const jwt = require('jsonwebtoken');

// Create a test token for RarefiedAir24
const testUser = {
  id: 'ae8fa884-1c96-4e08-86cd-8e986ed277b8',
  username: 'RarefiedAir24',
  email: 'supergeek@me.com'
};

const token = jwt.sign(testUser, 'c6ebabf7bf78c0155fd64564a956644acf63470cf965a6ac590b97d0f0ae0622');

console.log('Test token:', token);

// Test the gem purchase verification endpoint
const API_URL = 'https://am8zjeetod.execute-api.us-east-2.amazonaws.com/prod';

async function testGemPurchase() {
  try {
    console.log('\n--- Testing Gem Purchase Endpoint ---');
    
    // Test if the endpoint exists and responds
    const response = await fetch(`${API_URL}/user/verify-purchase`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        receipt: 'test-receipt',
        productId: 'gems_100'
      })
    });
    
    console.log('Response status:', response.status);
    
    if (response.ok) {
      const data = await response.json();
      console.log('Gem purchase verification successful:', data);
    } else {
      const errorText = await response.text();
      console.log('Gem purchase verification failed:', response.status, errorText);
    }
    
  } catch (error) {
    console.error('Gem purchase test error:', error);
  }
}

testGemPurchase(); 