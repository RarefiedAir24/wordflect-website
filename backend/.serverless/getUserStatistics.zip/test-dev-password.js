const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function testDevPassword() {
  try {
    console.log('Testing dev table password...');
    
    // Get vitab from dev table
    const result = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-users-dev',
      FilterExpression: 'email = :email',
      ExpressionAttributeValues: {
        ':email': 'vitab@aol.com'
      }
    }));
    
    if (result.Items && result.Items.length > 0) {
      const user = result.Items[0];
      console.log('Full password hash:', user.password);
      
      // Test the password comparison
      const isMatch = await bcrypt.compare('Stella', user.password);
      console.log('Password match result:', isMatch);
      
      if (isMatch) {
        console.log('✅ Password verification successful!');
      } else {
        console.log('❌ Password verification failed!');
      }
    } else {
      console.log('User not found');
    }
    
  } catch (error) {
    console.error('Error testing password:', error);
  }
}

testDevPassword(); 