const jwt = require('jsonwebtoken');

// Create a test token for RarefiedAir24
const testUser = {
  id: 'ae8fa884-1c96-4e08-86cd-8e986ed277b8',
  username: 'RarefiedAir24',
  email: 'supergeek@me.com'
};

const token = jwt.sign(testUser, 'c6ebabf7bf78c0155fd64564a956644acf63470cf965a6ac590b97d0f0ae0622');

const API_URL = 'https://am8zjeetod.execute-api.us-east-2.amazonaws.com/prod';

async function testUserStats() {
  try {
    console.log('Testing user profile endpoint...');
    const response = await fetch(`${API_URL}/user/profile`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ User Profile Response:');
      console.log('Points:', data.points);
      console.log('Flectcoins:', data.flectcoins);
      console.log('Gems:', data.gems);
      console.log('Is Premium:', data.isPremium);
      console.log('Premium Tier:', data.premiumTier);
      console.log('Selected Frame:', data.selectedFrame?.name || 'None');
    } else {
      console.log('❌ Error:', response.status, await response.text());
    }
  } catch (error) {
    console.error('❌ Test error:', error);
  }
}

testUserStats(); 