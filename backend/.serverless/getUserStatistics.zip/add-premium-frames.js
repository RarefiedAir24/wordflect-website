const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function addPremiumFrames() {
  try {
    console.log('Adding premium frames to production database...');
    
    const premiumFrames = [
      {
        id: 'crystal-crown',
        name: 'Crystal Crown',
        imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/crystal-crown.png',
        rarity: 'premium',
        price: 0,
        premiumRequired: true,
        isDefault: false
      },
      {
        id: 'phoenix-reign',
        name: 'Phoenix Reign',
        imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/phoenix-reign.png',
        rarity: 'pro',
        price: 0,
        premiumRequired: true,
        isDefault: false
      }
    ];
    
    for (const frame of premiumFrames) {
      await dynamoDB.send(new PutCommand({
        TableName: 'wordflect-backend-frames-prod',
        Item: frame
      }));
      console.log(`✅ Added premium frame: ${frame.name} (${frame.rarity})`);
    }
    
    console.log('\n🎉 Premium frames added successfully!');
    
  } catch (error) {
    console.error('Error adding premium frames:', error);
  }
}

addPremiumFrames();
