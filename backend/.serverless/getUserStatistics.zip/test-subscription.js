const jwt = require('jsonwebtoken');

// Create a test token for RarefiedAir24
const testUser = {
  id: 'ae8fa884-1c96-4e08-86cd-8e986ed277b8',
  username: 'RarefiedAir24',
  email: 'supergeek@me.com'
};

const token = jwt.sign(testUser, 'c6ebabf7bf78c0155fd64564a956644acf63470cf965a6ac590b97d0f0ae0622');

console.log('Test token:', token);

// Test the subscription purchase endpoint
const API_URL = 'https://am8zjeetod.execute-api.us-east-2.amazonaws.com/prod';

async function testSubscriptionPurchase() {
  try {
    console.log('\n--- Testing Subscription Purchase ---');
    
    // Test Pro subscription purchase
    const response = await fetch(`${API_URL}/user/purchase-premium`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        tierId: 'wordflect-pro',
        paymentMethod: 'simulated',
        receipt: 'simulated-receipt'
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      console.log('Subscription purchase successful:', data);
      
      // Test user profile to see if premium status was updated
      console.log('\n--- Testing User Profile After Purchase ---');
      const profileResponse = await fetch(`${API_URL}/user/profile`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (profileResponse.ok) {
        const profileData = await profileResponse.json();
        console.log('User profile after purchase:', {
          isPremium: profileData.isPremium,
          premiumTier: profileData.premiumTier,
          subscriptionEndDate: profileData.subscriptionEndDate,
          gems: profileData.gems
        });
      } else {
        const errorText = await profileResponse.text();
        console.log('Profile fetch failed:', profileResponse.status, errorText);
      }
      
    } else {
      const errorText = await response.text();
      console.log('Subscription purchase failed:', response.status, errorText);
    }
    
  } catch (error) {
    console.error('Subscription test error:', error);
  }
}

testSubscriptionPurchase(); 