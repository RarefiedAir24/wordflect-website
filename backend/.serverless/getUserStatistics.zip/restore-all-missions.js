const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

function generateMissionId(type, title) {
  return `${type}-${title.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
}

async function restoreAllMissions() {
  try {
    console.log('Restoring all missions to production database...');
    
    const missions = [
      // === Daily Missions ===
      {
        id: generateMissionId('daily', 'Play 1 Game Today'),
        type: 'daily',
        title: 'Play 1 Game Today',
        description: 'Play at least one game today',
        target: 1,
        objective: 'Play Games Today',
        reward: { type: 'points', amount: 25 },
        tier: 'Daily Basics',
        category: 'gameplay',
        sortOrder: 1
      },
      {
        id: generateMissionId('daily', 'Find 10 Words'),
        type: 'daily',
        title: 'Find 10 Words',
        description: 'Find 10 words today',
        target: 10,
        objective: 'Find X Words Today',
        reward: { type: 'points', amount: 30 },
        tier: 'Daily Basics',
        category: 'word-finding',
        sortOrder: 2
      },
      {
        id: generateMissionId('daily', 'Score 100 Points'),
        type: 'daily',
        title: 'Score 100 Points',
        description: 'Score 100 points today',
        target: 100,
        objective: 'Score Points Today',
        reward: { type: 'points', amount: 40 },
        tier: 'Daily Basics',
        category: 'scoring',
        sortOrder: 3
      },
      {
        id: generateMissionId('daily', 'Find a Long Word'),
        type: 'daily',
        title: 'Find a Long Word',
        description: 'Find a word with 8 or more letters',
        target: 1,
        objective: 'Find Long Words Today',
        reward: { type: 'points', amount: 50 },
        tier: 'Daily Challenges',
        category: 'word-finding',
        sortOrder: 4,
        minWordLength: 8
      },
      {
        id: generateMissionId('daily', 'Complete Game Without Hints'),
        type: 'daily',
        title: 'Complete Game Without Hints',
        description: 'Complete a game without using any hints',
        target: 1,
        objective: 'Complete Games No Hints Today',
        reward: { type: 'points', amount: 100 },
        tier: 'Daily Challenges',
        category: 'gameplay',
        sortOrder: 5
      },
      {
        id: generateMissionId('daily', 'Play 3 Games'),
        type: 'daily',
        title: 'Play 3 Games',
        description: 'Play 3 games today',
        target: 3,
        objective: 'Play Games Today',
        reward: { type: 'points', amount: 60 },
        tier: 'Daily Challenges',
        category: 'gameplay',
        sortOrder: 6
      },
      {
        id: generateMissionId('daily', 'Find 3 Long Words'),
        type: 'daily',
        title: 'Find 3 Long Words',
        description: 'Find 3 words with 8 or more letters',
        target: 3,
        objective: 'Find Long Words Today',
        reward: { type: 'points', amount: 75 },
        tier: 'Daily Challenges',
        category: 'word-finding',
        sortOrder: 7,
        minWordLength: 8
      },
      {
        id: generateMissionId('daily', 'Score 200 Points'),
        type: 'daily',
        title: 'Score 200 Points',
        description: 'Score 200 points today',
        target: 200,
        objective: 'Score Points Today',
        reward: { type: 'points', amount: 80 },
        tier: 'Daily Challenges',
        category: 'scoring',
        sortOrder: 8
      },
      {
        id: generateMissionId('daily', 'Find 20 Words'),
        type: 'daily',
        title: 'Find 20 Words',
        description: 'Find 20 words today',
        target: 20,
        objective: 'Find X Words Today',
        reward: { type: 'points', amount: 90 },
        tier: 'Daily Challenges',
        category: 'word-finding',
        sortOrder: 9
      },
      {
        id: generateMissionId('daily', 'Find the Word of the Day'),
        type: 'daily',
        title: 'Find the Word of the Day',
        description: 'Find today\'s word of the day: {word}',
        target: 1,
        objective: 'Find Word of the Day Today',
        reward: { type: 'gems', amount: 100 },
        tier: 'Daily Special',
        category: 'special',
        sortOrder: 10
      },

      // === Weekly Missions ===
      {
        id: generateMissionId('weekly', 'Play 5 Games'),
        type: 'weekly',
        title: 'Play 5 Games',
        description: 'Play 5 games this week',
        target: 5,
        objective: 'Play Games This Week',
        reward: { type: 'points', amount: 50 },
        tier: 'Weekly Basics',
        category: 'gameplay',
        sortOrder: 1
      },
      {
        id: generateMissionId('weekly', 'Find 50 Words'),
        type: 'weekly',
        title: 'Find 50 Words',
        description: 'Find 50 words this week',
        target: 50,
        objective: 'Find X Words This Week',
        reward: { type: 'points', amount: 75 },
        tier: 'Weekly Basics',
        category: 'word-finding',
        sortOrder: 2
      },
      {
        id: generateMissionId('weekly', 'Score 500 Points'),
        type: 'weekly',
        title: 'Score 500 Points',
        description: 'Score 500 points this week',
        target: 500,
        objective: 'Score Points This Week',
        reward: { type: 'points', amount: 100 },
        tier: 'Weekly Basics',
        category: 'scoring',
        sortOrder: 3
      },
      {
        id: generateMissionId('weekly', 'Find 10 Long Words'),
        type: 'weekly',
        title: 'Find 10 Long Words',
        description: 'Find 10 words with 8 or more letters this week',
        target: 10,
        objective: 'Find Long Words This Week',
        reward: { type: 'points', amount: 125 },
        tier: 'Weekly Challenges',
        category: 'word-finding',
        sortOrder: 4,
        minWordLength: 8
      },
      {
        id: generateMissionId('weekly', 'Complete 5 Games Without Hints'),
        type: 'weekly',
        title: 'Complete 5 Games Without Hints',
        description: 'Complete 5 games without using any hints this week',
        target: 5,
        objective: 'Complete Games No Hints This Week',
        reward: { type: 'points', amount: 200 },
        tier: 'Weekly Challenges',
        category: 'gameplay',
        sortOrder: 5
      },
      {
        id: generateMissionId('weekly', 'Play Every Day'),
        type: 'weekly',
        title: 'Play Every Day',
        description: 'Play every day this week',
        target: 7,
        objective: 'Play Every Day This Week',
        reward: { type: 'points', amount: 300 },
        tier: 'Weekly Challenges',
        category: 'gameplay',
        sortOrder: 6
      },
      {
        id: generateMissionId('weekly', 'Score 1000 Points'),
        type: 'weekly',
        title: 'Score 1000 Points',
        description: 'Score 1000 points this week',
        target: 1000,
        objective: 'Score Points This Week',
        reward: { type: 'points', amount: 150 },
        tier: 'Weekly Challenges',
        category: 'scoring',
        sortOrder: 7
      },
      {
        id: generateMissionId('weekly', 'Find the Word of the Day 7 Days in a Row'),
        type: 'weekly',
        title: 'Find the Word of the Day 7 Days in a Row',
        description: 'Find the word of the day every day this week',
        target: 7,
        objective: 'Find Word of the Day Streak',
        reward: { type: 'gems', amount: 500 },
        tier: 'Weekly Special',
        category: 'special',
        sortOrder: 8
      },

      // === Global Missions ===
      {
        id: generateMissionId('global', 'Reach Level 10'),
        type: 'global',
        title: 'Reach Level 10',
        description: 'Reach level 10',
        target: 10,
        objective: 'Reach Level',
        reward: { type: 'points', amount: 2000 },
        tier: 'Level Milestones',
        category: 'progression',
        sortOrder: 1
      },
      {
        id: generateMissionId('global', 'Reach Level 25'),
        type: 'global',
        title: 'Reach Level 25',
        description: 'Reach level 25',
        target: 25,
        objective: 'Reach Level',
        reward: { type: 'points', amount: 5000 },
        tier: 'Level Milestones',
        category: 'progression',
        sortOrder: 2
      },
      {
        id: generateMissionId('global', 'Reach Level 50'),
        type: 'global',
        title: 'Reach Level 50',
        description: 'Reach level 50',
        target: 50,
        objective: 'Reach Level',
        reward: { type: 'points', amount: 10000 },
        tier: 'Level Milestones',
        category: 'progression',
        sortOrder: 3
      },
      {
        id: generateMissionId('global', 'Play 100 Games'),
        type: 'global',
        title: 'Play 100 Games',
        description: 'Play 100 games total',
        target: 100,
        objective: 'Play X Games Total',
        reward: { type: 'points', amount: 5000 },
        tier: 'Gameplay Milestones',
        category: 'gameplay',
        sortOrder: 4
      },
      {
        id: generateMissionId('global', 'Find 1000 Words'),
        type: 'global',
        title: 'Find 1000 Words',
        description: 'Find 1000 words total',
        target: 1000,
        objective: 'Find X Words Total',
        reward: { type: 'points', amount: 8000 },
        tier: 'Word Finding Milestones',
        category: 'word-finding',
        sortOrder: 5
      },
      {
        id: generateMissionId('global', 'Find 5000 Words'),
        type: 'global',
        title: 'Find 5000 Words',
        description: 'Find 5000 words total',
        target: 5000,
        objective: 'Find X Words Total',
        reward: { type: 'points', amount: 25000 },
        tier: 'Word Finding Milestones',
        category: 'word-finding',
        sortOrder: 6
      },
      {
        id: generateMissionId('global', 'Score 10000 Points'),
        type: 'global',
        title: 'Score 10000 Points',
        description: 'Score 10000 points total',
        target: 10000,
        objective: 'Score X Points Total',
        reward: { type: 'points', amount: 15000 },
        tier: 'Scoring Milestones',
        category: 'scoring',
        sortOrder: 7
      },
      {
        id: generateMissionId('global', 'Maintain 7-Day Login Streak'),
        type: 'global',
        title: 'Maintain 7-Day Login Streak',
        description: 'Login for 7 consecutive days',
        target: 7,
        objective: 'Login Streak',
        reward: { type: 'points', amount: 1000 },
        tier: 'Login Milestones',
        category: 'login',
        sortOrder: 8
      }
    ];
    
    for (const mission of missions) {
      await dynamoDB.send(new PutCommand({
        TableName: 'wordflect-backend-missions-prod',
        Item: mission
      }));
      console.log(`✅ Restored mission: ${mission.title} (${mission.type})`);
    }
    
    console.log('\n🎉 All missions restored successfully!');
    console.log(`Total missions restored: ${missions.length}`);
    console.log('\nMission breakdown:');
    console.log(`- Daily missions: ${missions.filter(m => m.type === 'daily').length}`);
    console.log(`- Weekly missions: ${missions.filter(m => m.type === 'weekly').length}`);
    console.log(`- Global missions: ${missions.filter(m => m.type === 'global').length}`);
    
  } catch (error) {
    console.error('Error restoring missions:', error);
  }
}

restoreAllMissions();
