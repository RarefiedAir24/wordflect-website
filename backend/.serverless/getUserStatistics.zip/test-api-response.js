const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function testAPIResponse() {
  console.log('🧪 Testing API Response Structure...\n');
  
  try {
    // Get user data
    const userResult = await dynamoDB.send(new GetCommand({
      TableName: 'wordflect-backend-users-prod',
      Key: { id: 'd59de7c3-9c83-41c9-87bf-a73b87048ff3' }
    }));
    
    if (!userResult.Item) {
      console.log('❌ User not found');
      return;
    }
    
    const user = userResult.Item;
    console.log('👤 User Data:');
    console.log(`   Email: ${user.email}`);
    console.log(`   Username: ${user.username}`);
    console.log(`   Level: ${user.level}`);
    console.log(`   Gems: ${user.gems}`);
    console.log(`   Flectcoins: ${user.flectcoins}`);
    console.log(`   Mission Progress: ${JSON.stringify(user.missionProgress || {})}`);
    console.log('');
    
    // Simulate the API response structure
    const mockAPIResponse = {
      success: true,
      data: {
        user: {
          email: user.email,
          username: user.username,
          level: user.level,
          gems: user.gems,
          flectcoins: user.flectcoins,
          missionProgress: user.missionProgress || {}
        },
        missions: {
          daily: [],
          weekly: [],
          global: []
        }
      }
    };
    
    // Get all missions
    const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
    const missionsResult = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-missions-prod'
    }));
    
    // Group missions by type
    const dailyMissions = missionsResult.Items.filter(item => item.type === 'daily');
    const weeklyMissions = missionsResult.Items.filter(item => item.type === 'weekly');
    const globalMissions = missionsResult.Items.filter(item => item.type === 'global');
    
    // Add sample missions to response
    mockAPIResponse.data.missions.daily = dailyMissions.slice(0, 5).map(mission => ({
      id: mission.id,
      title: mission.title,
      type: mission.type,
      target: mission.target,
      tier: mission.tier,
      flectcoins: mission.flectcoins,
      gems: mission.gems,
      sortOrder: mission.sortOrder,
      progress: user.missionProgress?.[mission.id] || 0,
      completed: (user.missionProgress?.[mission.id] || 0) >= mission.target
    }));
    
    mockAPIResponse.data.missions.weekly = weeklyMissions.slice(0, 3).map(mission => ({
      id: mission.id,
      title: mission.title,
      type: mission.type,
      target: mission.target,
      tier: mission.tier,
      flectcoins: mission.flectcoins,
      gems: mission.gems,
      sortOrder: mission.sortOrder,
      progress: user.missionProgress?.[mission.id] || 0,
      completed: (user.missionProgress?.[mission.id] || 0) >= mission.target
    }));
    
    mockAPIResponse.data.missions.global = globalMissions.slice(0, 3).map(mission => ({
      id: mission.id,
      title: mission.title,
      type: mission.type,
      target: mission.target,
      tier: mission.tier,
      flectcoins: mission.flectcoins,
      gems: mission.gems,
      sortOrder: mission.sortOrder,
      progress: user.missionProgress?.[mission.id] || 0,
      completed: (user.missionProgress?.[mission.id] || 0) >= mission.target
    }));
    
    console.log('📡 API Response Structure:');
    console.log('==========================');
    console.log(JSON.stringify(mockAPIResponse, null, 2));
    
    console.log('\n🔍 Sample Mission Rewards:');
    console.log('==========================');
    console.log('📅 Daily Missions:');
    mockAPIResponse.data.missions.daily.forEach(mission => {
      console.log(`   ${mission.title}: ${mission.flectcoins} flectcoins, ${mission.gems} gems (${mission.tier})`);
    });
    
    console.log('\n📆 Weekly Missions:');
    mockAPIResponse.data.missions.weekly.forEach(mission => {
      console.log(`   ${mission.title}: ${mission.flectcoins} flectcoins, ${mission.gems} gems (${mission.tier})`);
    });
    
    console.log('\n🌍 Global Missions:');
    mockAPIResponse.data.missions.global.forEach(mission => {
      console.log(`   ${mission.title}: ${mission.flectcoins} flectcoins, ${mission.gems} gems (${mission.tier})`);
    });
    
    console.log('\n✅ API response structure is correct!');
    console.log('📱 This should now display properly in the TestFlight app.');
    
  } catch (error) {
    console.error('❌ Error testing API response:', error);
  }
}

testAPIResponse();
