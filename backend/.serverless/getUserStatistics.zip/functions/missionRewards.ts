import { DynamoDB } from 'aws-sdk';
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';

const dynamoDB = new DynamoDB.DocumentClient();
const USERS_TABLE = process.env.USERS_TABLE!;
const MISSIONS_TABLE = process.env.MISSIONS_TABLE!;

interface MissionReward {
  type: 'points' | 'coins' | 'xp';
  amount: number;
}

interface Mission {
  id: string;
  type: 'daily' | 'weekly' | 'global';
  reward: MissionReward;
}

export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  try {
    const userId = event.requestContext.authorizer?.claims.sub;
    if (!userId) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Unauthorized' }),
      };
    }

    const { missionId } = JSON.parse(event.body || '{}');
    if (!missionId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Mission ID is required' }),
      };
    }

    // Get mission details
    const missionResult = await dynamoDB.get({
      TableName: MISSIONS_TABLE,
      Key: { id: missionId },
    }).promise();

    const mission = missionResult.Item as Mission;
    if (!mission) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'Mission not found' }),
      };
    }

    // Get user data
    const userResult = await dynamoDB.get({
      TableName: USERS_TABLE,
      Key: { id: userId },
    }).promise();

    const user = userResult.Item;
    if (!user) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    // Check if mission is already completed
    if (user.completedMissions?.includes(missionId)) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Mission already completed' }),
      };
    }

    // Calculate rewards
    const rewards = calculateRewards(mission, user);
    const newLevel = calculateNewLevel(user.level, rewards.xp);

    // Update user data
    await dynamoDB.update({
      TableName: USERS_TABLE,
      Key: { id: userId },
      UpdateExpression: 'SET points = if_not_exists(points, :zero) + :points, coins = if_not_exists(coins, :zero) + :coins, xp = if_not_exists(xp, :zero) + :xp, level = :level, completedMissions = list_append(if_not_exists(completedMissions, :empty_list), :missionId)',
      ExpressionAttributeValues: {
        ':points': rewards.points,
        ':coins': rewards.coins,
        ':xp': rewards.xp,
        ':level': newLevel,
        ':missionId': [missionId],
        ':empty_list': [],
        ':zero': 0,
      },
    }).promise();

    // Update mission stats
    await dynamoDB.update({
      TableName: USERS_TABLE,
      Key: { id: userId },
      UpdateExpression: 'SET missionStats.#type = missionStats.#type + :inc',
      ExpressionAttributeNames: {
        '#type': `${mission.type}Completed`,
      },
      ExpressionAttributeValues: {
        ':inc': 1,
      },
    }).promise();

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Mission completed successfully',
        rewards,
        newLevel,
      }),
    };
  } catch (error) {
    console.error('Error completing mission:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal server error' }),
    };
  }
};

function calculateRewards(mission: Mission, user: any): { points: number; coins: number; xp: number } {
  const baseReward = mission.reward.amount;
  const streakMultiplier = calculateStreakMultiplier(user);
  const levelMultiplier = 1 + (user.level * 0.1); // 10% increase per level

  const totalMultiplier = streakMultiplier * levelMultiplier;

  return {
    points: Math.floor(baseReward * totalMultiplier),
    coins: Math.floor(baseReward * 0.5 * totalMultiplier),
    xp: Math.floor(baseReward * 0.2 * totalMultiplier),
  };
}

function calculateStreakMultiplier(user: any): number {
  const streak = user.currentStreak || 0;
  if (streak >= 7) return 2.0;
  if (streak >= 5) return 1.5;
  if (streak >= 3) return 1.2;
  return 1.0;
}

function calculateNewLevel(currentLevel: number, xpGained: number): number {
  const xpPerLevel = 1000; // Base XP required per level
  const totalXp = (currentLevel * xpPerLevel) + xpGained;
  return Math.floor(totalXp / xpPerLevel);
} 