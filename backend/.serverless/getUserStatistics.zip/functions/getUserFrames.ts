import { DynamoDB } from 'aws-sdk';
import mongoose from 'mongoose';
import Frame from '../src/models/Frame';
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';

const dynamoDB = new DynamoDB.DocumentClient();
const USERS_TABLE = process.env.USERS_TABLE || 'wordflect-backend-users-dev';
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/wordflect';

export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  try {
    // Authenticate user (assume JWT claims in event.requestContext.authorizer)
    const userId = event.requestContext.authorizer?.claims?.sub || event.requestContext.authorizer?.claims?.id;
    if (!userId) {
      return {
        statusCode: 401,
        body: JSON.stringify({ error: 'Unauthorized' }),
      };
    }

    // Fetch user from DynamoDB
    const userResult = await dynamoDB.get({
      TableName: USERS_TABLE,
      Key: { id: userId },
    }).promise();
    const user = userResult.Item;
    if (!user) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: 'User not found' }),
      };
    }
    const unlockedFrames = user.unlockedFrames || [];

    // Connect to MongoDB if not already connected
    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI);
    }

    // Fetch all frames from MongoDB
    const allFrames = await Frame.find();

    // Mark frames as unlocked if user has them
    const frames = allFrames.map(frame => {
      const frameObj = frame.toObject() as { [key: string]: any };
      const frameId = typeof frameObj._id === 'string' ? frameObj._id : frameObj._id.toString();
      return {
        ...frameObj,
        id: frameId,
        isUnlocked: unlockedFrames.includes(frameId),
      };
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ frames }),
    };
  } catch (error) {
    console.error('Error fetching frames:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to fetch frames' }),
    };
  }
}; 