const jwt = require('jsonwebtoken');

// Create a test token for RarefiedAir24
const testUser = {
  id: 'ae8fa884-1c96-4e08-86cd-8e986ed277b8',
  username: 'RarefiedAir24',
  email: 'supergeek@me.com'
};

const token = jwt.sign(testUser, 'c6ebabf7bf78c0155fd64564a956644acf63470cf965a6ac590b97d0f0ae0622');

console.log('Test token:', token);

// Test the frames endpoint
const API_URL = 'https://am8zjeetod.execute-api.us-east-2.amazonaws.com/prod';

async function testAPI() {
  try {
    // Test frames endpoint
    console.log('\n--- Testing Frames Endpoint ---');
    const framesResponse = await fetch(`${API_URL}/frames`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (framesResponse.ok) {
      const framesData = await framesResponse.json();
      console.log('Frames response length:', framesData.length);
      console.log('First few frames:', framesData.slice(0, 3));
      
      // Check for premium frames
      const premiumFrames = framesData.filter(f => f.id === 'crystal-crown' || f.id === 'phoenix-reign');
      console.log('Premium frames found:', premiumFrames.length);
      if (premiumFrames.length > 0) {
        console.log('Premium frame details:', premiumFrames[0]);
      }
    } else {
      console.log('Frames error:', framesResponse.status, await framesResponse.text());
    }

    // Test user profile endpoint
    console.log('\n--- Testing User Profile Endpoint ---');
    const profileResponse = await fetch(`${API_URL}/user/profile`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (profileResponse.ok) {
      const profileData = await profileResponse.json();
      console.log('Profile response keys:', Object.keys(profileData));
      console.log('User stats:', {
        points: profileData.points,
        flectcoins: profileData.flectcoins,
        gems: profileData.gems,
        isPremium: profileData.isPremium,
        premiumTier: profileData.premiumTier
      });
    } else {
      console.log('Profile error:', profileResponse.status, await profileResponse.text());
    }

  } catch (error) {
    console.error('API test error:', error);
  }
}

testAPI(); 