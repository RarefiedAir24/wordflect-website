const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function createSupergeekProdUserFinal() {
  try {
    console.log('Creating supergeek@me.com user in PRODUCTION table...');
    
    // Generate user ID
    const userId = uuidv4();
    
    // Hash the password
    const password = 'test123';
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    
    // Create user object
    const user = {
      id: userId,
      email: 'supergeek@me.com',
      username: 'supergeek',
      password: hashedPassword,
      createdAt: new Date().toISOString(),
      highestLevel: 1,
      gems: 100,
      flectcoins: 500,
      isPremium: false,
      premiumTier: 'free',
      selectedFrame: 'default'
    };
    
    // Add user to production table
    const putResult = await dynamoDB.send(new PutCommand({
      TableName: 'wordflect-backend-users-prod',
      Item: user
    }));
    
    console.log('✅ User created successfully in PRODUCTION table!');
    console.log('User ID:', userId);
    console.log('Username:', user.username);
    console.log('Email:', user.email);
    console.log('\nYou can now sign in with:');
    console.log('Email: supergeek@me.com');
    console.log('Password: test123');
    
    // Test the password
    const isMatch = await bcrypt.compare(password, hashedPassword);
    console.log('\nPassword verification test:', isMatch ? '✅ PASS' : '❌ FAIL');
    
  } catch (error) {
    console.error('Error creating user:', error);
  }
}

createSupergeekProdUserFinal();
