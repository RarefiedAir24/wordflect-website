const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function createTestFramesFixed() {
  try {
    console.log('Creating test frames in production database...');
    
    const frames = [
      {
        id: 'golden',
        frameId: 'golden',
        name: 'Golden Frame',
        description: 'A luxurious golden frame',
        price: 1000,
        rarity: 'rare',
        imageUrl: 'https://example.com/golden-frame.png',
        isAvailable: true
      },
      {
        id: 'diamond',
        frameId: 'diamond',
        name: 'Diamond Frame',
        description: 'A sparkling diamond frame',
        price: 2500,
        rarity: 'epic',
        imageUrl: 'https://example.com/diamond-frame.png',
        isAvailable: true
      },
      {
        id: 'rainbow',
        frameId: 'rainbow',
        name: 'Rainbow Frame',
        description: 'A colorful rainbow frame',
        price: 500,
        rarity: 'common',
        imageUrl: 'https://example.com/rainbow-frame.png',
        isAvailable: true
      },
      {
        id: 'neon',
        frameId: 'neon',
        name: 'Neon Frame',
        description: 'A glowing neon frame',
        price: 1500,
        rarity: 'rare',
        imageUrl: 'https://example.com/neon-frame.png',
        isAvailable: true
      },
      {
        id: 'crystal',
        frameId: 'crystal',
        name: 'Crystal Frame',
        description: 'A transparent crystal frame',
        price: 3000,
        rarity: 'legendary',
        imageUrl: 'https://example.com/crystal-frame.png',
        isAvailable: true
      }
    ];
    
    for (const frame of frames) {
      await dynamoDB.send(new PutCommand({
        TableName: 'wordflect-backend-frames-prod',
        Item: frame
      }));
      console.log(`✅ Created frame: ${frame.name} (${frame.rarity})`);
    }
    
    console.log('\n🎉 All test frames created successfully!');
    
  } catch (error) {
    console.error('Error creating frames:', error);
  }
}

createTestFramesFixed();
