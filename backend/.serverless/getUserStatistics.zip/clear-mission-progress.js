const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

const USERS_TABLE = 'wordflect-backend-users-prod';

async function clearMissionProgress() {
  console.log('Clearing mission completion status for all users...');

  try {
    // Get all users
    const result = await dynamoDB.send(new ScanCommand({
      TableName: USERS_TABLE
    }));

    if (!result.Items || result.Items.length === 0) {
      console.log('No users found');
      return;
    }

    console.log(`Found ${result.Items.length} users`);

    let clearedCount = 0;
    for (const user of result.Items) {
      if (user.missions && Object.keys(user.missions).length > 0) {
        console.log(`Clearing missions for user: ${user.username || user.email || user.id}`);
        
        // Clear all mission progress
        await dynamoDB.send(new UpdateCommand({
          TableName: USERS_TABLE,
          Key: { id: user.id },
          UpdateExpression: 'REMOVE missions',
        }));
        
        clearedCount++;
      }
    }

    console.log(`✅ Cleared mission progress for ${clearedCount} users`);
    console.log('🎉 All mission completion status has been reset!');

  } catch (error) {
    console.error('❌ Error clearing mission progress:', error);
    throw error;
  }
}

// Run the script
clearMissionProgress()
  .then(() => {
    console.log('🎉 Script completed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 Script failed:', error);
    process.exit(1);
  });
