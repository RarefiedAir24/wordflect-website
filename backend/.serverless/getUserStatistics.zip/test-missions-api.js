const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function testMissionsAPI() {
  console.log('🧪 Testing Missions API and Database...\n');
  
  try {
    // 1. Check missions table directly
    console.log('1️⃣ Checking missions table directly...');
    const missionsResult = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-missions-prod'
    }));
    
    console.log(`   📊 Total missions in table: ${missionsResult.Items?.length || 0}`);
    
    if (missionsResult.Items && missionsResult.Items.length > 0) {
      const dailyMissions = missionsResult.Items.filter(m => m.type === 'daily');
      const weeklyMissions = missionsResult.Items.filter(m => m.type === 'weekly');
      const globalMissions = missionsResult.Items.filter(m => m.type === 'global');
      
      console.log(`   📅 Daily missions: ${dailyMissions.length}`);
      console.log(`   📆 Weekly missions: ${weeklyMissions.length}`);
      console.log(`   🌍 Global missions: ${globalMissions.length}`);
      
      console.log('\n   📋 Sample daily missions:');
      dailyMissions.slice(0, 3).forEach((mission, i) => {
        console.log(`      ${i + 1}. ${mission.title} (${mission.id})`);
      });
    } else {
      console.log('   ❌ No missions found in table!');
    }
    
    // 2. Check Word of the Day
    console.log('\n2️⃣ Checking Word of the Day...');
    const wotdResult = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-word-of-the-day-prod'
    }));
    
    if (wotdResult.Items && wotdResult.Items.length > 0) {
      const today = new Date().toISOString().split('T')[0];
      const todayWord = wotdResult.Items.find(item => item.date === today);
      
      if (todayWord) {
        console.log(`   ✅ Word of the Day for ${today}: "${todayWord.word}"`);
      } else {
        console.log(`   ⚠️  No word found for today (${today})`);
        console.log(`   📅 Available dates: ${wotdResult.Items.map(item => item.date).join(', ')}`);
      }
    } else {
      console.log('   ❌ No Word of the Day data found!');
    }
    
    // 3. Check user data
    console.log('\n3️⃣ Checking user data...');
    const usersResult = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-users-prod'
    }));
    
    if (usersResult.Items && usersResult.Items.length > 0) {
      const user = usersResult.Items[0]; // Get first user
      console.log(`   👤 User found: ${user.username || user.email}`);
      console.log(`   🎮 Level: ${user.highestLevel || 'N/A'}`);
      console.log(`   💎 Gems: ${user.gems || 'N/A'}`);
      console.log(`   🪙 Flectcoins: ${user.flectcoins || 'N/A'}`);
      console.log(`   👑 Premium: ${user.isPremium ? 'Yes' : 'No'}`);
      
      if (user.missions) {
        const dailyProgress = Object.keys(user.missions.daily || {}).length;
        const weeklyProgress = Object.keys(user.missions.weekly || {}).length;
        const globalProgress = Object.keys(user.missions.global || {}).length;
        
        console.log(`   📊 Mission progress - Daily: ${dailyProgress}, Weekly: ${weeklyProgress}, Global: ${globalProgress}`);
      } else {
        console.log('   ⚠️  No mission progress found for user');
      }
    } else {
      console.log('   ❌ No users found!');
    }
    
    // 4. Test API endpoint (if we had a valid token)
    console.log('\n4️⃣ API Status Check...');
    console.log('   🌐 API URL: https://fo0rh1w8m9.execute-api.us-east-2.amazonaws.com/prod');
    console.log('   📡 Missions endpoint: /user/missions');
    console.log('   📡 Word of Day endpoint: /user/word-of-the-day');
    
    console.log('\n✅ Database check complete!');
    console.log('\n📱 Next steps:');
    console.log('   1. Test the new TestFlight build (v1.0.141)');
    console.log('   2. Check console logs for API responses');
    console.log('   3. Verify missions appear in the app');
    
  } catch (error) {
    console.error('❌ Error testing missions:', error);
  }
}

testMissionsAPI();
