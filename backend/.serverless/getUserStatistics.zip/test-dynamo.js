const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function testDynamo() {
  try {
    console.log('Testing DynamoDB connection...');
    console.log('Table name:', 'wordflect-backend-users-prod');
    
    const scanResult = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-users-prod',
      Limit: 1
    }));
    
    console.log('Scan successful!');
    console.log('Items found:', scanResult.Items ? scanResult.Items.length : 0);
    if (scanResult.Items && scanResult.Items.length > 0) {
      console.log('First user:', {
        id: scanResult.Items[0].id,
        email: scanResult.Items[0].email,
        username: scanResult.Items[0].username
      });
    }
  } catch (error) {
    console.error('DynamoDB test failed:', error);
  }
}

testDynamo(); 