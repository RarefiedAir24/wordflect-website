const fetch = require('node-fetch');

// Test the subscription verification endpoint
const API_URL = 'https://am8zjeetod.execute-api.us-east-2.amazonaws.com/prod';

// You'll need to get a valid token for testing
const token = 'YOUR_TEST_TOKEN_HERE'; // Replace with actual token

async function testSubscriptionVerification() {
  try {
    console.log('Testing subscription verification endpoint...');
    
    // Test with a mock receipt (this would normally come from Apple)
    const testData = {
      receipt: 'mock_receipt_data',
      productId: 'wordflectpro'
    };

    const response = await fetch(`${API_URL}/user/verify-subscription`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(testData)
    });

    console.log('Response status:', response.status);
    
    if (response.ok) {
      const data = await response.json();
      console.log('Subscription verification response:', data);
    } else {
      const errorText = await response.text();
      console.log('Error response:', errorText);
    }

  } catch (error) {
    console.error('Test error:', error);
  }
}

testSubscriptionVerification(); 