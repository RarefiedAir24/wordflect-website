const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, DeleteCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

function generateMissionId(type, title) {
  return `${type}-${title.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
}

async function updateWeeklyMissions() {
  try {
    console.log('Updating weekly missions to remove word-finding missions...');
    
    // First, let's see what's currently in the database
    const scanResult = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-missions-prod',
      FilterExpression: '#type = :type',
      ExpressionAttributeNames: { '#type': 'type' },
      ExpressionAttributeValues: { ':type': 'weekly' }
    }));
    
    console.log(`Found ${scanResult.Items.length} current weekly missions`);
    
    // Delete existing weekly missions
    for (const mission of scanResult.Items) {
      console.log(`Deleting mission: ${mission.title}`);
      await dynamoDB.send(new DeleteCommand({
        TableName: 'wordflect-backend-missions-prod',
        Key: { id: mission.id }
      }));
    }
    
    // Create new weekly missions focused on gameplay, scoring, and special missions
    const weeklyMissions = [
      // Basic gameplay missions
      { 
        id: generateMissionId('weekly', 'Play 5 Games'), 
        type: 'weekly', 
        title: 'Play 5 Games', 
        description: 'Play 5 games this week', 
        target: 5, 
        objective: 'Play Games This Week', 
        reward: { type: 'points', amount: 50 }, 
        tier: 'Weekly Basics', 
        category: 'gameplay', 
        sortOrder: 1 
      },
      { 
        id: generateMissionId('weekly', 'Score 500 Points'), 
        type: 'weekly', 
        title: 'Score 500 Points', 
        description: 'Score 500 points this week', 
        target: 500, 
        objective: 'Score Points This Week', 
        reward: { type: 'points', amount: 100 }, 
        tier: 'Weekly Basics', 
        category: 'scoring', 
        sortOrder: 2 
      },
      { 
        id: generateMissionId('weekly', 'Score 1000 Points'), 
        type: 'weekly', 
        title: 'Score 1000 Points', 
        description: 'Score 1000 points this week', 
        target: 1000, 
        objective: 'Score Points This Week', 
        reward: { type: 'points', amount: 150 }, 
        tier: 'Weekly Challenges', 
        category: 'scoring', 
        sortOrder: 3 
      },
      { 
        id: generateMissionId('weekly', 'Complete 5 Games Without Hints'), 
        type: 'weekly', 
        title: 'Complete 5 Games Without Hints', 
        description: 'Complete 5 games without using any hints this week', 
        target: 5, 
        objective: 'Complete Games No Hints This Week', 
        reward: { type: 'points', amount: 200 }, 
        tier: 'Weekly Challenges', 
        category: 'gameplay', 
        sortOrder: 4 
      },
      { 
        id: generateMissionId('weekly', 'Play Every Day'), 
        type: 'weekly', 
        title: 'Play Every Day', 
        description: 'Play every day this week', 
        target: 7, 
        objective: 'Play Every Day This Week', 
        reward: { type: 'points', amount: 300 }, 
        tier: 'Weekly Challenges', 
        category: 'gameplay', 
        sortOrder: 5 
      },
      { 
        id: generateMissionId('weekly', 'Find the Word of the Day 7 Days in a Row'), 
        type: 'weekly', 
        title: 'Find the Word of the Day 7 Days in a Row', 
        description: 'Find the word of the day every day this week', 
        target: 7, 
        objective: 'Find Word of the Day Streak', 
        reward: { type: 'gems', amount: 500 }, 
        tier: 'Weekly Special', 
        category: 'special', 
        sortOrder: 6 
      },
      { 
        id: generateMissionId('weekly', 'Score 2000 Points'), 
        type: 'weekly', 
        title: 'Score 2000 Points', 
        description: 'Score 2000 points this week', 
        target: 2000, 
        objective: 'Score Points This Week', 
        reward: { type: 'points', amount: 250 }, 
        tier: 'Weekly Challenges', 
        category: 'scoring', 
        sortOrder: 7 
      },
      { 
        id: generateMissionId('weekly', 'Play 10 Games'), 
        type: 'weekly', 
        title: 'Play 10 Games', 
        description: 'Play 10 games this week', 
        target: 10, 
        objective: 'Play Games This Week', 
        reward: { type: 'points', amount: 120 }, 
        tier: 'Weekly Challenges', 
        category: 'gameplay', 
        sortOrder: 8 
      }
    ];
    
    // Add the missions to the database
    for (const mission of weeklyMissions) {
      await dynamoDB.send(new PutCommand({
        TableName: 'wordflect-backend-missions-prod',
        Item: mission
      }));
      console.log(`✅ Added mission: ${mission.title} (${mission.type})`);
    }
    
    console.log(`\n🎉 Updated weekly missions! Total: ${weeklyMissions.length} missions`);
    console.log('📋 Weekly missions now focus on: gameplay, scoring, and special missions');
    console.log('🗑️ Removed word-finding missions (now handled in daily missions)');
    
  } catch (error) {
    console.error('Error updating weekly missions:', error);
  }
}

updateWeeklyMissions();
