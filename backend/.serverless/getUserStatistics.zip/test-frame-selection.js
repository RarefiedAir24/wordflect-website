const jwt = require('jsonwebtoken');

// Create a test token for RarefiedAir24
const testUser = {
  id: 'ae8fa884-1c96-4e08-86cd-8e986ed277b8',
  username: 'RarefiedAir24',
  email: 'supergeek@me.com'
};

const token = jwt.sign(testUser, 'c6ebabf7bf78c0155fd64564a956644acf63470cf965a6ac590b97d0f0ae0622');

console.log('Test token:', token);

// Test the frame selection endpoint
const API_URL = 'https://am8zjeetod.execute-api.us-east-2.amazonaws.com/prod';

async function testFrameSelection() {
  try {
    // Test crystal-crown frame selection
    console.log('\n--- Testing Crystal Crown Frame Selection ---');
    const crystalResponse = await fetch(`${API_URL}/user/select-frame`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ frameId: 'crystal-crown' })
    });
    
    if (crystalResponse.ok) {
      const crystalData = await crystalResponse.json();
      console.log('Crystal Crown selection successful:', crystalData);
    } else {
      const errorText = await crystalResponse.text();
      console.log('Crystal Crown selection failed:', crystalResponse.status, errorText);
    }

    // Test phoenix-reign frame selection
    console.log('\n--- Testing Phoenix Reign Frame Selection ---');
    const phoenixResponse = await fetch(`${API_URL}/user/select-frame`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ frameId: 'phoenix-reign' })
    });
    
    if (phoenixResponse.ok) {
      const phoenixData = await phoenixResponse.json();
      console.log('Phoenix Reign selection successful:', phoenixData);
    } else {
      const errorText = await phoenixResponse.text();
      console.log('Phoenix Reign selection failed:', phoenixResponse.status, errorText);
    }

  } catch (error) {
    console.error('Frame selection test error:', error);
  }
}

testFrameSelection(); 