const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function testSupergeekPassword() {
  try {
    console.log('Testing supergeek password...');
    
    // Get supergeek from prod table
    const result = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-users-prod',
      FilterExpression: 'email = :email',
      ExpressionAttributeValues: {
        ':email': 'supergeek@me.com'
      }
    }));
    
    if (result.Items && result.Items.length > 0) {
      const user = result.Items[0];
      console.log('Full password hash:', user.password);
      
      // Test the password
      const testPassword = 'Supergeek123';
      const isMatch = await bcrypt.compare(testPassword, user.password);
      console.log('Password verification test:', isMatch ? '✅ PASS' : '❌ FAIL');
      
      if (!isMatch) {
        console.log('Testing with different password variations...');
        const variations = ['supergeek123', 'Supergeek', 'supergeek', 'SUPERGEEK123'];
        for (const variation of variations) {
          const match = await bcrypt.compare(variation, user.password);
          console.log(`"${variation}": ${match ? '✅' : '❌'}`);
        }
      }
    } else {
      console.log('Supergeek not found in prod table');
    }
    
  } catch (error) {
    console.error('Error testing password:', error);
  }
}

testSupergeekPassword(); 