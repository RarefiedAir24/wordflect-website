const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, PutCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const { v4: uuidv4 } = require('uuid');
const fetch = require('node-fetch');
const jwt = require('jsonwebtoken');

const dynamoDB = new DynamoDBClient({ region: 'us-east-2' });
const docClient = DynamoDBDocumentClient.from(dynamoDB);

const USERS_TABLE = 'wordflect-backend-users-dev2';
const MISSIONS_TABLE = 'wordflect-backend-missions-dev2';

const USER_ID = 'ae8fa884-1c96-4e08-86cd-8e986ed277b8';
const JWT = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImFlOGZhODg0LTFjOTYtNGUwOC04NmNkLThlOTg2ZWQyNzdiOCIsImVtYWlsIjoic3VwZXJnZWVrQG1lLmNvbSIsInVzZXJuYW1lIjoiUmFyZWZpZWRBaXIyNCIsImlhdCI6MTc0OTMyNTY4OCwiZXhwIjoxNzQ5OTMwNDg4fQ.-hp4xforz80peHYsTCFs_a_5cdz27oAKjNZmaMSTMhY';

async function createTestUser() {
  const userId = uuidv4();
  const user = {
    id: userId,
    username: 'testuser',
    email: 'test@example.com',
    password: 'hashedpassword',
    createdAt: new Date().toISOString(),
    missions: {
      daily: {},
      weekly: {},
      global: {}
    },
    missionsStats: {
      dailyCompleted: 0,
      weeklyCompleted: 0,
      globalCompleted: 0
    }
  };

  await docClient.send(new PutCommand({
    TableName: USERS_TABLE,
    Item: user
  }));

  return userId;
}

async function setupMissions() {
  const missions = [
    {
      id: 'daily-play-3-games',
      type: 'daily',
      title: 'Play 3 Games',
      description: 'Play 3 games today',
      objective: 3,
      reward: 100,
      rewardType: 'points'
    },
    {
      id: 'weekly-play-5-games',
      type: 'weekly',
      title: 'Play 5 Games',
      description: 'Play 5 games this week',
      objective: 5,
      reward: 200,
      rewardType: 'points'
    }
  ];

  for (const mission of missions) {
    await docClient.send(new PutCommand({
      TableName: MISSIONS_TABLE,
      Item: mission
    }));
  }
}

async function updateUserStats(userId, gameCount = 1, jwtToken) {
  const response = await fetch('https://h1t1o3lrjj.execute-api.us-east-2.amazonaws.com/dev2/user/update-stats', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${jwtToken}`
    },
    body: JSON.stringify({
      id: userId,
      score: 100,
      words: ['test'],
      level: 1,
      won: false
    })
  });
  return response.json();
}

async function getUserMissions(userId, jwtToken) {
  const response = await fetch(
    `https://h1t1o3lrjj.execute-api.us-east-2.amazonaws.com/dev2/user/missions?id=${userId}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${jwtToken}`
      }
    }
  );
  return response.json();
}

async function runTest() {
  try {
    // Create a new test user
    const userId = await createTestUser();
    const testJWT = jwt.sign({ id: userId }, process.env.JWT_SECRET);
    console.log('Testing with user:', userId);

    // Initial mission state
    console.log('\nInitial mission state:');
    const initialMissions = await getUserMissions(userId, testJWT);
    console.log('User ID used for missions fetch:', userId);
    console.log('Raw response from /user/missions:', JSON.stringify(initialMissions, null, 2));

    for (let i = 1; i <= 5; i++) {
      console.log(`\nPlaying game #${i}...`);
      await updateUserStats(userId, 1, testJWT);
      const afterGame = await getUserMissions(userId, testJWT);
      console.log(`User ID used for missions fetch after game #${i}:`, userId);
      console.log(`Raw response from /user/missions after game #${i}:`, JSON.stringify(afterGame, null, 2));
      console.log(`Missions after game #${i}:`);
      console.log(JSON.stringify(afterGame, null, 2));
    }
  } catch (error) {
    console.error('Test failed:', error);
  }
}

runTest(); 