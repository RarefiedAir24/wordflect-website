const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-1' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function listProdUsersCorrect() {
  try {
    console.log('Listing all users in PRODUCTION table (us-east-1)...');
    
    const scanResult = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-users'
    }));
    
    if (scanResult.Items && scanResult.Items.length > 0) {
      console.log(`Found ${scanResult.Items.length} users:`);
      scanResult.Items.forEach((user, index) => {
        console.log(`\n${index + 1}. User:`);
        console.log(`   ID: ${user.id}`);
        console.log(`   Username: ${user.username}`);
        console.log(`   Email: ${user.email}`);
        console.log(`   Has password: ${!!user.password}`);
        if (user.createdAt) {
          console.log(`   Created: ${user.createdAt}`);
        }
        if (user.highestLevel) {
          console.log(`   Highest Level: ${user.highestLevel}`);
        }
      });
    } else {
      console.log('No users found in PRODUCTION table');
    }
    
  } catch (error) {
    console.error('Error listing users:', error);
  }
}

listProdUsersCorrect();
