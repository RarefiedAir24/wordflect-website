const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

function getTodayDateString() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getWordList() {
  const words = [
    'apple', 'banana', 'cherry', 'dragon', 'eagle', 'forest', 'garden', 'harbor', 'island', 'jungle',
    'knight', 'lemon', 'mountain', 'ocean', 'planet', 'queen', 'river', 'sunset', 'tiger', 'umbrella',
    'village', 'window', 'yellow', 'zebra', 'anchor', 'bridge', 'castle', 'diamond', 'eclipse', 'freedom',
    'galaxy', 'horizon', 'infinity', 'journey', 'kingdom', 'liberty', 'miracle', 'nature', 'oasis', 'paradise',
    'quartz', 'rainbow', 'silence', 'treasure', 'universe', 'victory', 'wisdom', 'xenon', 'yearning', 'zenith'
  ];
  return words.filter(w => w.length >= 4 && w.length <= 8 && /^[a-z]+$/.test(w));
}

async function setWordOfTheDay() {
  try {
    console.log('Setting word of the day for production...');
    
    const words = getWordList();
    if (!words.length) throw new Error('No valid words found');
    
    const randomWord = words[Math.floor(Math.random() * words.length)];
    const date = getTodayDateString();
    
    await dynamoDB.send(new PutCommand({
      TableName: 'wordflect-backend-word-of-the-day-prod',
      Item: { date, word: randomWord },
    }));
    
    console.log(`✅ Word of the day set for ${date}: ${randomWord}`);
    console.log('The Word of the Day card should now appear on the dashboard!');
    
  } catch (error) {
    console.error('Error setting word of the day:', error);
  }
}

setWordOfTheDay();
