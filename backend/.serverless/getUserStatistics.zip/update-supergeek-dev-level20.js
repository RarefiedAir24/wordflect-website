const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function updateSupergeekDevLevel20() {
  try {
    console.log('Updating supergeek@me.com dev user profile to level 20...');
    
    // Update the dev user profile with level 20 and realistic stats
    const updateResult = await dynamoDB.send(new UpdateCommand({
      TableName: 'wordflect-backend-users-dev',
      Key: { id: 'f3c070f2-453e-4ecd-9603-a7080b8b46da' },
      UpdateExpression: 'SET username = :username, highestLevel = :highestLevel, gems = :gems, flectcoins = :flectcoins, profileImageUrl = :profileImageUrl',
      ExpressionAttributeValues: {
        ':username': 'RarefiedAir24',
        ':highestLevel': 20,  // Restored to your actual level
        ':gems': 5000,        // More realistic gems for level 20
        ':flectcoins': 3000,  // More realistic flectcoins for level 20
        ':profileImageUrl': 'https://wordflect-profile-images.s3.amazonaws.com/profile-images/RarefiedAir24.jpg' // Placeholder for profile image
      }
    }));
    
    console.log('✅ Dev user profile updated to level 20!');
    console.log('Username: RarefiedAir24');
    console.log('Level: 20');
    console.log('Gems: 5000');
    console.log('Flectcoins: 3000');
    console.log('Profile Image: Restored placeholder');
    
  } catch (error) {
    console.error('Error updating dev user profile:', error);
  }
}

updateSupergeekDevLevel20();
