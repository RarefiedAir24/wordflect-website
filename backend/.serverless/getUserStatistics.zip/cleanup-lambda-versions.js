const { LambdaClient, ListVersionsByFunctionCommand, DeleteFunctionCommand } = require('@aws-sdk/client-lambda');

const lambda = new LambdaClient({ region: 'us-east-2' });

async function cleanupFunctionVersions(functionName) {
  try {
    // List all versions
    const versions = await lambda.send(new ListVersionsByFunctionCommand({
      FunctionName: functionName
    }));

    // Get the latest version
    const latestVersion = versions.Versions.reduce((latest, current) => {
      return parseInt(current.Version) > parseInt(latest.Version) ? current : latest;
    }, versions.Versions[0]);

    console.log(`\nProcessing ${functionName}:`);
    console.log(`Latest version: ${latestVersion.Version}`);

    // Delete all versions except the latest
    for (const version of versions.Versions) {
      if (version.Version !== latestVersion.Version && version.Version !== '$LATEST') {
        console.log(`Deleting version ${version.Version}...`);
        await lambda.send(new DeleteFunctionCommand({
          FunctionName: functionName,
          Qualifier: version.Version
        }));
      }
    }
  } catch (error) {
    console.error(`Error processing ${functionName}:`, error.message);
  }
}

async function main() {
  const functions = [
    'wordflect-backend-dev-missionRewards',
    'wordflect-backend-dev-updateUserStats',
    'wordflect-backend-dev-setWordOfTheDay',
    'wordflect-backend-dev-getWordOfTheDay',
    'wordflect-backend-dev-signin',
    'wordflect-backend-dev-updateProfileImage',
    'wordflect-backend-dev-completeUserMission',
    'wordflect-backend-dev-selectUserFrame',
    'wordflect-backend-dev-signup',
    'wordflect-backend-dev-getWordDefinition',
    'wordflect-backend-dev-requestPasswordReset',
    'wordflect-backend-dev-checkEmail',
    'wordflect-backend-dev-resetPassword',
    'wordflect-backend-dev-getUserProfile',
    'wordflect-backend-dev-getProfileImageUploadUrl',
    'wordflect-backend-dev-getLeaderboard',
    'wordflect-backend-dev-getUserFrames',
    'wordflect-backend-dev-getUserMissions'
  ];

  console.log('Starting Lambda version cleanup...');
  
  for (const functionName of functions) {
    await cleanupFunctionVersions(functionName);
  }

  console.log('\nCleanup completed!');
}

main().catch(console.error); 