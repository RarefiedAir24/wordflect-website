const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function updateSupergeekDevProfile() {
  try {
    console.log('Updating supergeek@me.com dev user profile...');
    
    // Update the dev user profile with correct username and restored progress
    const updateResult = await dynamoDB.send(new UpdateCommand({
      TableName: 'wordflect-backend-users-dev',
      Key: { id: 'f3c070f2-453e-4ecd-9603-a7080b8b46da' },
      UpdateExpression: 'SET username = :username, highestLevel = :highestLevel, gems = :gems, flectcoins = :flectcoins',
      ExpressionAttributeValues: {
        ':username': 'RarefiedAir24',
        ':highestLevel': 15,  // Restored to a reasonable level
        ':gems': 2500,        // Restored gems
        ':flectcoins': 1500   // Restored flectcoins
      }
    }));
    
    console.log('✅ Dev user profile updated successfully!');
    console.log('Username: RarefiedAir24');
    console.log('Level: 15');
    console.log('Gems: 2500');
    console.log('Flectcoins: 1500');
    
  } catch (error) {
    console.error('Error updating dev user profile:', error);
  }
}

updateSupergeekDevProfile();
