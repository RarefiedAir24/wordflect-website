const bcrypt = require('bcryptjs');

// Test the password hash we just created
async function testVitabSignin() {
  try {
    console.log('Testing vitab sign-in...');
    
    // The password hash from the database
    const storedHash = '$2b$10$BOY5TEcCX7rfs...'; // This is truncated, we need the full hash
    
    // Test password
    const testPassword = 'Stella';
    
    console.log('Testing password:', testPassword);
    
    // We need to get the full hash from the database
    const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
    const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
    
    const client = new DynamoDBClient({ region: 'us-east-2' });
    const dynamoDB = DynamoDBDocumentClient.from(client);
    
    const result = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-users-prod',
      FilterExpression: 'email = :email',
      ExpressionAttributeValues: {
        ':email': 'vitab@aol.com'
      }
    }));
    
    if (result.Items && result.Items.length > 0) {
      const user = result.Items[0];
      console.log('Full password hash:', user.password);
      
      // Test the password comparison
      const isMatch = await bcrypt.compare(testPassword, user.password);
      console.log('Password match result:', isMatch);
      
      if (isMatch) {
        console.log('✅ Password verification successful!');
      } else {
        console.log('❌ Password verification failed!');
      }
    } else {
      console.log('User not found');
    }
    
  } catch (error) {
    console.error('Error testing sign-in:', error);
  }
}

testVitabSignin(); 