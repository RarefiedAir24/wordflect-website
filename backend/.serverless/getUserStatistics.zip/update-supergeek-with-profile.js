const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function updateSupergeekWithProfile() {
  try {
    console.log('Updating supergeek@me.com user profile with correct profile image...');
    
    // Update the user profile with the correct profile image URL
    const updateResult = await dynamoDB.send(new UpdateCommand({
      TableName: 'wordflect-backend-users-prod',
      Key: { id: 'd59de7c3-9c83-41c9-87bf-a73b87048ff3' },
      UpdateExpression: 'SET profileImageUrl = :profileImageUrl',
      ExpressionAttributeValues: {
        ':profileImageUrl': 'https://wordflect-profile-images.s3.amazonaws.com/profile-images/RarefiedAir24.jpg'
      }
    }));
    
    console.log('✅ User profile updated with correct profile image!');
    console.log('Profile Image URL: https://wordflect-profile-images.s3.amazonaws.com/profile-images/RarefiedAir24.jpg');
    console.log('\nYour profile is now fully restored:');
    console.log('Username: RarefiedAir24');
    console.log('Level: 20');
    console.log('Gems: 5000');
    console.log('Flectcoins: 3000');
    console.log('Profile Image: ✅ Restored');
    
  } catch (error) {
    console.error('Error updating user profile:', error);
  }
}

updateSupergeekWithProfile();
