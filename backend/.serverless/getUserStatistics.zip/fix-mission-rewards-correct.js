const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function fixMissionRewardsCorrect() {
  console.log('🔧 Fixing mission rewards with correct structure...\n');
  
  try {
    // First, get all existing missions
    const result = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-missions-prod'
    }));
    
    console.log(`📊 Found ${result.Items.length} existing missions to update\n`);
    
    // Define correct mission rewards (daily/weekly = flectcoins only, special/global = gems)
    const missionRewards = {
      // DAILY MISSIONS - FLECTCOINS ONLY
      'daily-play-1-game-today': { flectcoins: 10, gems: 0, tier: 'Daily Basics' },
      'daily-score-100-points': { flectcoins: 15, gems: 0, tier: 'Daily Basics' },
      'daily-complete-game-without-hints': { flectcoins: 25, gems: 0, tier: 'Daily Challenges' },
      'daily-find-a-long-word': { flectcoins: 20, gems: 0, tier: 'Daily Challenges' },
      'daily-find-3-long-words': { flectcoins: 30, gems: 0, tier: 'Daily Challenges' },
      'daily-find-the-word-of-the-day': { flectcoins: 50, gems: 25, tier: 'Daily Special' }, // SPECIAL - GIVES GEMS
      
      // Daily word-finding missions (progressive rewards) - FLECTCOINS ONLY
      'daily-find-10-words': { flectcoins: 10, gems: 0, tier: 'Daily Basics' },
      'daily-find-20-words': { flectcoins: 15, gems: 0, tier: 'Daily Basics' },
      'daily-find-30-words': { flectcoins: 20, gems: 0, tier: 'Daily Basics' },
      'daily-find-40-words': { flectcoins: 25, gems: 0, tier: 'Daily Basics' },
      'daily-find-50-words': { flectcoins: 30, gems: 0, tier: 'Daily Basics' },
      'daily-find-60-words': { flectcoins: 35, gems: 0, tier: 'Daily Challenges' },
      'daily-find-70-words': { flectcoins: 40, gems: 0, tier: 'Daily Challenges' },
      'daily-find-80-words': { flectcoins: 45, gems: 0, tier: 'Daily Challenges' },
      'daily-find-90-words': { flectcoins: 50, gems: 0, tier: 'Daily Challenges' },
      'daily-find-100-words': { flectcoins: 55, gems: 0, tier: 'Daily Challenges' },
      'daily-find-120-words': { flectcoins: 60, gems: 0, tier: 'Daily Challenges' },
      'daily-find-140-words': { flectcoins: 65, gems: 0, tier: 'Daily Challenges' },
      'daily-find-160-words': { flectcoins: 70, gems: 0, tier: 'Daily Challenges' },
      'daily-find-180-words': { flectcoins: 75, gems: 0, tier: 'Daily Challenges' },
      'daily-find-200-words': { flectcoins: 80, gems: 0, tier: 'Daily Challenges' },
      
      // Daily scoring missions - FLECTCOINS ONLY
      'daily-score-200-points': { flectcoins: 25, gems: 0, tier: 'Daily Challenges' },
      'daily-play-3-games': { flectcoins: 20, gems: 0, tier: 'Daily Challenges' },
      
      // WEEKLY MISSIONS - FLECTCOINS ONLY
      'weekly-play-5-games': { flectcoins: 50, gems: 0, tier: 'Weekly Basics' },
      'weekly-score-500-points': { flectcoins: 60, gems: 0, tier: 'Weekly Basics' },
      'weekly-score-1000-points': { flectcoins: 80, gems: 0, tier: 'Weekly Challenges' },
      'weekly-complete-5-games-without-hints': { flectcoins: 100, gems: 0, tier: 'Weekly Challenges' },
      'weekly-play-every-day': { flectcoins: 120, gems: 0, tier: 'Weekly Challenges' },
      'weekly-find-the-word-of-the-day-7-days-in-a-row': { flectcoins: 150, gems: 75, tier: 'Weekly Special' }, // SPECIAL - GIVES GEMS
      'weekly-score-2000-points': { flectcoins: 100, gems: 0, tier: 'Weekly Challenges' },
      'weekly-play-10-games': { flectcoins: 80, gems: 0, tier: 'Weekly Challenges' },
      
      // GLOBAL MISSIONS - GEMS ONLY (milestones)
      'global-reach-level-10': { flectcoins: 0, gems: 100, tier: 'Level Milestones' },
      'global-reach-level-25': { flectcoins: 0, gems: 250, tier: 'Level Milestones' },
      'global-reach-level-50': { flectcoins: 0, gems: 500, tier: 'Level Milestones' },
      'global-play-100-games': { flectcoins: 0, gems: 150, tier: 'Gameplay Milestones' },
      'global-find-1000-words': { flectcoins: 0, gems: 200, tier: 'Word Finding Milestones' },
      'global-find-5000-words': { flectcoins: 0, gems: 500, tier: 'Word Finding Milestones' },
      'global-score-10000-points': { flectcoins: 0, gems: 300, tier: 'Scoring Milestones' },
      'global-maintain-7-day-login-streak': { flectcoins: 0, gems: 75, tier: 'Login Milestones' }
    };
    
    let updatedCount = 0;
    let errorCount = 0;
    
    // Update each mission
    for (const mission of result.Items) {
      const missionId = mission.id;
      const rewards = missionRewards[missionId];
      
      if (rewards) {
        try {
          const updatedMission = {
            ...mission,
            flectcoins: rewards.flectcoins,
            gems: rewards.gems,
            tier: rewards.tier
          };
          
          await dynamoDB.send(new PutCommand({
            TableName: 'wordflect-backend-missions-prod',
            Item: updatedMission
          }));
          
          console.log(`✅ Updated: ${mission.title}`);
          console.log(`   Flectcoins: ${rewards.flectcoins}, Gems: ${rewards.gems}, Tier: ${rewards.tier}`);
          updatedCount++;
        } catch (error) {
          console.error(`❌ Error updating ${mission.title}:`, error.message);
          errorCount++;
        }
      } else {
        console.log(`⚠️ No rewards defined for: ${mission.title} (${missionId})`);
      }
    }
    
    console.log('\n📊 UPDATE SUMMARY:');
    console.log('==================');
    console.log(`✅ Successfully updated: ${updatedCount} missions`);
    console.log(`❌ Errors: ${errorCount} missions`);
    console.log(`⚠️ Missing rewards: ${result.Items.length - updatedCount - errorCount} missions`);
    
    // Verify the updates
    console.log('\n🔍 Verifying updates...');
    const verifyResult = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-missions-prod'
    }));
    
    const missionsWithRewards = verifyResult.Items.filter(item => item.flectcoins !== undefined || item.gems !== undefined);
    const missionsWithoutRewards = verifyResult.Items.filter(item => item.flectcoins === undefined && item.gems === undefined);
    
    console.log(`✅ Missions with rewards: ${missionsWithRewards.length}`);
    console.log(`❌ Missions without rewards: ${missionsWithoutRewards.length}`);
    
    // Show summary by type
    const dailyMissions = verifyResult.Items.filter(item => item.type === 'daily');
    const weeklyMissions = verifyResult.Items.filter(item => item.type === 'weekly');
    const globalMissions = verifyResult.Items.filter(item => item.type === 'global');
    
    console.log('\n📊 REWARD SUMMARY BY TYPE:');
    console.log('==========================');
    console.log(`📅 Daily Missions: ${dailyMissions.length} (flectcoins only, except Word of Day)`);
    console.log(`📆 Weekly Missions: ${weeklyMissions.length} (flectcoins only, except 7-day streak)`);
    console.log(`🌍 Global Missions: ${globalMissions.length} (gems only - milestones)`);
    
    if (missionsWithoutRewards.length > 0) {
      console.log('\n⚠️ Missions still missing rewards:');
      missionsWithoutRewards.forEach(mission => {
        console.log(`   - ${mission.title} (${mission.id})`);
      });
    }
    
  } catch (error) {
    console.error('❌ Error fixing mission rewards:', error);
  }
}

fixMissionRewardsCorrect();
