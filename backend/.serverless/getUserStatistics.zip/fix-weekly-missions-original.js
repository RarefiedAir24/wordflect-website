const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, DeleteCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

function generateMissionId(type, title) {
  return `${type}-${title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}`;
}

async function fixWeeklyMissionsOriginal() {
  console.log('🔧 Fixing weekly missions with original structure and proper flectcoin rewards...\n');
  
  try {
    // First, get all existing weekly missions
    const result = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-missions-prod',
      FilterExpression: '#type = :type',
      ExpressionAttributeNames: { '#type': 'type' },
      ExpressionAttributeValues: { ':type': 'weekly' }
    }));
    
    console.log(`📊 Found ${result.Items.length} existing weekly missions to update\n`);
    
    // Delete existing weekly missions
    for (const mission of result.Items) {
      await dynamoDB.send(new DeleteCommand({
        TableName: 'wordflect-backend-missions-prod',
        Key: { id: mission.id }
      }));
    }
    
    console.log('🗑️ Deleted all existing weekly missions\n');
    
    // Define the correct weekly mission structure based on original design
    const weeklyMissions = [
      // Weekly Word Goals (word-finding missions)
      {
        id: generateMissionId('weekly', 'Find 500 Words'),
        type: 'weekly',
        title: 'Find 500 Words',
        description: 'Find 500 words this week',
        target: 500,
        objective: 'Find Words This Week',
        flectcoins: 500,
        gems: 0,
        tier: 'Weekly Word Goals',
        category: 'word-finding',
        sortOrder: 1
      },
      {
        id: generateMissionId('weekly', 'Find 750 Words'),
        type: 'weekly',
        title: 'Find 750 Words',
        description: 'Find 750 words this week',
        target: 750,
        objective: 'Find Words This Week',
        flectcoins: 750,
        gems: 0,
        tier: 'Weekly Word Goals',
        category: 'word-finding',
        sortOrder: 2
      },
      {
        id: generateMissionId('weekly', 'Find 1000 Words'),
        type: 'weekly',
        title: 'Find 1000 Words',
        description: 'Find 1000 words this week',
        target: 1000,
        objective: 'Find Words This Week',
        flectcoins: 1000,
        gems: 0,
        tier: 'Weekly Word Goals',
        category: 'word-finding',
        sortOrder: 3
      },
      
      // Weekly Score Goals (scoring missions)
      {
        id: generateMissionId('weekly', 'Score 500 Points'),
        type: 'weekly',
        title: 'Score 500 Points',
        description: 'Score 500 points this week',
        target: 500,
        objective: 'Score Points This Week',
        flectcoins: 100,
        gems: 0,
        tier: 'Weekly Score Goals',
        category: 'scoring',
        sortOrder: 4
      },
      {
        id: generateMissionId('weekly', 'Score 1000 Points'),
        type: 'weekly',
        title: 'Score 1000 Points',
        description: 'Score 1000 points this week',
        target: 1000,
        objective: 'Score Points This Week',
        flectcoins: 150,
        gems: 0,
        tier: 'Weekly Score Goals',
        category: 'scoring',
        sortOrder: 5
      },
      {
        id: generateMissionId('weekly', 'Score 2000 Points'),
        type: 'weekly',
        title: 'Score 2000 Points',
        description: 'Score 2000 points this week',
        target: 2000,
        objective: 'Score Points This Week',
        flectcoins: 250,
        gems: 0,
        tier: 'Weekly Score Goals',
        category: 'scoring',
        sortOrder: 6
      },
      
      // Weekly Challenges (gameplay missions)
      {
        id: generateMissionId('weekly', 'Play 5 Games'),
        type: 'weekly',
        title: 'Play 5 Games',
        description: 'Play 5 games this week',
        target: 5,
        objective: 'Play Games This Week',
        flectcoins: 50,
        gems: 0,
        tier: 'Weekly Challenges',
        category: 'gameplay',
        sortOrder: 7
      },
      {
        id: generateMissionId('weekly', 'Play 10 Games'),
        type: 'weekly',
        title: 'Play 10 Games',
        description: 'Play 10 games this week',
        target: 10,
        objective: 'Play Games This Week',
        flectcoins: 120,
        gems: 0,
        tier: 'Weekly Challenges',
        category: 'gameplay',
        sortOrder: 8
      },
      {
        id: generateMissionId('weekly', 'Play Every Day'),
        type: 'weekly',
        title: 'Play Every Day',
        description: 'Play at least one game every day this week',
        target: 7,
        objective: 'Play Every Day This Week',
        flectcoins: 300,
        gems: 0,
        tier: 'Weekly Challenges',
        category: 'gameplay',
        sortOrder: 9
      },
      {
        id: generateMissionId('weekly', 'Complete 5 Games Without Hints'),
        type: 'weekly',
        title: 'Complete 5 Games Without Hints',
        description: 'Complete 5 games without using any hints this week',
        target: 5,
        objective: 'Complete Games No Hints This Week',
        flectcoins: 200,
        gems: 0,
        tier: 'Weekly Challenges',
        category: 'gameplay',
        sortOrder: 10
      },
      {
        id: generateMissionId('weekly', 'Find 10 Long Words'),
        type: 'weekly',
        title: 'Find 10 Long Words',
        description: 'Find 10 words with 8 or more letters this week',
        target: 10,
        objective: 'Find Long Words This Week',
        flectcoins: 80,
        gems: 0,
        tier: 'Weekly Challenges',
        category: 'letter-specific',
        sortOrder: 11
      },
      
      // Weekly Special (special missions)
      {
        id: generateMissionId('weekly', 'Find the Word of the Day 7 Days in a Row'),
        type: 'weekly',
        title: 'Find the Word of the Day 7 Days in a Row',
        description: 'Find the word of the day for 7 consecutive days',
        target: 7,
        objective: 'Find Word of the Day 7 Days This Week',
        flectcoins: 150,
        gems: 75,
        tier: 'Weekly Special',
        category: 'special',
        sortOrder: 12
      }
    ];
    
    // Add all weekly missions to the database
    for (const mission of weeklyMissions) {
      await dynamoDB.send(new PutCommand({
        TableName: 'wordflect-backend-missions-prod',
        Item: mission
      }));
      console.log(`✅ Added: ${mission.title} (${mission.tier}) - ${mission.flectcoins} flectcoins, ${mission.gems} gems`);
    }
    
    console.log('\n📊 WEEKLY MISSION STRUCTURE SUMMARY:');
    console.log('=====================================');
    console.log(`📆 Total Weekly Missions: ${weeklyMissions.length}`);
    
    // Group by tier
    const weeklyWordGoals = weeklyMissions.filter(m => m.tier === 'Weekly Word Goals');
    const weeklyScoreGoals = weeklyMissions.filter(m => m.tier === 'Weekly Score Goals');
    const weeklyChallenges = weeklyMissions.filter(m => m.tier === 'Weekly Challenges');
    const weeklySpecial = weeklyMissions.filter(m => m.tier === 'Weekly Special');
    
    console.log('\n📚 WEEKLY MISSION TIERS:');
    console.log('========================');
    console.log(`   Weekly Word Goals: ${weeklyWordGoals.length} missions`);
    weeklyWordGoals.forEach(m => console.log(`     - ${m.title}: ${m.flectcoins} flectcoins`));
    
    console.log(`\n   Weekly Score Goals: ${weeklyScoreGoals.length} missions`);
    weeklyScoreGoals.forEach(m => console.log(`     - ${m.title}: ${m.flectcoins} flectcoins`));
    
    console.log(`\n   Weekly Challenges: ${weeklyChallenges.length} missions`);
    weeklyChallenges.forEach(m => console.log(`     - ${m.title}: ${m.flectcoins} flectcoins`));
    
    console.log(`\n   Weekly Special: ${weeklySpecial.length} missions`);
    weeklySpecial.forEach(m => console.log(`     - ${m.title}: ${m.flectcoins} flectcoins, ${m.gems} gems`));
    
    console.log('\n💰 WEEKLY REWARD STRUCTURE:');
    console.log('===========================');
    console.log('   Word-finding missions: flectcoins = word count (500, 750, 1000)');
    console.log('   Scoring missions: flectcoins based on difficulty (100, 150, 250)');
    console.log('   Gameplay missions: flectcoins based on difficulty (50-300)');
    console.log('   Special missions: both flectcoins and gems');
    
  } catch (error) {
    console.error('❌ Error fixing weekly missions:', error);
  }
}

fixWeeklyMissionsOriginal();
