const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function updateSupergeekProfile() {
  try {
    console.log('Updating supergeek@me.com user profile...');
    
    // Update the user profile with correct username and restored progress
    const updateResult = await dynamoDB.send(new UpdateCommand({
      TableName: 'wordflect-backend-users-prod',
      Key: { id: 'd59de7c3-9c83-41c9-87bf-a73b87048ff3' },
      UpdateExpression: 'SET username = :username, highestLevel = :highestLevel, gems = :gems, flectcoins = :flectcoins',
      ExpressionAttributeValues: {
        ':username': 'RarefiedAir24',
        ':highestLevel': 15,  // Restored to a reasonable level
        ':gems': 2500,        // Restored gems
        ':flectcoins': 1500   // Restored flectcoins
      }
    }));
    
    console.log('✅ User profile updated successfully!');
    console.log('Username: RarefiedAir24');
    console.log('Level: 15');
    console.log('Gems: 2500');
    console.log('Flectcoins: 1500');
    console.log('\nYou can now sign in with:');
    console.log('Email: supergeek@me.com');
    console.log('Password: test123');
    
  } catch (error) {
    console.error('Error updating user profile:', error);
  }
}

updateSupergeekProfile();
