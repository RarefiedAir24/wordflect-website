const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function giveAllFramesAccess() {
  try {
    console.log('Giving Pro user access to ALL frames...');
    
    // ALL frames in the system - Pro users get everything!
    const allFrames = [
      // Default frames
      'spiked-steel',
      'ice-crystal',
      
      // Level-based frames
      'heart-gold',
      'skull-bone',
      'blue-spikes',
      'wood-diamonds',
      'fire-frame',
      'halo',
      'blue-diamonds',
      'dark-bling',
      'galaxy-frame',
      'vine-frame',
      'cyber-frame',
      'ice-shard',
      'gradient-diamond',
      'dragon-frame',
      
      // Battle-based frames
      'wings',
      'empress',
      
      // Premium frames
      'crystal-crown',
      'phoenix-reign'
    ];
    
    // Update the user profile with ALL frames unlocked
    const updateResult = await dynamoDB.send(new UpdateCommand({
      TableName: 'wordflect-backend-users-prod',
      Key: { id: 'd59de7c3-9c83-41c9-87bf-a73b87048ff3' },
      UpdateExpression: 'SET unlockedFrames = :unlockedFrames, selectedFrame = :selectedFrame',
      ExpressionAttributeValues: {
        ':unlockedFrames': allFrames,
        ':selectedFrame': 'phoenix-reign' // Keep the Pro frame as selected
      }
    }));
    
    console.log('✅ Pro user now has access to ALL frames!');
    console.log('Total frames unlocked:', allFrames.length);
    console.log('Selected frame: Phoenix Reign (Pro)');
    console.log('\nFrame categories unlocked:');
    console.log('- Default frames (2)');
    console.log('- Level-based frames (16)');
    console.log('- Battle-based frames (2)');
    console.log('- Premium frames (2)');
    console.log('\nTotal: 22 frames available!');
    
  } catch (error) {
    console.error('Error giving all frames access:', error);
  }
}

giveAllFramesAccess();
