const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function updateUserWithFrames() {
  try {
    console.log('Updating user profile with unlocked frames...');
    
    // Frames that should be unlocked at level 20
    const unlockedFrames = [
      'spiked-steel',    // Default
      'ice-crystal',     // Default
      'heart-gold',      // Level 5
      'skull-bone',      // Level 5
      'blue-spikes',     // Level 5
      'wood-diamonds',   // Level 8
      'fire-frame',      // Level 5
      'halo',           // Level 10
      'blue-diamonds',   // Level 15
      'dark-bling',      // Level 18
      'galaxy-frame',    // Level 12
      'vine-frame',      // Level 15
      'cyber-frame',     // Level 18
      'ice-shard',       // Level 20
      'gradient-diamond' // Level 20
    ];
    
    // Update the user profile with unlocked frames
    const updateResult = await dynamoDB.send(new UpdateCommand({
      TableName: 'wordflect-backend-users-prod',
      Key: { id: 'd59de7c3-9c83-41c9-87bf-a73b87048ff3' },
      UpdateExpression: 'SET unlockedFrames = :unlockedFrames, selectedFrame = :selectedFrame',
      ExpressionAttributeValues: {
        ':unlockedFrames': unlockedFrames,
        ':selectedFrame': 'ice-shard' // Set a cool frame as selected
      }
    }));
    
    console.log('✅ User profile updated with unlocked frames!');
    console.log('Unlocked frames:', unlockedFrames.length);
    console.log('Selected frame: Ice Shard');
    console.log('\nFrames you can access:');
    unlockedFrames.forEach(frameId => {
      console.log(`- ${frameId}`);
    });
    
  } catch (error) {
    console.error('Error updating user with frames:', error);
  }
}

updateUserWithFrames();
