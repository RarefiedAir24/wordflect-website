const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, DeleteCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

const MISSIONS_TABLE = 'wordflect-backend-missions-prod';

async function removeDailyThemeMission() {
  try {
    console.log('🗑️ Removing problematic "Find Daily Theme Words" mission...\n');
    
    // Find the daily theme mission
    const { Items: missions } = await dynamoDB.send(new ScanCommand({
      TableName: MISSIONS_TABLE,
      FilterExpression: 'title = :title AND #type = :type',
      ExpressionAttributeNames: {
        '#type': 'type'
      },
      ExpressionAttributeValues: {
        ':title': 'Find Daily Theme Words',
        ':type': 'daily'
      }
    }));

    if (missions.length === 0) {
      console.log('❌ "Find Daily Theme Words" mission not found');
      return;
    }

    console.log(`📋 Found ${missions.length} mission(s) to remove:`);
    missions.forEach(mission => {
      console.log(`   - Title: ${mission.title}`);
      console.log(`   - Type: ${mission.type}`);
      console.log(`   - Tier: ${mission.tier}`);
      console.log(`   - ID: ${mission.id}`);
      console.log(`   - Reward: ${mission.reward?.amount || 0} ${mission.reward?.type || 'none'}`);
      console.log('');
    });

    // Delete the mission(s)
    for (const mission of missions) {
      await dynamoDB.send(new DeleteCommand({
        TableName: MISSIONS_TABLE,
        Key: { id: mission.id }
      }));
      console.log(`✅ Removed: ${mission.title} (${mission.id})`);
    }

    console.log('\n🎉 SUCCESS: "Find Daily Theme Words" mission removed!');
    console.log('📊 This eliminates the bug where it was tracking all found words instead of only theme words');
    console.log('🎯 Theme word progress is still tracked in the Daily Theme section of the game');

  } catch (error) {
    console.error('❌ Error removing daily theme mission:', error);
  }
}

// Run the removal
removeDailyThemeMission()
  .then(() => {
    console.log('\n✅ Script completed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Script failed:', error);
    process.exit(1);
  });
