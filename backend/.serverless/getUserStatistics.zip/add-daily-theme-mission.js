const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, ScanCommand, DeleteCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

const MISSIONS_TABLE = 'wordflect-backend-missions-prod';

function generateMissionId(type, title) {
  return `${type}-${title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}`;
}

async function addDailyThemeMission() {
  try {
    console.log('🎯 Adding daily theme mission to production database...\n');
    
    // First, check if a theme mission already exists
    const existingResult = await dynamoDB.send(new ScanCommand({
      TableName: MISSIONS_TABLE,
      FilterExpression: 'contains(#title, :theme) OR contains(#description, :theme)',
      ExpressionAttributeNames: {
        '#title': 'title',
        '#description': 'description'
      },
      ExpressionAttributeValues: {
        ':theme': 'theme'
      }
    }));
    
    // Delete existing theme missions if any
    if (existingResult.Items && existingResult.Items.length > 0) {
      console.log(`🗑️  Found ${existingResult.Items.length} existing theme missions, removing...`);
      for (const mission of existingResult.Items) {
        await dynamoDB.send(new DeleteCommand({
          TableName: MISSIONS_TABLE,
          Key: { id: mission.id }
        }));
        console.log(`   - Removed: ${mission.title}`);
      }
    }
    
    // Create new daily theme mission for 20 words
    const dailyThemeMission = {
      id: generateMissionId('daily', 'Find Daily Theme Words'),
      type: 'daily',
      title: 'Find Daily Theme Words',
      description: 'Find words from today\'s daily theme. Complete the theme to earn bonus flectcoins!',
      target: 20,
      objective: 'Find Daily Theme Words',
      reward: { type: 'flectcoins', amount: 150 },
      tier: 'Daily Special',
      category: 'theme',
      sortOrder: 1,
      isThemeMission: true
    };
    
    // Add the mission to the database
    await dynamoDB.send(new PutCommand({
      TableName: MISSIONS_TABLE,
      Item: dailyThemeMission
    }));
    
    console.log('✅ Added daily theme mission:');
    console.log(`   - Title: ${dailyThemeMission.title}`);
    console.log(`   - Target: ${dailyThemeMission.target} words`);
    console.log(`   - Reward: ${dailyThemeMission.reward.amount} ${dailyThemeMission.reward.type}`);
    console.log(`   - Tier: ${dailyThemeMission.tier}`);
    
    console.log('\n🎉 Daily theme mission successfully added to production database!');
    
  } catch (error) {
    console.error('Error adding daily theme mission:', error);
  }
}

addDailyThemeMission();
