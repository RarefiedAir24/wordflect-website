const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, DeleteCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

function generateMissionId(type, title) {
  return `${type}-${title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}`;
}

async function fixMissionsOriginalStructure() {
  console.log('🔧 Restoring original mission structure with proper tiers and flectcoin rewards...\n');
  
  try {
    // First, get all existing missions
    const result = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-missions-prod'
    }));
    
    console.log(`📊 Found ${result.Items.length} existing missions to update\n`);
    
    // Delete all existing missions
    for (const mission of result.Items) {
      await dynamoDB.send(new DeleteCommand({
        TableName: 'wordflect-backend-missions-prod',
        Key: { id: mission.id }
      }));
    }
    
    console.log('🗑️ Deleted all existing missions\n');
    
    // Define the correct mission structure
    const missions = [
      // DAILY MISSIONS
      
      // Tier 1: Easy (10, 15, 20, 25 words)
      {
        id: generateMissionId('daily', 'Find 10 Words'),
        type: 'daily',
        title: 'Find 10 Words',
        description: 'Find 10 words today',
        target: 10,
        objective: 'Find X Words Today',
        flectcoins: 10,
        gems: 0,
        tier: 'Tier 1: Easy',
        category: 'word-finding',
        sortOrder: 1
      },
      {
        id: generateMissionId('daily', 'Find 15 Words'),
        type: 'daily',
        title: 'Find 15 Words',
        description: 'Find 15 words today',
        target: 15,
        objective: 'Find X Words Today',
        flectcoins: 15,
        gems: 0,
        tier: 'Tier 1: Easy',
        category: 'word-finding',
        sortOrder: 2
      },
      {
        id: generateMissionId('daily', 'Find 20 Words'),
        type: 'daily',
        title: 'Find 20 Words',
        description: 'Find 20 words today',
        target: 20,
        objective: 'Find X Words Today',
        flectcoins: 20,
        gems: 0,
        tier: 'Tier 1: Easy',
        category: 'word-finding',
        sortOrder: 3
      },
      {
        id: generateMissionId('daily', 'Find 25 Words'),
        type: 'daily',
        title: 'Find 25 Words',
        description: 'Find 25 words today',
        target: 25,
        objective: 'Find X Words Today',
        flectcoins: 25,
        gems: 0,
        tier: 'Tier 1: Easy',
        category: 'word-finding',
        sortOrder: 4
      },
      
      // Tier 2: Medium (30, 40, 50 words)
      {
        id: generateMissionId('daily', 'Find 30 Words'),
        type: 'daily',
        title: 'Find 30 Words',
        description: 'Find 30 words today',
        target: 30,
        objective: 'Find X Words Today',
        flectcoins: 30,
        gems: 0,
        tier: 'Tier 2: Medium',
        category: 'word-finding',
        sortOrder: 5
      },
      {
        id: generateMissionId('daily', 'Find 40 Words'),
        type: 'daily',
        title: 'Find 40 Words',
        description: 'Find 40 words today',
        target: 40,
        objective: 'Find X Words Today',
        flectcoins: 40,
        gems: 0,
        tier: 'Tier 2: Medium',
        category: 'word-finding',
        sortOrder: 6
      },
      {
        id: generateMissionId('daily', 'Find 50 Words'),
        type: 'daily',
        title: 'Find 50 Words',
        description: 'Find 50 words today',
        target: 50,
        objective: 'Find X Words Today',
        flectcoins: 50,
        gems: 0,
        tier: 'Tier 2: Medium',
        category: 'word-finding',
        sortOrder: 7
      },
      
      // Tier 3: Hard (75, 100, 125 words)
      {
        id: generateMissionId('daily', 'Find 75 Words'),
        type: 'daily',
        title: 'Find 75 Words',
        description: 'Find 75 words today',
        target: 75,
        objective: 'Find X Words Today',
        flectcoins: 75,
        gems: 0,
        tier: 'Tier 3: Hard',
        category: 'word-finding',
        sortOrder: 8
      },
      {
        id: generateMissionId('daily', 'Find 100 Words'),
        type: 'daily',
        title: 'Find 100 Words',
        description: 'Find 100 words today',
        target: 100,
        objective: 'Find X Words Today',
        flectcoins: 100,
        gems: 0,
        tier: 'Tier 3: Hard',
        category: 'word-finding',
        sortOrder: 9
      },
      {
        id: generateMissionId('daily', 'Find 125 Words'),
        type: 'daily',
        title: 'Find 125 Words',
        description: 'Find 125 words today',
        target: 125,
        objective: 'Find X Words Today',
        flectcoins: 125,
        gems: 0,
        tier: 'Tier 3: Hard',
        category: 'word-finding',
        sortOrder: 10
      },
      
      // Tier 4: Expert (150, 200 words)
      {
        id: generateMissionId('daily', 'Find 150 Words'),
        type: 'daily',
        title: 'Find 150 Words',
        description: 'Find 150 words today',
        target: 150,
        objective: 'Find X Words Today',
        flectcoins: 150,
        gems: 0,
        tier: 'Tier 4: Expert',
        category: 'word-finding',
        sortOrder: 11
      },
      {
        id: generateMissionId('daily', 'Find 200 Words'),
        type: 'daily',
        title: 'Find 200 Words',
        description: 'Find 200 words today',
        target: 200,
        objective: 'Find X Words Today',
        flectcoins: 200,
        gems: 0,
        tier: 'Tier 4: Expert',
        category: 'word-finding',
        sortOrder: 12
      },
      
      // Other daily missions
      {
        id: generateMissionId('daily', 'Play 1 Game Today'),
        type: 'daily',
        title: 'Play 1 Game Today',
        description: 'Play at least one game today',
        target: 1,
        objective: 'Play Games Today',
        flectcoins: 10,
        gems: 0,
        tier: 'Daily Basics',
        category: 'gameplay',
        sortOrder: 13
      },
      {
        id: generateMissionId('daily', 'Score 100 Points'),
        type: 'daily',
        title: 'Score 100 Points',
        description: 'Score 100 points today',
        target: 100,
        objective: 'Score Points Today',
        flectcoins: 15,
        gems: 0,
        tier: 'Daily Basics',
        category: 'scoring',
        sortOrder: 14
      },
      {
        id: generateMissionId('daily', 'Complete Game Without Hints'),
        type: 'daily',
        title: 'Complete Game Without Hints',
        description: 'Complete a game without using any hints',
        target: 1,
        objective: 'Complete Games No Hints Today',
        flectcoins: 25,
        gems: 0,
        tier: 'Daily Challenges',
        category: 'gameplay',
        sortOrder: 15
      },
      {
        id: generateMissionId('daily', 'Find a Long Word'),
        type: 'daily',
        title: 'Find a Long Word',
        description: 'Find a word with 8 or more letters',
        target: 1,
        objective: 'Find Long Words Today',
        flectcoins: 20,
        gems: 0,
        tier: 'Daily Challenges',
        category: 'word-finding',
        sortOrder: 16
      },
      {
        id: generateMissionId('daily', 'Find 3 Long Words'),
        type: 'daily',
        title: 'Find 3 Long Words',
        description: 'Find 3 words with 8 or more letters',
        target: 3,
        objective: 'Find Long Words Today',
        flectcoins: 30,
        gems: 0,
        tier: 'Daily Challenges',
        category: 'word-finding',
        sortOrder: 17
      },
      {
        id: generateMissionId('daily', 'Play 3 Games'),
        type: 'daily',
        title: 'Play 3 Games',
        description: 'Play 3 games today',
        target: 3,
        objective: 'Play Games Today',
        flectcoins: 20,
        gems: 0,
        tier: 'Daily Challenges',
        category: 'gameplay',
        sortOrder: 18
      },
      {
        id: generateMissionId('daily', 'Score 200 Points'),
        type: 'daily',
        title: 'Score 200 Points',
        description: 'Score 200 points today',
        target: 200,
        objective: 'Score Points Today',
        flectcoins: 25,
        gems: 0,
        tier: 'Daily Challenges',
        category: 'scoring',
        sortOrder: 19
      },
      {
        id: generateMissionId('daily', 'Find the Word of the Day'),
        type: 'daily',
        title: 'Find the Word of the Day',
        description: 'Find today\'s word of the day',
        target: 1,
        objective: 'Find Word of the Day Today',
        flectcoins: 50,
        gems: 25,
        tier: 'Daily Special',
        category: 'special',
        sortOrder: 20
      },
      
      // WEEKLY MISSIONS
      {
        id: generateMissionId('weekly', 'Play 5 Games'),
        type: 'weekly',
        title: 'Play 5 Games',
        description: 'Play 5 games this week',
        target: 5,
        objective: 'Play Games This Week',
        flectcoins: 50,
        gems: 0,
        tier: 'Weekly Basics',
        category: 'gameplay',
        sortOrder: 1
      },
      {
        id: generateMissionId('weekly', 'Score 500 Points'),
        type: 'weekly',
        title: 'Score 500 Points',
        description: 'Score 500 points this week',
        target: 500,
        objective: 'Score Points This Week',
        flectcoins: 60,
        gems: 0,
        tier: 'Weekly Basics',
        category: 'scoring',
        sortOrder: 2
      },
      {
        id: generateMissionId('weekly', 'Score 1000 Points'),
        type: 'weekly',
        title: 'Score 1000 Points',
        description: 'Score 1000 points this week',
        target: 1000,
        objective: 'Score Points This Week',
        flectcoins: 80,
        gems: 0,
        tier: 'Weekly Challenges',
        category: 'scoring',
        sortOrder: 3
      },
      {
        id: generateMissionId('weekly', 'Complete 5 Games Without Hints'),
        type: 'weekly',
        title: 'Complete 5 Games Without Hints',
        description: 'Complete 5 games without using hints',
        target: 5,
        objective: 'Complete Games No Hints This Week',
        flectcoins: 100,
        gems: 0,
        tier: 'Weekly Challenges',
        category: 'gameplay',
        sortOrder: 4
      },
      {
        id: generateMissionId('weekly', 'Play Every Day'),
        type: 'weekly',
        title: 'Play Every Day',
        description: 'Play at least one game every day this week',
        target: 7,
        objective: 'Play Games Every Day This Week',
        flectcoins: 120,
        gems: 0,
        tier: 'Weekly Challenges',
        category: 'gameplay',
        sortOrder: 5
      },
      {
        id: generateMissionId('weekly', 'Find the Word of the Day 7 Days in a Row'),
        type: 'weekly',
        title: 'Find the Word of the Day 7 Days in a Row',
        description: 'Find the word of the day for 7 consecutive days',
        target: 7,
        objective: 'Find Word of the Day 7 Days This Week',
        flectcoins: 150,
        gems: 75,
        tier: 'Weekly Special',
        category: 'special',
        sortOrder: 6
      },
      {
        id: generateMissionId('weekly', 'Score 2000 Points'),
        type: 'weekly',
        title: 'Score 2000 Points',
        description: 'Score 2000 points this week',
        target: 2000,
        objective: 'Score Points This Week',
        flectcoins: 100,
        gems: 0,
        tier: 'Weekly Challenges',
        category: 'scoring',
        sortOrder: 7
      },
      {
        id: generateMissionId('weekly', 'Play 10 Games'),
        type: 'weekly',
        title: 'Play 10 Games',
        description: 'Play 10 games this week',
        target: 10,
        objective: 'Play Games This Week',
        flectcoins: 80,
        gems: 0,
        tier: 'Weekly Challenges',
        category: 'gameplay',
        sortOrder: 8
      },
      
      // GLOBAL MISSIONS (Gems only)
      {
        id: generateMissionId('global', 'Reach Level 10'),
        type: 'global',
        title: 'Reach Level 10',
        description: 'Reach level 10',
        target: 10,
        objective: 'Reach Level',
        flectcoins: 0,
        gems: 100,
        tier: 'Level Milestones',
        category: 'leveling',
        sortOrder: 1
      },
      {
        id: generateMissionId('global', 'Reach Level 25'),
        type: 'global',
        title: 'Reach Level 25',
        description: 'Reach level 25',
        target: 25,
        objective: 'Reach Level',
        flectcoins: 0,
        gems: 250,
        tier: 'Level Milestones',
        category: 'leveling',
        sortOrder: 2
      },
      {
        id: generateMissionId('global', 'Reach Level 50'),
        type: 'global',
        title: 'Reach Level 50',
        description: 'Reach level 50',
        target: 50,
        objective: 'Reach Level',
        flectcoins: 0,
        gems: 500,
        tier: 'Level Milestones',
        category: 'leveling',
        sortOrder: 3
      },
      {
        id: generateMissionId('global', 'Play 100 Games'),
        type: 'global',
        title: 'Play 100 Games',
        description: 'Play 100 games total',
        target: 100,
        objective: 'Play Games Total',
        flectcoins: 0,
        gems: 150,
        tier: 'Gameplay Milestones',
        category: 'gameplay',
        sortOrder: 4
      },
      {
        id: generateMissionId('global', 'Find 1000 Words'),
        type: 'global',
        title: 'Find 1000 Words',
        description: 'Find 1000 words total',
        target: 1000,
        objective: 'Find Words Total',
        flectcoins: 0,
        gems: 200,
        tier: 'Word Finding Milestones',
        category: 'word-finding',
        sortOrder: 5
      },
      {
        id: generateMissionId('global', 'Find 5000 Words'),
        type: 'global',
        title: 'Find 5000 Words',
        description: 'Find 5000 words total',
        target: 5000,
        objective: 'Find Words Total',
        flectcoins: 0,
        gems: 500,
        tier: 'Word Finding Milestones',
        category: 'word-finding',
        sortOrder: 6
      },
      {
        id: generateMissionId('global', 'Score 10000 Points'),
        type: 'global',
        title: 'Score 10000 Points',
        description: 'Score 10000 points total',
        target: 10000,
        objective: 'Score Points Total',
        flectcoins: 0,
        gems: 300,
        tier: 'Scoring Milestones',
        category: 'scoring',
        sortOrder: 7
      },
      {
        id: generateMissionId('global', 'Maintain 7-Day Login Streak'),
        type: 'global',
        title: 'Maintain 7-Day Login Streak',
        description: 'Log in for 7 consecutive days',
        target: 7,
        objective: 'Login Streak',
        flectcoins: 0,
        gems: 75,
        tier: 'Login Milestones',
        category: 'login',
        sortOrder: 8
      }
    ];
    
    // Add all missions to the database
    for (const mission of missions) {
      await dynamoDB.send(new PutCommand({
        TableName: 'wordflect-backend-missions-prod',
        Item: mission
      }));
      console.log(`✅ Added: ${mission.title} (${mission.tier}) - ${mission.flectcoins} flectcoins, ${mission.gems} gems`);
    }
    
    console.log('\n📊 MISSION STRUCTURE SUMMARY:');
    console.log('=============================');
    console.log(`📅 Daily Missions: ${missions.filter(m => m.type === 'daily').length}`);
    console.log(`📆 Weekly Missions: ${missions.filter(m => m.type === 'weekly').length}`);
    console.log(`🌍 Global Missions: ${missions.filter(m => m.type === 'global').length}`);
    
    console.log('\n📚 WORD-FINDING TIERS:');
    console.log('=====================');
    console.log('   Tier 1: Easy (10, 15, 20, 25 words)');
    console.log('   Tier 2: Medium (30, 40, 50 words)');
    console.log('   Tier 3: Hard (75, 100, 125 words)');
    console.log('   Tier 4: Expert (150, 200 words)');
    
    console.log('\n💰 REWARD STRUCTURE:');
    console.log('===================');
    console.log('   Word-finding missions: flectcoins = word count');
    console.log('   Daily missions: flectcoins only (except Word of Day)');
    console.log('   Weekly missions: flectcoins only (except 7-day streak)');
    console.log('   Global missions: gems only (milestones)');
    console.log('   Special missions: both flectcoins and gems');
    
  } catch (error) {
    console.error('❌ Error fixing mission structure:', error);
  }
}

fixMissionsOriginalStructure();
