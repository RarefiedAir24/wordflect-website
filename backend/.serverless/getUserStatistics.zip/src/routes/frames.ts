import express from 'express';
import { authenticateToken } from '../middleware/auth';
// import Frame from '../models/Frame'; // No longer using Mongoose Frame model
import User from '../models/User'; // Keep for other routes

// Add AWS SDK imports for DynamoDB
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, ScanCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';

const router = express.Router();

// DynamoDB setup
const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);
const USERS_TABLE = process.env.USERS_TABLE || 'wordflect-backend-users-dev';
const FRAMES_TABLE = process.env.FRAMES_TABLE || 'wordflect-backend-frames-dev';

// Get all available frames for a user
router.get('/', authenticateToken, async (req, res) => {
  try {
    // Fetch all frames from DynamoDB
    const framesResult = await dynamoDB.send(new ScanCommand({
      TableName: FRAMES_TABLE,
    }));
    const allFrames = framesResult.Items || [];

    // Fetch user from DynamoDB to see which frames they've unlocked
    const userResult = await dynamoDB.send(new GetCommand({
      TableName: USERS_TABLE,
      Key: { id: req.user.id },
    }));
    const user = userResult.Item;
    const unlockedFrameIds = user?.unlockedFrames || [];

    // Mark frames as unlocked if user has them
    const framesWithStatus = allFrames.map(frame => ({
      ...frame,
      isUnlocked: unlockedFrameIds.includes(frame.id),
    }));

    res.json(framesWithStatus);
  } catch (error) {
    console.error('Error fetching frames:', error);
    res.status(500).json({ error: 'Failed to fetch frames' });
  }
});

// Select a frame
router.post('/select', authenticateToken, async (req, res) => {
  try {
    const { frameId } = req.body;
    const userId = req.user.id;

    // 1. Get user to check if they have the frame
    const userResult = await dynamoDB.send(new GetCommand({
      TableName: USERS_TABLE,
      Key: { id: userId },
    }));

    if (!userResult.Item) {
      return res.status(404).json({ error: 'User not found' });
    }
    const user = userResult.Item;

    // 2. Check if user has unlocked this frame
    if (!user.unlockedFrames?.includes(frameId)) {
      return res.status(403).json({ error: 'Frame not unlocked' });
    }

    // 3. Update the user's selectedFrame
    const getFrame = new GetCommand({
      TableName: FRAMES_TABLE,
      Key: { id: frameId },
    });
    const { Item: frameToSelect } = await dynamoDB.send(getFrame);

    if (!frameToSelect) {
      return res.status(404).json({ error: 'Frame not found in frames table' });
    }

    const command = new UpdateCommand({
      TableName: USERS_TABLE,
      Key: { id: userId },
      UpdateExpression: 'SET selectedFrame = :frame',
      ExpressionAttributeValues: {
        ':frame': frameToSelect,
      },
      ReturnValues: 'ALL_NEW',
    });

    await dynamoDB.send(command);
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error selecting frame:', error);
    res.status(500).json({ error: 'Failed to select frame' });
  }
});

// Purchase a frame
router.post('/purchase', authenticateToken, async (req, res) => {
  try {
    const { frameId, price } = req.body;
    const userId = req.user.id;

    // 1. Get the current user data
    const userResult = await dynamoDB.send(new GetCommand({
      TableName: USERS_TABLE,
      Key: { id: userId },
    }));

    if (!userResult.Item) {
      return res.status(404).json({ error: 'User not found' });
    }
    const user = userResult.Item;

    // 2. Validate the purchase
    if ((user.flectcoins || 0) < price) {
      return res.status(400).json({ error: 'Not enough flectcoins' });
    }
    if (user.unlockedFrames?.includes(frameId)) {
      return res.status(400).json({ error: 'Frame already unlocked' });
    }

    // 3. Update user's flectcoins and add the new frame
    const command = new UpdateCommand({
      TableName: USERS_TABLE,
      Key: { id: userId },
      UpdateExpression: 'SET flectcoins = :newFlectcoins, unlockedFrames = list_append(if_not_exists(unlockedFrames, :empty_list), :newFrame)',
      ExpressionAttributeValues: {
        ':newFlectcoins': (user.flectcoins || 0) - price,
        ':newFrame': [frameId],
        ':empty_list': [],
      },
      ReturnValues: 'ALL_NEW',
    });

    const { Attributes } = await dynamoDB.send(command);

    res.json({ success: true, user: Attributes });
  } catch (error) {
    console.error('Error purchasing frame:', error);
    res.status(500).json({ error: 'Failed to purchase frame' });
  }
});

export default router; 