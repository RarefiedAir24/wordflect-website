import mongoose, { Schema, Document } from 'mongoose';

export interface IFrame extends Document {
  name: string;
  imageUrl: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt?: number; // Level required to unlock
  price?: number; // Gems required to purchase
  isDefault: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const FrameSchema: Schema = new Schema({
  name: { type: String, required: true },
  imageUrl: { type: String, required: true },
  rarity: { 
    type: String, 
    required: true,
    enum: ['common', 'rare', 'epic', 'legendary']
  },
  unlockedAt: { type: Number },
  price: { type: Number },
  isDefault: { type: Boolean, default: false },
}, {
  timestamps: true
});

export default mongoose.model<IFrame>('Frame', FrameSchema); 