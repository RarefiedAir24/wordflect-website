"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mongoose_1 = require("mongoose");
var FrameSchema = new mongoose_1.Schema({
    name: { type: String, required: true },
    imageUrl: { type: String, required: true },
    rarity: {
        type: String,
        required: true,
        enum: ['common', 'rare', 'epic', 'legendary']
    },
    unlockedAt: { type: Number },
    price: { type: Number },
    isDefault: { type: Boolean, default: false },
}, {
    timestamps: true
});
exports.default = mongoose_1.default.model('Frame', FrameSchema);
