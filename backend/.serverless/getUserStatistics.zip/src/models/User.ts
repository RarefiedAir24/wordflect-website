import { Schema, Document } from 'mongoose';

export interface User extends Document {
  id: string;
  username: string;
  email: string;
  passwordHash: string;
  topScore?: number;
  gamesPlayed?: number;
  highestLevel?: number;
  longestWord?: string;
  allFoundWords?: { word: string, date: string }[];
  selectedFrame?: any; 
  unlockedFrames?: any[];
  profileImageUrl?: string;
  profileImageKey?: string;
  flectcoins?: number;
  gems?: number;
  firstPlaceFinishes?: number;
  secondPlaceFinishes?: number;
  thirdPlaceFinishes?: number;
  
  // Timestamps
  createdAt: string;
  updatedAt: string;
}