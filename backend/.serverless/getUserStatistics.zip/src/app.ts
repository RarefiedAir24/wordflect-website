import framesRouter from './routes/frames';

app.use('/api/user/frames', framesRouter); 