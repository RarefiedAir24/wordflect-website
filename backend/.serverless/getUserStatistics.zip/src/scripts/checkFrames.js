const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, ScanCommand } = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({ region: "us-east-2" });
const docClient = DynamoDBDocumentClient.from(client);

const FRAMES_TABLE = 'wordflect-backend-frames-dev';

const checkFrames = async () => {
  const command = new ScanCommand({
    TableName: FRAMES_TABLE,
  });

  try {
    const response = await docClient.send(command);
    console.log(`Found ${response.Items.length} frames in ${FRAMES_TABLE}:`);
    response.Items.forEach(frame => {
      console.log(`- ${frame.name} (${frame.id}): Level ${frame.unlockedAt || 'default'}, ${frame.price || 0} gems`);
    });
  } catch (error) {
    console.error("Error checking frames:", error);
  }
};

checkFrames(); 