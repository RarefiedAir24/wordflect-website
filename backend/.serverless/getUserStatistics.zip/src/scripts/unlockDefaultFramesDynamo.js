const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const mongoose = require('mongoose');

// Inline Frame model schema for MongoDB
const frameSchema = new mongoose.Schema({
  name: { type: String, required: true },
  imageUrl: { type: String, required: true },
  rarity: {
    type: String,
    required: true,
    enum: ['common', 'rare', 'epic', 'legendary']
  },
  unlockedAt: { type: Number },
  price: { type: Number },
  isDefault: { type: Boolean, default: false },
}, {
  timestamps: true
});

let Frame;
try {
  Frame = mongoose.model('Frame');
} catch (e) {
  Frame = mongoose.model('Frame', frameSchema);
}

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

async function unlockDefaultFramesForDynamoUsers() {
  try {
    // Connect to MongoDB and get default frames
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/wordflect');
    const defaultFrames = await Frame.find({ isDefault: true });
    const defaultFrameIds = defaultFrames.map(f => f._id.toString());
    const selectedFrame = defaultFrameIds[0] || null;
    await mongoose.disconnect();

    // Fetch all users from DynamoDB
    const users = [];
    let ExclusiveStartKey = undefined;
    do {
      const scanResult = await dynamoDB.send(new ScanCommand({
        TableName: process.env.USERS_TABLE,
        ExclusiveStartKey,
      }));
      users.push(...(scanResult.Items || []));
      ExclusiveStartKey = scanResult.LastEvaluatedKey;
    } while (ExclusiveStartKey);

    console.log(`Found ${users.length} users in DynamoDB`);

    // Update each user
    for (const user of users) {
      await dynamoDB.send(new UpdateCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id: user.id },
        UpdateExpression: 'SET unlockedFrames = :frames, selectedFrame = :selected',
        ExpressionAttributeValues: {
          ':frames': defaultFrameIds,
          ':selected': selectedFrame,
        },
      }));
      console.log(`Updated user ${user.id}`);
    }

    console.log('Successfully unlocked default frames for all DynamoDB users');
    process.exit(0);
  } catch (error) {
    console.error('Error unlocking default frames for DynamoDB users:', error);
    process.exit(1);
  }
}

unlockDefaultFramesForDynamoUsers(); 