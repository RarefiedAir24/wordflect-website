const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, GetCommand } = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({ region: "us-east-2" });
const docClient = DynamoDBDocumentClient.from(client);

const USERS_TABLE = 'wordflect-backend-users-dev';

// Replace with your actual user ID or email
const USER_ID = 'your-user-id-here'; // You'll need to provide this

const checkUser = async () => {
  const command = new GetCommand({
    TableName: USERS_TABLE,
    Key: {
      id: USER_ID
    }
  });

  try {
    const response = await docClient.send(command);
    if (response.Item) {
      const user = response.Item;
      console.log('User Data:');
      console.log(`- ID: ${user.id}`);
      console.log(`- Username: ${user.username}`);
      console.log(`- Email: ${user.email}`);
      console.log(`- Highest Level: ${user.highestLevel || 'Not set'}`);
      console.log(`- Gems: ${user.gems || 0}`);
      console.log(`- Selected Frame: ${user.selectedFrame || 'None'}`);
      console.log(`- Unlocked Frames: ${user.unlockedFrames ? user.unlockedFrames.join(', ') : 'None'}`);
    } else {
      console.log('User not found');
    }
  } catch (error) {
    console.error("Error checking user:", error);
  }
};

checkUser(); 