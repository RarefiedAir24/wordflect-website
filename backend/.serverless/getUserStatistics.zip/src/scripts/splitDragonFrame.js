const fs = require('fs');
const path = require('path');

// This script helps you split the Dragon frame image
// You'll need to manually create the split images using an image editor

const SPLIT_GUIDE = `
🐉 DRAGON FRAME SPLIT GUIDE 🐉

To create a layered Dragon frame with animated fire breath from the heads:

1. DOWNLOAD THE CURRENT DRAGON FRAME:
   - Current URL: https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-frame.png
   - Save it as 'dragon-frame-original.png'

2. CREATE TWO SEPARATE IMAGES:

   A) DRAGON BODY (dragon-body.png):
   - Remove the dragon heads from the frame
   - Keep the dragon body, wings, tail, and frame structure
   - Make sure the heads area is transparent
   - This will be the static background layer

   B) DRAGON HEADS (dragon-heads.png):
   - Extract just the dragon heads
   - Keep the heads with transparent background
   - Position the heads exactly where they were in the original
   - This will be the animated layer with fire breath effect

3. UPLOAD TO S3:
   - Upload dragon-body.png to: https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-body.png
   - Upload dragon-heads.png to: https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-heads.png

4. UPDATE DATABASE:
   - The Dragon frame will need to be updated with the new image URLs
   - bodyImageUrl: "https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-body.png"
   - headImageUrl: "https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-heads.png"

5. TEST THE EFFECT:
   - The dragon body will remain static
   - Only the heads will have the fire breath animation
   - This creates a realistic dragon breathing fire effect

RECOMMENDED TOOLS:
- Adobe Photoshop
- GIMP (free)
- Figma
- Canva Pro

TIPS FOR SPLITTING:
- Use layer masks to cleanly separate the heads
- Ensure the heads layer has transparent background
- Test the alignment by overlaying the images
- Keep the same dimensions as the original frame
`;

console.log(SPLIT_GUIDE);

// Create a simple HTML preview tool
const createPreviewHTML = () => {
  const html = `
<!DOCTYPE html>
<html>
<head>
    <title>Dragon Frame Split Preview</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .container { display: flex; gap: 20px; }
        .frame { border: 2px solid #ccc; padding: 10px; }
        .frame img { max-width: 300px; height: auto; }
        .instructions { background: #f0f0f0; padding: 15px; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>🐉 Dragon Frame Split Preview</h1>
    
    <div class="instructions">
        <h3>Instructions:</h3>
        <ol>
            <li>Download the current dragon frame from S3</li>
            <li>Split it into body and heads using an image editor</li>
            <li>Upload both images to S3</li>
            <li>Update the database with new URLs</li>
        </ol>
    </div>
    
    <div class="container">
        <div class="frame">
            <h3>Original Dragon Frame</h3>
            <img src="https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-frame.png" alt="Original Dragon Frame">
        </div>
        
        <div class="frame">
            <h3>Dragon Body (Static)</h3>
            <p>Create this by removing the heads</p>
            <div style="width: 300px; height: 300px; background: #ddd; display: flex; align-items: center; justify-content: center; border: 2px dashed #999;">
                <p>dragon-body.png</p>
            </div>
        </div>
        
        <div class="frame">
            <h3>Dragon Heads (Animated)</h3>
            <p>Create this by extracting just the heads</p>
            <div style="width: 300px; height: 300px; background: #ddd; display: flex; align-items: center; justify-content: center; border: 2px dashed #999;">
                <p>dragon-heads.png</p>
            </div>
        </div>
    </div>
    
    <div style="margin-top: 20px; padding: 15px; background: #e8f4fd; border-radius: 5px;">
        <h3>Expected Result:</h3>
        <p>The dragon body will remain static while only the heads have the fire breath animation, creating a realistic dragon breathing fire effect.</p>
    </div>
</body>
</html>
`;

  const outputPath = path.join(__dirname, 'dragon-frame-preview.html');
  fs.writeFileSync(outputPath, html);
  console.log(`\n📄 Preview HTML created: ${outputPath}`);
  console.log('Open this file in your browser to see the split guide!');
};

createPreviewHTML();

console.log('\n🎯 NEXT STEPS:');
console.log('1. Download the current dragon frame from S3');
console.log('2. Use an image editor to split it into body and heads');
console.log('3. Upload both images to S3');
console.log('4. Let me know when you\'re ready to update the database!'); 