const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, ScanCommand, UpdateCommand } = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({ region: "us-east-2" });
const docClient = DynamoDBDocumentClient.from(client);

const FRAMES_TABLE = 'wordflect-backend-frames-prod';

const removeFrameRequirements = async () => {
  try {
    // First, get all frames
    const scanCommand = new ScanCommand({
      TableName: FRAMES_TABLE,
    });
    
    const response = await docClient.send(scanCommand);
    console.log(`Found ${response.Items.length} frames to update`);
    
    // Update each frame to remove requirements
    for (const frame of response.Items) {
      const updateParams = {
        TableName: FRAMES_TABLE,
        Key: { id: frame.id },
        UpdateExpression: "REMOVE unlockedAt, price, battleWinsRequired SET isDefault = :isDefault",
        ExpressionAttributeValues: {
          ":isDefault": true
        }
      };
      
      const updateCommand = new UpdateCommand(updateParams);
      await docClient.send(updateCommand);
      
      console.log(`✅ Updated ${frame.name} (${frame.id}): Removed all requirements`);
    }
    
    console.log('\n🎉 All frame requirements have been removed!');
    console.log('📱 You can now test all frames in the app');
    console.log('⚠️  Remember to restore requirements later for production');
    
  } catch (error) {
    console.error("Error removing frame requirements:", error);
  }
};

const restoreFrameRequirements = async () => {
  console.log('🔄 Restoring original frame requirements...');
  
  const originalRequirements = [
    { id: 'spiked-steel', name: 'Spiked Steel', price: 0, isDefault: true },
    { id: 'ice-crystal', name: 'Ice Crystal', price: 0, isDefault: true },
    { id: 'heart-gold', name: 'Heart Gold', unlockedAt: 5, price: 150 },
    { id: 'skull-bone', name: 'Skull Bone', unlockedAt: 5, price: 200 },
    { id: 'blue-spikes', name: 'Blue Spikes', unlockedAt: 5, price: 250 },
    { id: 'wood-diamonds', name: 'Wood Diamonds', unlockedAt: 8, price: 300 },
    { id: 'fire-frame', name: 'Fire Frame', unlockedAt: 5, price: 200 },
    { id: 'halo', name: 'Halo', unlockedAt: 10, price: 400 },
    { id: 'blue-diamonds', name: 'Blue Diamonds', unlockedAt: 15, price: 500 },
    { id: 'dark-bling', name: 'Dark Bling', unlockedAt: 18, price: 600 },
    { id: 'galaxy-frame', name: 'Galaxy Frame', unlockedAt: 12, price: 500 },
    { id: 'gradient-diamond', name: 'Gradient Diamond', unlockedAt: 20, price: 800 },
    { id: 'empress', name: 'Empress', battleWinsRequired: 25, price: 1000 },
    { id: 'wings', name: 'Wings', battleWinsRequired: 10, price: 1200 },
    { id: 'dragon-frame', name: 'Dragon Frame', unlockedAt: 25, price: 1000 },
    { id: 'vine-frame', name: 'Vine Frame', unlockedAt: 15, price: 600 },
    { id: 'cyber-frame', name: 'Cyber Frame', unlockedAt: 18, price: 700 },
    { id: 'ice-shard', name: 'Ice Shard', unlockedAt: 20, price: 800 },
  ];
  
  try {
    for (const frame of originalRequirements) {
      const updateParams = {
        TableName: FRAMES_TABLE,
        Key: { id: frame.id },
        UpdateExpression: "SET price = :price, isDefault = :isDefault",
        ExpressionAttributeValues: {
          ":price": frame.price,
          ":isDefault": frame.isDefault || false
        }
      };
      
      // Add unlockedAt if it exists
      if (frame.unlockedAt) {
        updateParams.UpdateExpression += ", unlockedAt = :unlockedAt";
        updateParams.ExpressionAttributeValues[":unlockedAt"] = frame.unlockedAt;
      }
      
      // Add battleWinsRequired if it exists
      if (frame.battleWinsRequired) {
        updateParams.UpdateExpression += ", battleWinsRequired = :battleWinsRequired";
        updateParams.ExpressionAttributeValues[":battleWinsRequired"] = frame.battleWinsRequired;
      }
      
      const updateCommand = new UpdateCommand(updateParams);
      await docClient.send(updateCommand);
      
      console.log(`✅ Restored ${frame.name} requirements`);
    }
    
    console.log('\n🎉 All frame requirements have been restored!');
    
  } catch (error) {
    console.error("Error restoring frame requirements:", error);
  }
};

// Check command line argument
const action = process.argv[2];

if (action === 'restore') {
  restoreFrameRequirements();
} else {
  console.log('🚀 Removing all frame requirements for testing...\n');
  removeFrameRequirements();
} 