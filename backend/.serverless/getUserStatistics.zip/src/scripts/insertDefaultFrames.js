const mongoose = require('mongoose');

// Frame schema
const frameSchema = new mongoose.Schema({
  name: { type: String, required: true },
  imageUrl: { type: String, required: true },
  rarity: {
    type: String,
    required: true,
    enum: ['common', 'rare', 'epic', 'legendary']
  },
  unlockedAt: { type: Number },
  price: { type: Number },
  isDefault: { type: Boolean, default: false },
}, {
  timestamps: true
});

const Frame = mongoose.model('Frame', frameSchema);

const defaultFrames = [
  {
    name: 'Basic Frame',
    imageUrl: 'https://wordflect.s3.amazonaws.com/frames/basic.png',
    rarity: 'common',
    isDefault: true,
    price: 0
  },
  {
    name: 'Silver Frame',
    imageUrl: 'https://wordflect.s3.amazonaws.com/frames/silver.png',
    rarity: 'rare',
    unlockedAt: 5,
    price: 150
  },
  {
    name: 'Gold Frame',
    imageUrl: 'https://wordflect.s3.amazonaws.com/frames/gold.png',
    rarity: 'epic',
    unlockedAt: 10,
    price: 400
  },
  {
    name: 'Diamond Frame',
    imageUrl: 'https://wordflect.s3.amazonaws.com/frames/diamond.png',
    rarity: 'legendary',
    unlockedAt: 20,
    price: 800
  }
];

async function insertDefaultFrames() {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/wordflect');
    console.log('Connected to MongoDB');

    // Clear existing frames
    await Frame.deleteMany({});
    console.log('Cleared existing frames');

    // Insert default frames
    const frames = await Frame.insertMany(defaultFrames);
    console.log('Inserted default frames:', frames);

    process.exit(0);
  } catch (error) {
    console.error('Error inserting default frames:', error);
    process.exit(1);
  }
}

insertDefaultFrames(); 