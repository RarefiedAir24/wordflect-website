const mongoose = require('mongoose');

// Inline Frame model schema
const frameSchema = new mongoose.Schema({
  name: { type: String, required: true },
  imageUrl: { type: String, required: true },
  rarity: {
    type: String,
    required: true,
    enum: ['common', 'rare', 'epic', 'legendary']
  },
  unlockedAt: { type: Number },
  price: { type: Number },
  isDefault: { type: Boolean, default: false },
}, {
  timestamps: true
});

// Inline User model schema
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  selectedFrame: { type: mongoose.Schema.Types.ObjectId, ref: 'Frame' },
  unlockedFrames: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Frame' }],
  gems: { type: Number, default: 0 },
  highestLevel: { type: Number, default: 1 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const Frame = mongoose.model('Frame', frameSchema);
const User = mongoose.model('User', userSchema);

async function unlockDefaultFrames() {
  try {
    await mongoose.connect('mongodb://localhost:27017/wordflect');
    console.log('Connected to MongoDB');

    // Get all default frames
    const defaultFrames = await Frame.find({ isDefault: true });
    console.log(`Found ${defaultFrames.length} default frames`);

    // Get all users
    const users = await User.find();
    console.log(`Found ${users.length} users`);

    // Update each user with default frames
    for (const user of users) {
      const defaultFrameIds = defaultFrames.map(frame => frame._id);
      user.unlockedFrames = [...new Set([...user.unlockedFrames, ...defaultFrameIds])];
      await user.save();
    }

    console.log('Successfully unlocked default frames for all users');
    process.exit(0);
  } catch (error) {
    console.error('Error unlocking default frames:', error);
    process.exit(1);
  }
}

unlockDefaultFrames(); 