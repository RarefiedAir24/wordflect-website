const mongoose = require('mongoose');
const Frame = require('../models/Frame').default;
const { config } = require('../config');

const frames = [
  {
    name: 'Spiked Steel',
    imageUrl: 'https://wordflect-avatar-frames.s3.amazonaws.com/spiked-steel.png',
    rarity: 'common',
    isDefault: true,
  },
  {
    name: 'Heart Gold',
    imageUrl: 'https://wordflect-avatar-frames.s3.amazonaws.com/heart-gold.png',
    rarity: 'common',
    isDefault: true,
  },
  {
    name: 'Ice Crystal',
    imageUrl: 'https://wordflect-avatar-frames.s3.amazonaws.com/ice-crystal.png',
    rarity: 'common',
    isDefault: true,
  },
  {
    name: 'Skull Bone',
    imageUrl: 'https://wordflect-avatar-frames.s3.amazonaws.com/skull-bone.png',
    rarity: 'common',
    isDefault: true,
  },
  {
    name: 'Silver',
    imageUrl: 'https://your-cdn.com/frames/silver.png',
    rarity: 'rare',
    unlockedAt: 10,
    price: 150,
  },
  {
    name: 'Gold',
    imageUrl: 'https://your-cdn.com/frames/gold.png',
    rarity: 'epic',
    unlockedAt: 25,
    price: 400,
  },
  {
    name: 'Diamond',
    imageUrl: 'https://your-cdn.com/frames/diamond.png',
    rarity: 'legendary',
    unlockedAt: 50,
    price: 800,
  },
];

async function seedFrames() {
  try {
    await mongoose.connect(config.mongoUri);
    console.log('Connected to MongoDB');

    // Clear existing frames
    await Frame.deleteMany({});
    console.log('Cleared existing frames');

    // Insert new frames
    await Frame.insertMany(frames);
    console.log('Seeded frames successfully');

    process.exit(0);
  } catch (error) {
    console.error('Error seeding frames:', error);
    process.exit(1);
  }
}

seedFrames(); 