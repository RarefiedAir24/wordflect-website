const jwt = require('jsonwebtoken');

exports.handler = async (event) => {
  try {
    const token = event.authorizationToken.replace('Bearer ', '');
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    return {
      principalId: decoded.id || decoded.sub,
      policyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Action: 'execute-api:Invoke',
            Effect: 'Allow',
            Resource: event.methodArn,
          },
        ],
      },
      context: {
        claims: decoded,
      },
    };
  } catch (error) {
    console.error('Token validation failed:', error);
    throw new Error('Unauthorized');
  }
}; 