const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

// Default frames data
const defaultFrames = [
  { id: 'spiked-steel', name: 'Spiked Steel', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/spiked-steel.png', rarity: 'common', isDefault: true, price: 0 },
  { id: 'ice-crystal', name: 'Ice Crystal', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-crystal.png', rarity: 'common', isDefault: true, price: 0 },
  { id: 'heart-gold', name: 'Heart Gold', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/heart-gold.png', rarity: 'rare', unlockedAt: 5, price: 150 },
  { id: 'skull-bone', name: 'Skull Bone', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/skull-bone.png', rarity: 'rare', unlockedAt: 5, price: 200 },
  { id: 'blue-spikes', name: 'Blue Spikes', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-spikes.png', rarity: 'rare', unlockedAt: 5, price: 250 },
  { id: 'wood-diamonds', name: 'Wood Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wood-diamonds.png', rarity: 'rare', unlockedAt: 8, price: 300 },
  { id: 'fire-frame', name: 'Fire Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/fire-frame.png', rarity: 'rare', unlockedAt: 5, price: 200 },
  { id: 'halo', name: 'Halo', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/halo.png', rarity: 'epic', unlockedAt: 10, price: 400 },
  { id: 'blue-diamonds', name: 'Blue Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-diamonds.png', rarity: 'epic', unlockedAt: 15, price: 500 },
  { id: 'dark-bling', name: 'Dark Bling', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dark-bling.png', rarity: 'epic', unlockedAt: 18, price: 600 },
  { id: 'galaxy-frame', name: 'Galaxy Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/galaxy-frame.png', rarity: 'epic', unlockedAt: 12, price: 500 },
  { id: 'gradient-diamond', name: 'Gradient Diamond', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/gradient-diamond.png', rarity: 'legendary', unlockedAt: 20, price: 800 },
  { id: 'empress', name: 'Empress', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/empress.png', rarity: 'legendary', battleWinsRequired: 25, price: 1000 },
  { id: 'wings', name: 'Wings', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wings.png', rarity: 'legendary', battleWinsRequired: 10, price: 1200 },
  { id: 'dragon-frame', name: 'Dragon Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-frame.png', rarity: 'legendary', unlockedAt: 25, price: 1000 },
  { id: 'vine-frame', name: 'Vine Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/vine-frame.png', rarity: 'epic', unlockedAt: 15, price: 600 },
  { id: 'cyber-frame', name: 'Cyber Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/cyber-frame.png', rarity: 'epic', unlockedAt: 18, price: 700 },
  { id: 'ice-shard', name: 'Ice Shard', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-shard.png', rarity: 'epic', unlockedAt: 20, price: 800 },
];

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    // Parse Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Authorization header is required' }),
      };
    }
    const token = authHeader.replace('Bearer ', '');
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtErr) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Invalid or expired token' }),
      };
    }
    const userId = decoded.id;
    if (!userId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'User ID is required' }),
      };
    }

    // Parse body
    let body;
    try {
      body = JSON.parse(event.body);
    } catch (err) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Invalid request body' }),
      };
    }
    const { frameId } = body;
    if (!frameId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'frameId is required' }),
      };
    }

    // Fetch user from DynamoDB
    const result = await dynamoDB.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
    }));
    const user = result.Item;
    if (!user) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    // Find the frame in our default frames list
    const frame = defaultFrames.find(f => f.id === frameId);
    if (!frame) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Frame not found' }),
      };
    }

    if (!frame.price) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Frame is not purchasable' }),
      };
    }

    if (user.gems < frame.price) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Not enough gems' }),
      };
    }

    // Check if already unlocked
    const unlockedFrames = user.unlockedFrames || [];
    if (unlockedFrames.includes(frameId)) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Frame already unlocked' }),
      };
    }

    // Update user's gems and unlocked frames
    const newGems = user.gems - frame.price;
    const newUnlockedFrames = [...unlockedFrames, frameId];

    await dynamoDB.send(new UpdateCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
      UpdateExpression: 'set gems = :gems, unlockedFrames = :frames',
      ExpressionAttributeValues: {
        ':gems': newGems,
        ':frames': newUnlockedFrames,
      },
    }));

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ 
        success: true,
        gems: newGems
      }),
    };
  } catch (error) {
    console.error('Error purchasing frame:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Failed to purchase frame', error: error.message }),
    };
  }
}; 