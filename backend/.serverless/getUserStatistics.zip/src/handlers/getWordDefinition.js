const WORDNIK_API_KEY = process.env.WORDNIK_API_KEY;

// Simple in-memory cache
const definitionCache = {};
const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours

// Helper to fetch from secondary API
async function fetchFromDictionaryApiDev(word) {
  const url = `https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`;
  try {
    const response = await fetch(url);
    if (!response.ok) return null;
    const data = await response.json();
    // Parse the response to extract a definition
    if (Array.isArray(data) && data.length > 0 && data[0].meanings && data[0].meanings.length > 0) {
      const firstMeaning = data[0].meanings[0];
      if (firstMeaning.definitions && firstMeaning.definitions.length > 0) {
        return [{
          text: firstMeaning.definitions[0].definition,
          attributionText: 'from Free Dictionary API',
          sourceDictionary: 'dictionaryapi.dev'
        }];
      }
    }
    return null;
  } catch (e) {
    return null;
  }
}

exports.handler = async (event) => {
  try {
    const word = event.queryStringParameters && event.queryStringParameters.word;
    console.log('Received request for word:', word);
    
    if (!word) {
      console.log('Missing word parameter');
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Missing word parameter.' }),
      };
    }

    const now = Date.now();
    // Check cache
    if (definitionCache[word] && (now - definitionCache[word].timestamp < CACHE_TTL)) {
      console.log('Cache hit for word:', word);
      return {
        statusCode: 200,
        body: JSON.stringify(definitionCache[word].data),
      };
    }
    console.log('Cache miss for word:', word);

    // Always use lowercase for Wordnik API call
    const wordForApi = word.toLowerCase();
    const url = `https://api.wordnik.com/v4/word.json/${encodeURIComponent(wordForApi)}/definitions?limit=1&includeRelated=false&useCanonical=false&includeTags=false&api_key=${WORDNIK_API_KEY}`;
    console.log('Fetching from Wordnik:', url);
    
    const response = await fetch(url);
    console.log('Wordnik response status:', response.status);
    
    if (!response.ok) {
      console.error('Wordnik API error:', response.status, response.statusText);
      return {
        statusCode: response.status,
        body: JSON.stringify({ 
          message: 'Failed to fetch definition.',
          error: response.statusText,
          status: response.status
        }),
      };
    }

    const data = await response.json();
    console.log('Wordnik API response:', JSON.stringify(data));

    // Validate the response data
    let validDefinition = Array.isArray(data) && data.find(entry => entry.text && entry.text.trim() !== '');
    if (!validDefinition) {
      // Try secondary API
      console.log('No valid Wordnik definition, trying secondary API...');
      const secondaryData = await fetchFromDictionaryApiDev(wordForApi);
      if (secondaryData) {
        // Store in cache and return
        definitionCache[word] = { data: secondaryData, timestamp: now };
        console.log('Cached definition from secondary API for word:', word);
        return {
          statusCode: 200,
          body: JSON.stringify(secondaryData),
        };
      }
      // If both fail, return empty array
      console.log('No valid definition found from any source');
      return {
        statusCode: 200,
        body: JSON.stringify([]),
      };
    }

    // Store in cache
    definitionCache[word] = { data, timestamp: now };
    console.log('Cached definition for word:', word);
    
    return {
      statusCode: 200,
      body: JSON.stringify(data),
    };
  } catch (error) {
    console.error('Wordnik definition error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        message: 'Internal server error.',
        error: error.message,
        stack: error.stack
      }),
    };
  }
}; 