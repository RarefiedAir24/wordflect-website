const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  console.log('Test dependencies handler started');
  
  try {
    // Test AWS SDK
    console.log('Testing AWS SDK...');
    const scanResult = await dynamoDB.send(new ScanCommand({
      TableName: process.env.USERS_TABLE,
      Limit: 1
    }));
    console.log('AWS SDK test passed');
    
    // Test bcrypt
    console.log('Testing bcrypt...');
    const hash = await bcrypt.hash('test', 10);
    const isMatch = await bcrypt.compare('test', hash);
    console.log('bcrypt test passed, hash:', hash.substring(0, 20) + '...', 'match:', isMatch);
    
    // Test JWT
    console.log('Testing JWT...');
    const token = jwt.sign({ test: 'data' }, process.env.JWT_SECRET || 'test-secret', { expiresIn: '1h' });
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'test-secret');
    console.log('JWT test passed, token:', token.substring(0, 20) + '...');
    
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'All dependencies working',
        awsSdk: 'OK',
        bcrypt: 'OK',
        jwt: 'OK',
        usersFound: scanResult.Items ? scanResult.Items.length : 0
      }),
    };
  } catch (error) {
    console.error('Dependency test failed:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'Dependency test failed',
        error: error.message,
        stack: error.stack
      }),
    };
  }
}; 