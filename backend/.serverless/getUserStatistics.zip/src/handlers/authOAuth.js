const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, PutCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');
const fetch = require('node-fetch');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin || '*';
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

// Google OAuth - Disabled for iOS-only app
// async function verifyGoogleToken(accessToken) {
//   try {
//     const response = await fetch(`https://www.googleapis.com/oauth2/v2/userinfo?access_token=${accessToken}`);
//     if (!response.ok) {
//       throw new Error('Invalid Google token');
//     }
//     return await response.json();
//   } catch (error) {
//     console.error('Google token verification error:', error);
//     throw new Error('Failed to verify Google token');
//   }
// }

// Verify Apple token (simplified - in production you'd verify the JWT signature)
async function verifyAppleToken(idToken) {
  try {
    // In production, you should verify the JWT signature with Apple's public keys
    // For now, we'll decode the token and trust the userInfo passed from frontend
    const payload = JSON.parse(Buffer.from(idToken.split('.')[1], 'base64').toString());
    return {
      sub: payload.sub,
      email: payload.email,
      email_verified: payload.email_verified,
    };
  } catch (error) {
    console.error('Apple token verification error:', error);
    throw new Error('Failed to verify Apple token');
  }
}

// Find or create user
async function findOrCreateUser(provider, userInfo, username) {
  const { email, sub: providerUserId, name } = userInfo;
  
  // First, try to find user by email
  const emailScanResult = await dynamoDB.send(new ScanCommand({
    TableName: process.env.USERS_TABLE,
    FilterExpression: 'email = :email',
    ExpressionAttributeValues: { ':email': email }
  }));

  if (emailScanResult.Items && emailScanResult.Items.length > 0) {
    // User exists, update OAuth info if needed
    const user = emailScanResult.Items[0];
    console.log('Found existing user by email:', user.id);
    
    // Update OAuth provider info if not already set
    if (!user.oauthProviders) {
      user.oauthProviders = {};
    }
    user.oauthProviders[provider] = {
      providerUserId,
      linkedAt: new Date().toISOString()
    };
    
    // Update user in database
    await dynamoDB.send(new PutCommand({
      TableName: process.env.USERS_TABLE,
      Item: user
    }));
    
    return user;
  }

  // Check if user exists by OAuth provider ID
  const oauthScanResult = await dynamoDB.send(new ScanCommand({
    TableName: process.env.USERS_TABLE,
    FilterExpression: 'oauthProviders.#provider.providerUserId = :providerUserId',
    ExpressionAttributeNames: { '#provider': provider },
    ExpressionAttributeValues: { ':providerUserId': providerUserId }
  }));

  if (oauthScanResult.Items && oauthScanResult.Items.length > 0) {
    console.log('Found existing user by OAuth provider:', oauthScanResult.Items[0].id);
    return oauthScanResult.Items[0];
  }

  // Create new user with provided username
  const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  // Ensure username is unique
  let finalUsername = username;
  let counter = 1;
  while (true) {
    const usernameScanResult = await dynamoDB.send(new ScanCommand({
      TableName: process.env.USERS_TABLE,
      FilterExpression: 'username = :username',
      ExpressionAttributeValues: { ':username': finalUsername }
    }));
    
    if (!usernameScanResult.Items || usernameScanResult.Items.length === 0) {
      break;
    }
    finalUsername = `${username}${counter}`;
    counter++;
  }

  const newUser = {
    id: userId,
    username: finalUsername,
    email: email,
    oauthProviders: {
      [provider]: {
        providerUserId,
        linkedAt: new Date().toISOString()
      }
    },
    createdAt: new Date().toISOString(),
    level: 1,
    highestLevel: 1,
    experience: 0,
    points: 0,
    gems: 0,
    flectcoins: 150,
    coins: 100,
    selectedFrame: null,
    unlockedFrames: ['spiked-steel'],
    frames: ['spiked-steel'],
    missions: [],
    gamesPlayed: 0,
    topScore: 0,
    longestWord: '',
    allFoundWords: [],
    profileImageUrl: null,
    profileImageKey: null,
    stats: {
      gamesPlayed: 0,
      gamesWon: 0,
      totalScore: 0,
      averageScore: 0
    }
  };

  await dynamoDB.send(new PutCommand({
    TableName: process.env.USERS_TABLE,
    Item: newUser
  }));

  console.log('Created new user via OAuth:', userId);
  return newUser;
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  console.log('OAuth handler started');
  console.log('Event:', JSON.stringify(event, null, 2));

  // Handle OPTIONS request for CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: '',
    };
  }

  try {
    const { provider, accessToken, idToken, userInfo, username } = JSON.parse(event.body);
    
    if (!provider || !userInfo || !username) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Provider, userInfo, and username are required' }),
      };
    }

    let verifiedUserInfo;

    // Verify the OAuth token (Apple only for iOS)
    if (provider === 'apple') {
      if (!idToken) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ message: 'Apple ID token is required' }),
        };
      }
      verifiedUserInfo = await verifyAppleToken(idToken);
    } else {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Only Apple Sign-In is supported' }),
      };
    }

    // Find or create user with username
    const user = await findOrCreateUser(provider, verifiedUserInfo, username);

    // Generate JWT token
    const token = jwt.sign(
      { 
        id: user.id,
        email: user.email,
        username: user.username,
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    console.log('OAuth authentication successful for user:', user.id);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'OAuth authentication successful',
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          createdAt: user.createdAt,
          profileImageUrl: user.profileImageUrl,
          highestLevel: user.highestLevel,
          gems: user.gems,
          flectcoins: user.flectcoins,
          isPremium: user.isPremium,
          premiumTier: user.premiumTier,
          subscriptionEndDate: user.subscriptionEndDate,
          selectedFrame: user.selectedFrame
        },
        token,
      }),
    };

  } catch (error) {
    console.error('Error in OAuth handler:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'OAuth authentication failed',
        error: error.message 
      }),
    };
  }
};
