const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);
const USERS_TABLE = process.env.USERS_TABLE;
const MISSIONS_TABLE = process.env.MISSIONS_TABLE;
const WORD_OF_THE_DAY_TABLE = process.env.WORD_OF_THE_DAY_TABLE;

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

// Helper: fetch all missions from DynamoDB
async function fetchAllMissions() {
  const result = await dynamoDB.send(new ScanCommand({ TableName: MISSIONS_TABLE }));
  return result.Items || [];
}

function shouldReset(lastProgress, period) {
  // If no progress was ever made, don't reset
  if (!lastProgress) return false;
  
  const now = new Date();
  const last = new Date(lastProgress);
  
  if (period === 'daily') {
    // Convert to EST
    const estNow = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    const estLast = new Date(last.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    return estNow.toDateString() !== estLast.toDateString();
  } else if (period === 'weekly') {
    // Reset every Monday (start of new week)
    const nowWeek = now.getFullYear() + '-' + getWeekNumber(now);
    const lastWeek = last.getFullYear() + '-' + getWeekNumber(last);
    return nowWeek !== lastWeek;
  }
  return false;
}

function getWeekNumber(d) {
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay()||7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1)/7);
  return weekNo;
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  // START OF DIAGNOSTIC LOGGING
  console.log("--- GET USER MISSIONS EVENT START ---");
  console.log(JSON.stringify(event, null, 2));
  console.log("--- GET USER MISSIONS EVENT END ---");
  // END OF DIAGNOSTIC LOGGING

  try {
    // Securely get the user ID from the authorizer context.
    // This is the single, reliable source of truth for the user's identity.
    const id = event.requestContext.authorizer.principalId;

    if (!id) {
      console.error('CRITICAL: No user ID found in authorizer context.');
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'User not authorized.' }),
        headers: corsHeaders,
      };
    }
    
    // Debug log: print table name and user ID
    console.log('Looking up user for missions in table:', USERS_TABLE, 'with id:', id);
    
    // Get user
    const { Item: user } = await dynamoDB.send(new GetCommand({ TableName: USERS_TABLE, Key: { id } }));
    console.log('User lookup result:', user);
    
    if (!user) {
      return { 
        statusCode: 404, 
        body: JSON.stringify({ message: 'User not found' }),
        headers: corsHeaders
      };
    }
    
    // Fetch all missions
    const allMissions = await fetchAllMissions();
    console.log('All missions in table:', allMissions.length, allMissions.map(m => ({ id: m.id, type: m.type, title: m.title })));
    
    // Fetch today's word of the day
    let wordOfTheDay = null;
    try {
      const today = new Date().toISOString().slice(0, 10);
      const wotdResponse = await dynamoDB.send(new GetCommand({
        TableName: WORD_OF_THE_DAY_TABLE,
        Key: { date: today },
      }));
      wordOfTheDay = wotdResponse.Item?.word;
    } catch (e) {
      console.error('Failed to fetch word of the day:', e);
    }

    // Prepare missions progress
    let missions = user.missions || { daily: {}, weekly: {}, global: {} };
    // Ensure standard buckets exist
    if (!missions.daily) missions.daily = {};
    if (!missions.weekly) missions.weekly = {};
    if (!missions.global) missions.global = {};
    let missionsStats = user.missionsStats || { dailyCompleted: 0, weeklyCompleted: 0, globalCompleted: 0 };
    let updated = false;

    // Ensure every mission is present in user's progress
    for (const mission of allMissions) {
      const { id: missionId } = mission;
      const period = (mission.type || '').toLowerCase();
      if (!['daily','weekly','global'].includes(period)) {
        // Skip unknown mission types
        continue;
      }
      if (!missions[period]) missions[period] = {};
      const prog = missions[period][missionId];
      
      // Replace {word} placeholder in any mission description
      if (mission.description && mission.description.includes('{word}') && wordOfTheDay) {
        mission.description = mission.description.replace('{word}', wordOfTheDay);
      }

      if (!prog) {
        missions[period][missionId] = { progress: 0, completed: false, lastCompleted: null, lastProgress: null };
        updated = true;
      } else if ((period === 'daily' || period === 'weekly') && shouldReset(prog.lastProgress, period)) {
        missions[period][missionId] = { progress: 0, completed: false, lastCompleted: null, lastProgress: null };
        updated = true;
      }
    }
    
    // Save if updated
    if (updated) {
      await dynamoDB.send(new UpdateCommand({
        TableName: USERS_TABLE,
        Key: { id },
        UpdateExpression: 'SET missions = :m',
        ExpressionAttributeValues: { ':m': missions },
      }));
    }
    
    // Group missions by period for frontend
    const missionsByPeriod = { daily: [], weekly: [], global: [] };
    for (const mission of allMissions) {
      const period = (mission.type || '').toLowerCase();
      if (['daily','weekly','global'].includes(period)) {
        missionsByPeriod[period].push(mission);
      }
    }

    // Build merged missions with progress for convenience
    const mergedMissionsByPeriod = { daily: [], weekly: [], global: [] };
    for (const period of ['daily','weekly','global']) {
      const defs = missionsByPeriod[period] || [];
      const progMap = missions[period] || {};
      for (const def of defs) {
        const prog = progMap[def.id] || { progress: 0, completed: false, lastCompleted: null, lastProgress: null };
        mergedMissionsByPeriod[period].push({
          ...def,
          progress: typeof prog.progress === 'number' ? prog.progress : 0,
          completed: !!prog.completed,
          lastCompleted: prog.lastCompleted || null,
          lastProgress: prog.lastProgress || null,
        });
      }
    }
    
    // Return definitions, progress, and stats
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        missions: missionsByPeriod,
        progress: missions,
        merged: mergedMissionsByPeriod,
        stats: missionsStats,
      })
    };
  } catch (error) {
    console.error('Get user missions error:', error);
    return { 
      statusCode: 500, 
      body: JSON.stringify({ message: 'An error occurred.' }),
      headers: corsHeaders
    };
  }
}; 