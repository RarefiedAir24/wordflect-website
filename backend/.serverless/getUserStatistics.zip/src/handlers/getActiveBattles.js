const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, QueryCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');

const dynamoDB = DynamoDBDocumentClient.from(new DynamoDBClient({}));

// Add defaultFrames definition for resolving frame objects
const defaultFrames = [
  { id: 'spiked-steel', name: 'Spiked Steel', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/spiked-steel.png', rarity: 'common', isDefault: true, price: 0 },
  { id: 'ice-crystal', name: 'Ice Crystal', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-crystal.png', rarity: 'common', isDefault: true, price: 0 },
  { id: 'heart-gold', name: 'Heart Gold', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/heart-gold.png', rarity: 'rare', unlockedAt: 5, price: 150 },
  { id: 'skull-bone', name: 'Skull Bone', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/skull-bone.png', rarity: 'rare', unlockedAt: 5, price: 200 },
  { id: 'blue-spikes', name: 'Blue Spikes', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-spikes.png', rarity: 'rare', unlockedAt: 5, price: 250 },
  { id: 'wood-diamonds', name: 'Wood Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wood-diamonds.png', rarity: 'rare', unlockedAt: 8, price: 300 },
  { id: 'fire-frame', name: 'Fire Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/fire-frame.png', rarity: 'rare', unlockedAt: 5, price: 200 },
  { id: 'halo', name: 'Halo', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/halo.png', rarity: 'epic', unlockedAt: 10, price: 400 },
  { id: 'blue-diamonds', name: 'Blue Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-diamonds.png', rarity: 'epic', unlockedAt: 15, price: 500 },
  { id: 'dark-bling', name: 'Dark Bling', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dark-bling.png', rarity: 'epic', unlockedAt: 18, price: 600 },
  { id: 'galaxy-frame', name: 'Galaxy Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/galaxy-frame.png', rarity: 'epic', unlockedAt: 12, price: 500 },
  { id: 'gradient-diamond', name: 'Gradient Diamond', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/gradient-diamond.png', rarity: 'legendary', unlockedAt: 20, price: 800 },
  { id: 'empress', name: 'Empress', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/empress.png', rarity: 'legendary', battleWinsRequired: 25, price: 1000 },
  { id: 'wings', name: 'Wings', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wings.png', rarity: 'legendary', battleWinsRequired: 10, price: 1200 },
  { id: 'dragon-frame', name: 'Dragon Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-frame.png', rarity: 'legendary', unlockedAt: 25, price: 1000 },
  { id: 'vine-frame', name: 'Vine Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/vine-frame.png', rarity: 'epic', unlockedAt: 15, price: 600 },
  { id: 'cyber-frame', name: 'Cyber Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/cyber-frame.png', rarity: 'epic', unlockedAt: 18, price: 700 },
  { id: 'ice-shard', name: 'Ice Shard', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-shard.png', rarity: 'epic', unlockedAt: 20, price: 800 },
];

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

// Helper function to fetch user profile data
async function fetchUserProfile(userId) {
  try {
    const { Item: user } = await dynamoDB.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
    }));

    if (!user) {
      return null;
    }

    // Resolve selectedFrame to full object if it's just an ID
    let selectedFrame = user.selectedFrame;
    if (selectedFrame && typeof selectedFrame === 'string') {
      selectedFrame = defaultFrames.find(f => f.id === selectedFrame);
    }

    return {
      id: user.id,
      username: user.username,
      profileImageUrl: user.profileImageUrl,
      selectedFrame: selectedFrame || null,
      highestLevel: user.highestLevel || 1,
    };
  } catch (error) {
    console.error(`Error fetching user profile for ${userId}:`, error);
    return null;
  }
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.error('No valid Authorization header found in getActiveBattles');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Verify and decode the JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      console.error('JWT verification failed in getActiveBattles:', jwtError);
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token', error: jwtError.message }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      console.error('No user ID found in JWT in getActiveBattles');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    // Get active battles where user is either challenger or opponent
    const [challengerBattles, opponentBattles] = await Promise.all([
      dynamoDB.send(new QueryCommand({
        TableName: process.env.BATTLES_TABLE,
        IndexName: 'status-challenger-index',
        KeyConditionExpression: '#s = :status AND challengerId = :challengerId',
        ExpressionAttributeNames: {
          '#s': 'status'
        },
        ExpressionAttributeValues: {
          ':status': 'active',
          ':challengerId': userId,
        },
      })),
      dynamoDB.send(new QueryCommand({
        TableName: process.env.BATTLES_TABLE,
        IndexName: 'status-opponent-index',
        KeyConditionExpression: '#s = :status AND opponentId = :opponentId',
        ExpressionAttributeNames: {
          '#s': 'status'
        },
        ExpressionAttributeValues: {
          ':status': 'active',
          ':opponentId': userId,
        },
      })),
    ]);

    const battles = [
      ...(challengerBattles.Items || []),
      ...(opponentBattles.Items || []),
    ];

    // Sort battles by creation date (most recent first)
    battles.sort((a, b) => {
      const dateA = new Date(a.createdAt);
      const dateB = new Date(b.createdAt);
      return dateB - dateA;
    });

    // Enrich battles with user profile data
    const enrichedBattles = await Promise.all(battles.map(async (battle) => {
      // Fetch user profiles for both challenger and opponent
      const [challengerProfile, opponentProfile] = await Promise.all([
        fetchUserProfile(battle.challengerId),
        fetchUserProfile(battle.opponentId),
      ]);

      return {
        ...battle,
        challenger: challengerProfile,
        opponent: opponentProfile,
      };
    }));

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        battles: enrichedBattles,
      }),
    };
  } catch (error) {
    console.error('Error getting active battles:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Internal server error' }),
    };
  }
}; 