const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, GetCommand, QueryCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');

const dynamoDB = DynamoDBDocumentClient.from(new DynamoDBClient({}));

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    console.log('createBattleInvitation handler started');
    console.log('Event:', JSON.stringify(event, null, 2));
    console.log('Environment variables:', {
      USERS_TABLE: process.env.USERS_TABLE,
      BATTLES_TABLE: process.env.BATTLES_TABLE,
      STAGE: process.env.STAGE,
      JWT_SECRET: process.env.JWT_SECRET ? 'SET' : 'NOT SET'
    });
    
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.log('No valid Authorization header found');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    console.log('Token extracted successfully');
    
    // Verify and decode the JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
      console.log('JWT verified successfully, user ID:', decoded.id);
    } catch (jwtError) {
      console.error('JWT verification failed:', jwtError);
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token', error: jwtError.message }),
      };
    }

    const challengerId = decoded.id;
    if (!challengerId) {
      console.log('No user ID found in JWT');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    console.log('Parsing request body...');
    const { opponentUsername } = JSON.parse(event.body);
    console.log('Opponent username:', opponentUsername);

    if (!opponentUsername) {
      console.log('No opponent username provided');
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Opponent username is required' }),
      };
    }

    // Get challenger user info
    console.log('Getting challenger info from table:', process.env.USERS_TABLE);
    let challengerResponse;
    try {
      challengerResponse = await dynamoDB.send(new GetCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id: challengerId },
      }));

      if (!challengerResponse.Item) {
        console.log('Challenger not found:', challengerId);
        return {
          statusCode: 404,
          headers: corsHeaders,
          body: JSON.stringify({ message: 'Challenger not found' }),
        };
      }

      console.log('Challenger found:', challengerResponse.Item.username);
    } catch (error) {
      console.error('Error getting challenger:', error);
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Error getting challenger info', error: error.message }),
      };
    }

    // Find opponent by username
    console.log('Finding opponent by username:', opponentUsername);
    console.log('Username type:', typeof opponentUsername);
    console.log('Username length:', opponentUsername ? opponentUsername.length : 'null');
    console.log('Username trimmed:', opponentUsername ? opponentUsername.trim() : 'null');
    
    let opponent;
    try {
      console.log('Scanning all users for debug and matching...');
      const allUsersResponse = await dynamoDB.send(new ScanCommand({
        TableName: process.env.USERS_TABLE,
        Limit: 1000 // get up to 1000 users for matching
      }));
      const allUsers = allUsersResponse.Items || [];
      console.log('All users sample:', allUsers.slice(0, 10).map(u => ({ id: u.id, username: u.username, type: typeof u.username, length: u.username ? u.username.length : null })));

      // Try to match by trimmed/lowercased username
      const searched = opponentUsername.trim().toLowerCase();
      opponent = allUsers.find(u => (u.username && typeof u.username === 'string' && u.username.trim().toLowerCase() === searched));
      if (!opponent) {
        // fallback: try exact match
        opponent = allUsers.find(u => u.username === opponentUsername);
      }
      if (!opponent) {
        console.log('Opponent not found after all matching attempts:', opponentUsername);
        return {
          statusCode: 404,
          headers: corsHeaders,
          body: JSON.stringify({ 
            message: 'Opponent not found',
            searchedUsername: opponentUsername,
            searchedLower: searched,
            availableUsers: allUsers.slice(0, 10).map(u => u.username),
            allUserDebug: allUsers.slice(0, 10).map(u => ({ username: u.username, type: typeof u.username, length: u.username ? u.username.length : null }))
          }),
        };
      }
      console.log('Opponent found after matching:', opponent.username);
    } catch (opponentError) {
      console.error('Error finding opponent:', opponentError);
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ 
          message: 'Error finding opponent', 
          error: opponentError.message,
          searchedUsername: opponentUsername
        }),
      };
    }

    // Prevent self-invitation
    if (challengerId === opponent.id) {
      console.log('Self-invitation attempted');
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Cannot challenge yourself' }),
      };
    }

    // Check if there's already a pending invitation
    const battlesTable = process.env.BATTLES_TABLE || `wordflect-backend-battles-${process.env.STAGE || 'prod'}`;
    console.log('Checking existing invitations in table:', battlesTable);
    
    // Temporarily skip existing invitation check to test basic functionality
    console.log('Skipping existing invitation check for now');
    /*
    try {
      const existingInvitationResponse = await dynamoDB.send(new QueryCommand({
        TableName: battlesTable,
        IndexName: 'status-challenger-index',
        KeyConditionExpression: 'status = :status AND challengerId = :challengerId',
        FilterExpression: 'opponentId = :opponentId',
        ExpressionAttributeValues: {
          ':status': 'pending',
          ':challengerId': challengerId,
          ':opponentId': opponent.id,
        },
      }));

      if (existingInvitationResponse.Items && existingInvitationResponse.Items.length > 0) {
        console.log('Existing invitation found');
        return {
          statusCode: 409,
          headers: corsHeaders,
          body: JSON.stringify({ message: 'Battle invitation already sent to this user' }),
        };
      }
    } catch (battlesError) {
      console.error('Error with battles table operations:', battlesError);
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ 
          message: 'Error with battles table', 
          error: battlesError.message,
          table: battlesTable
        }),
      };
    }
    */

    // Create battle invitation
    const invitationId = uuidv4();
    const invitation = {
      id: invitationId,
      challengerId: String(challengerId),
      opponentId: String(opponent.id),
      status: 'pending',
      challengerScore: 0,
      opponentScore: 0,
      challengerPlayed: false,
      opponentPlayed: false,
      winner: null,
      createdAt: new Date().toISOString(),
      challenger: {
        id: String(challengerId),
        username: challengerResponse.Item.username,
        level: challengerResponse.Item.highestLevel || 1,
        profileImageUrl: challengerResponse.Item.profileImageUrl,
      },
      opponent: {
        id: String(opponent.id),
        username: opponent.username,
        level: opponent.highestLevel || 1,
        profileImageUrl: opponent.profileImageUrl,
      },
    };

    console.log('Writing invitation to DynamoDB:', JSON.stringify(invitation, null, 2));

    await dynamoDB.send(new PutCommand({
      TableName: battlesTable,
      Item: invitation,
    }));

    console.log('Invitation created successfully');
    return {
      statusCode: 201,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'Battle invitation sent successfully',
        invitation,
      }),
    };
  } catch (error) {
    console.error('Error creating battle invitation:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'Internal server error', 
        error: error.message,
        stack: error.stack
      }),
    };
  }
}; 