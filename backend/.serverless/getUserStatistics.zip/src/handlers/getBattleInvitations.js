const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, QueryCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');

const dynamoDB = DynamoDBDocumentClient.from(new DynamoDBClient({}));

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    console.log('getBattleInvitations handler started');
    console.log('Event:', JSON.stringify(event, null, 2));
    
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.log('No valid Authorization header found');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    console.log('Token extracted successfully');
    
    // Verify and decode the JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
      console.log('JWT verified successfully, user ID:', decoded.id);
    } catch (jwtError) {
      console.error('JWT verification failed:', jwtError);
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token', error: jwtError.message }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      console.log('No user ID found in JWT');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    console.log('getBattleInvitations: userId:', userId);

    // Get pending invitations where user is the opponent (received)
    const receivedResponse = await dynamoDB.send(new QueryCommand({
      TableName: process.env.BATTLES_TABLE,
      IndexName: 'status-opponent-index',
      KeyConditionExpression: '#s = :status AND opponentId = :opponentId',
      ExpressionAttributeNames: {
        '#s': 'status'
      },
      ExpressionAttributeValues: {
        ':status': 'pending',
        ':opponentId': userId,
      },
    }));
    const receivedInvitations = (receivedResponse.Items || []).map(invite => ({ ...invite, type: 'received' }));
    console.log('getBattleInvitations: receivedInvitations:', receivedInvitations);

    // Get pending invitations where user is the challenger (sent)
    const sentResponse = await dynamoDB.send(new QueryCommand({
      TableName: process.env.BATTLES_TABLE,
      IndexName: 'status-challenger-index',
      KeyConditionExpression: '#s = :status AND challengerId = :challengerId',
      ExpressionAttributeNames: {
        '#s': 'status'
      },
      ExpressionAttributeValues: {
        ':status': 'pending',
        ':challengerId': userId,
      },
    }));
    const sentInvitations = (sentResponse.Items || []).map(invite => ({ ...invite, type: 'sent' }));
    console.log('getBattleInvitations: sentInvitations:', sentInvitations);

    // Combine and return
    const invitations = [...receivedInvitations, ...sentInvitations];
    console.log('getBattleInvitations: final invitations:', invitations);

    // Helper to fetch user profile
    async function fetchUserProfile(userId) {
      if (!userId) return null;
      try {
        const { Item } = await dynamoDB.send(new GetCommand({
          TableName: process.env.USERS_TABLE,
          Key: { id: userId },
        }));
        if (!Item) return null;
        return {
          id: Item.id,
          username: Item.username,
          highestLevel: Item.highestLevel || 1,
          profileImageUrl: Item.profileImageUrl || null,
          belt: Item.belt || null,
          // Add more fields as needed
        };
      } catch (err) {
        console.error('Error fetching user profile for', userId, err);
        return null;
      }
    }

    // Enrich invitations with up-to-date user info
    const enrichedInvitations = await Promise.all(
      invitations.map(async (invite) => {
        const [challenger, opponent] = await Promise.all([
          fetchUserProfile(invite.challengerId),
          fetchUserProfile(invite.opponentId),
        ]);
        return {
          ...invite,
          challenger,
          opponent,
        };
      })
    );

    // Sort invitations by creation date (most recent first)
    enrichedInvitations.sort((a, b) => {
      const dateA = new Date(a.createdAt);
      const dateB = new Date(b.createdAt);
      return dateB - dateA;
    });

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        invitations: enrichedInvitations,
      }),
    };
  } catch (error) {
    console.error('Error getting battle invitations:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Internal server error' }),
    };
  }
}; 