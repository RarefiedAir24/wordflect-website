const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const WORD_OF_THE_DAY_TABLE = process.env.WORD_OF_THE_DAY_TABLE || 'wordflect-backend-word-of-the-day-prod';

function getTodayDateString() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getWordList() {
  const words = [
    // Animals
    'dragon', 'eagle', 'tiger', 'panda', 'koala', 'dolphin', 'penguin', 'flamingo', 'giraffe', 'elephant',
    'kangaroo', 'jaguar', 'leopard', 'cheetah', 'rhino', 'hippo', 'zebra', 'gazelle', 'antelope', 'buffalo',
    
    // Nature
    'forest', 'ocean', 'river', 'mountain', 'desert', 'island', 'volcano', 'canyon', 'waterfall', 'meadow',
    'jungle', 'savanna', 'tundra', 'glacier', 'reef', 'lagoon', 'bay', 'gulf', 'strait', 'channel',
    
    // Colors
    'purple', 'orange', 'yellow', 'silver', 'golden', 'crimson', 'emerald', 'sapphire', 'ruby', 'amber',
    'turquoise', 'magenta', 'indigo', 'violet', 'scarlet', 'maroon', 'navy', 'teal', 'coral', 'peach',
    
    // Objects
    'castle', 'bridge', 'tower', 'palace', 'temple', 'monument', 'statue', 'fountain', 'lighthouse', 'windmill',
    'cottage', 'mansion', 'villa', 'chalet', 'cabin', 'barn', 'shed', 'garage', 'studio', 'library',
    
    // Food
    'pizza', 'burger', 'sandwich', 'taco', 'sushi', 'pasta', 'salad', 'soup', 'stew', 'curry',
    'lasagna', 'ravioli', 'dumpling', 'spring', 'noodle', 'rice', 'bread', 'cake', 'cookie', 'muffin',
    
    // Activities
    'dancing', 'singing', 'painting', 'writing', 'reading', 'cooking', 'gardening', 'fishing', 'hiking', 'swimming',
    'running', 'cycling', 'skiing', 'surfing', 'climbing', 'yoga', 'meditation', 'photography', 'knitting', 'sewing',
    
    // Emotions/States
    'happy', 'joyful', 'peaceful', 'serene', 'excited', 'curious', 'brave', 'strong', 'gentle', 'kind',
    'loving', 'caring', 'hopeful', 'dreamy', 'magical', 'mystical', 'wonderful', 'amazing', 'fantastic', 'brilliant',
    
    // Abstract
    'freedom', 'wisdom', 'courage', 'honor', 'truth', 'beauty', 'grace', 'power', 'spirit', 'soul',
    'dream', 'hope', 'faith', 'love', 'peace', 'joy', 'life', 'light', 'dark', 'shadow'
  ];
  return words.filter(w => w.length >= 4 && w.length <= 8 && /^[a-z]+$/.test(w));
}

async function setWordOfTheDay() {
  const words = getWordList();
  if (!words.length) throw new Error('No valid words found');
  
  const randomWord = words[Math.floor(Math.random() * words.length)];
  const date = getTodayDateString();
  
  await dynamoDB.send(new PutCommand({
    TableName: WORD_OF_THE_DAY_TABLE,
    Item: { date, word: randomWord },
  }));
  
  console.log(`Set word of the day for ${date}: ${randomWord}`);
  return { date, word: randomWord };
}

exports.handler = async (event, context) => {
  try {
    console.log('Setting word of the day...');
    const result = await setWordOfTheDay();
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
      },
      body: JSON.stringify({
        message: 'Word of the day set successfully',
        data: result
      })
    };
  } catch (error) {
    console.error('Failed to set word of the day:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
      },
      body: JSON.stringify({
        message: 'Failed to set word of the day',
        error: error.message
      })
    };
  }
}; 