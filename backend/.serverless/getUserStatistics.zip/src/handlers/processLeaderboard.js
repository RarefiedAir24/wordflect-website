const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);
const USERS_TABLE = process.env.USERS_TABLE;

exports.handler = async (event) => {
  console.log('Starting monthly leaderboard processing...');

  try {
    // 1. Determine the date range for the previous month
    const now = new Date();
    const lastMonthEndDate = new Date(now.getFullYear(), now.getMonth(), 0); // Last day of previous month
    const lastMonthStartDate = new Date(now.getFullYear(), now.getMonth() - 1, 1); // First day of previous month
    
    console.log(`Processing leaderboard for the period: ${lastMonthStartDate.toISOString()} to ${lastMonthEndDate.toISOString()}`);

    // 2. Scan the entire users table
    // In a production environment with millions of users, a more efficient approach
    // like exporting data to S3 and processing with Athena/Glue would be better.
    // For the current scale, a Scan is acceptable.
    const scanParams = {
      TableName: USERS_TABLE,
      ProjectionExpression: 'id, username, allFoundWords'
    };
    const { Items: users } = await dynamoDB.send(new ScanCommand(scanParams));

    if (!users || users.length === 0) {
      console.log('No users found. Exiting.');
      return;
    }

    // 3. Calculate monthly score for each user
    const monthlyScores = users.map(user => {
      const monthlyWords = (user.allFoundWords || []).filter(word => {
        const wordDate = new Date(word.date);
        return wordDate >= lastMonthStartDate && wordDate <= lastMonthEndDate;
      });

      const monthlyScore = monthlyWords.reduce((total, word) => {
        // This assumes a simple scoring logic (length of word). 
        // This should be updated if a more complex scoring system is in place.
        return total + word.word.length;
      }, 0);
      
      return {
        userId: user.id,
        username: user.username,
        monthlyScore,
      };
    }).filter(user => user.monthlyScore > 0); // Only consider users with scores

    // 4. Sort users by monthly score to find the top 3
    monthlyScores.sort((a, b) => b.monthlyScore - a.monthlyScore);
    const winners = monthlyScores.slice(0, 3);

    console.log('Top 3 winners for the month:', winners);

    // 5. Update the profiles of the winners
    for (let i = 0; i < winners.length; i++) {
      const winner = winners[i];
      let finishField;

      if (i === 0) finishField = 'firstPlaceFinishes';
      else if (i === 1) finishField = 'secondPlaceFinishes';
      else if (i === 2) finishField = 'thirdPlaceFinishes';
      
      if (finishField) {
        try {
          await dynamoDB.send(new UpdateCommand({
            TableName: USERS_TABLE,
            Key: { id: winner.userId },
            UpdateExpression: 'ADD #finishField :inc',
            ExpressionAttributeNames: {
              '#finishField': finishField
            },
            ExpressionAttributeValues: {
              ':inc': 1
            }
          }));
          console.log(`Successfully updated ${finishField} for user ${winner.username}`);
        } catch (error) {
          console.error(`Failed to update ${finishField} for user ${winner.username}:`, error);
        }
      }
    }

    console.log('Monthly leaderboard processing complete.');
    return { statusCode: 200, body: JSON.stringify({ message: 'Leaderboard processed successfully.' }) };

  } catch (error) {
    console.error('Error processing monthly leaderboard:', error);
    return { statusCode: 500, body: JSON.stringify({ message: 'An error occurred during leaderboard processing.' }) };
  }
}; 