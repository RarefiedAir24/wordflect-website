const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand, GetCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const MISSIONS_TABLE = process.env.MISSIONS_TABLE;
const WORD_OF_THE_DAY_TABLE = process.env.WORD_OF_THE_DAY_TABLE || 'WordOfTheDay';

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

// Helper: get week number
function getWeekNumber(d) {
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay()||7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1)/7);
  return weekNo;
}

// Helper: fetch all missions from DynamoDB
async function fetchAllMissions() {
  const result = await dynamoDB.send(new ScanCommand({ TableName: MISSIONS_TABLE }));
  return result.Items || [];
}

// Helper function to check if text describes a score-based mission
const textDescribesScore = (text) => {
  const t = (text || '').toLowerCase();
  const scoreKeywords = ['score', 'points', 'perfect score', 'high scorer'];
  return scoreKeywords.some(keyword => t.includes(keyword));
};

// Helper function to check if text describes a word-finding mission
const textDescribesWordFinding = (text) => {
  const t = (text || '').toLowerCase();
  return t.includes('find') && t.includes('word');
};

// Helper function to check if a mission is word-finding based (alias for compatibility)
const isWordFindingMission = (text) => {
  return textDescribesWordFinding(text);
};

// Helper: check and update mission progress
function getMissionProgressIncrement(mission, gameData, userMission, user, period, allFoundWords) {
  const objective = (mission.objective || mission.title || '').toString();
  const lowerObjective = objective.toLowerCase();

  // ABSOLUTE GUARD: Only allow battle missions to increment if isBattle is true
  if (lowerObjective.includes('battle') && gameData.isBattle !== true) {
    return 0;
  }
  
  // Prevent regular games from incrementing battle missions
  if (lowerObjective.includes('battle') && !gameData.isBattle) {
    return 0;
  }

  // If mission has minWordLength and maxWordLength, use them for progress calculation
  if (mission.minWordLength && mission.maxWordLength) {
    const count = gameData.words.filter(w => {
      const wordLength = (w.word || w).length;
      return wordLength >= mission.minWordLength && wordLength <= mission.maxWordLength;
    }).length;
    return count;
  }
  
  // If mission has only minWordLength, use it for progress calculation
  if (mission.minWordLength) {
    const count = gameData.words.filter(w => (w.word || w).length >= mission.minWordLength).length;
    return count;
  }

  // --- FIXED LOGIC FOR LONG WORD MISSIONS ---
  // If the mission is about finding long words (e.g., 8+ letters or "long words")
  if (isWordFindingMission(objective) && (lowerObjective.includes('8+') || lowerObjective.includes('8 letters') || lowerObjective.includes('eight') || lowerObjective.includes('long word'))) {
    // Count only words with 8 or more letters
    const count = gameData.words.filter(w => (w.word || w).length >= 8).length;
    return count;
  }

  // Handle theme word missions BEFORE word-finding missions
  if (lowerObjective.includes('theme word') || lowerObjective.includes('daily theme word') || lowerObjective.includes('find daily theme words')) {
    // Return 1 if all theme words were completed today, 0 otherwise
    console.log(`🎯 Theme word mission detected: ${objective}, all theme words completed: ${gameData.allThemeWordsCompleted}`);
    return gameData.allThemeWordsCompleted ? 1 : 0;
  }
  
  // Handle theme word missions by mission ID
  if (mission.id === 'daily-find-daily-theme-words') {
    // Return 1 if all theme words were completed today, 0 otherwise
    console.log(`🎯 Theme word mission detected by ID: ${mission.id}, all theme words completed: ${gameData.allThemeWordsCompleted}`);
    return gameData.allThemeWordsCompleted ? 1 : 0;
  }

  // Handle word-finding missions (generic, e.g., 'Find X words')
  if (textDescribesWordFinding(objective) || textDescribesWordFinding(mission.title)) {
    // For global missions, count total unique words from user's history
    if (period === 'global') {
      // Count all unique words from user's history
      return allFoundWords.length;
    }
    // For daily/weekly missions, count words from current game
    return gameData.words.length;
  }

  // Handle score-based missions (objective or title)
  if (textDescribesScore(objective) || textDescribesScore(mission.title)) {
    // For missions requiring a specific score in a single game
    const objLower = (objective || '').toLowerCase();
    const titleLower = (mission.title || '').toLowerCase();
    if (objLower.includes('in a game') || objLower.includes('single game') || titleLower.includes('in a game') || titleLower.includes('single game')) {
      return gameData.score >= mission.target && !userMission.completed ? mission.target : 0;
    }
    // For missions requiring cumulative score (e.g., "Score X points this week")
    return gameData.score;
  }

  // Handle 'Use Hint' missions
  if (lowerObjective.includes('use') && lowerObjective.includes('hint')) {
    return gameData.hintsUsed || 0;
  }

  // Handle 'Complete Game No Powerups' missions
  if (lowerObjective.includes('complete game no powerups') || lowerObjective.includes('complete games no powerups')) {
    // Reward 1 point for completing a game without using any powerups
    const totalPowerupsUsed = (gameData.hintsUsed || 0) + (gameData.transformsUsed || 0) + (gameData.shufflesUsed || 0) + (gameData.timeExtensionsUsed || 0);
    return totalPowerupsUsed === 0 ? 1 : 0;
  }

  // Handle battle-specific missions
  if (lowerObjective.includes('battle')) {
    // Battle-specific mission logic
    if (lowerObjective.includes('win') && lowerObjective.includes('battle')) {
      return gameData.won ? 1 : 0;
    }
    if (lowerObjective.includes('play') && lowerObjective.includes('battle')) {
      return 1; // Count each battle played
    }
    if (lowerObjective.includes('score') && lowerObjective.includes('battle')) {
      return gameData.score;
    }
    if (lowerObjective.includes('find') && lowerObjective.includes('word') && lowerObjective.includes('battle')) {
      return gameData.words.length;
    }
  }


  
  // Debug: Log all mission objectives to see what we're missing
  console.log(`🔍 Mission debug - Objective: "${objective}", Lower: "${lowerObjective}"`);

  // Handle other mission types
  switch (objective) {
    case 'Find Daily Theme Words':
    case 'daily-find-daily-theme-words':
      // Return 1 if all theme words were completed today, 0 otherwise
      console.log(`🎯 Exact theme word mission match: ${objective}, all theme words completed: ${gameData.allThemeWordsCompleted}`);
      return gameData.allThemeWordsCompleted ? 1 : 0;
    case 'Play 1 Game Today':
    case 'Play X Games Today':
    case 'Play X Games This Week':
    case 'Play X Games Total':
      return 1;
    case 'Word Warrior': // Find X words today (objective sometimes equals title)
    case 'Word Collector': // Find X words this week
    case 'Word Master': // Find X words total
      if (mission.id === 'daily-find-daily-theme-words') {
        console.log(`🎯 Theme word mission caught by Word Warrior case, returning 0`);
        return 0;
      }
      return gameData.words.length;
    case 'Consistent Player': // Play X days in a row (weekly)
    case '3-Day Login Streak':
    case '5-Day Login Streak':
    case '7-Day Login Streak':
    case 'Consistent Winner':
      // These require login/win streak logic, not handled in a single game
      return 0;
    case 'Win 3 Games':
    case 'Win 5 Games':
    case 'Win 7 Games':
      return gameData.won ? 1 : 0;
    case 'Level Up': // Reach level N
    case 'Level 20 Achieved':
    case 'Level 30 Achieved':
    case 'Level 40 Achieved':
    case 'Level 50 Achieved':
    case 'Level 60 Achieved':
    case 'Level 70 Achieved':
    case 'Level 80 Achieved':
    case 'Level 90 Achieved':
    case 'Level 100 Achieved':
      return user.highestLevel >= mission.target && !userMission.completed ? mission.target : 0;
    default:
      // Don't count theme word mission in default case
      if (mission.id === 'daily-find-daily-theme-words') {
        console.log(`🎯 Theme word mission caught by default case, returning 0`);
        return 0;
      }
      // If title signifies word-finding (e.g., 'Word Warrior'), count words
      const titleLower = (mission.title || '').toLowerCase();
      if (titleLower.includes('word warrior') || titleLower.includes('word collector') || titleLower.includes('word master')) {
        return gameData.words.length;
      }
      // Handle 'Play X Games' missions (e.g., 'Play 3 Games', 'Play 5 Games', etc.)
      if (/play\s*\d*\s*game/i.test(objective) || /play\s*\d*\s*game/i.test(mission.title)) {
        return 1;
      }
      // Fallback: if mission has a custom field like mission.type or mission.objective, handle here
      return 0;
  }
}

async function fetchWordOfTheDay() {
  const today = new Date().toISOString().slice(0, 10);
  const { Item } = await dynamoDB.send(new GetCommand({
    TableName: WORD_OF_THE_DAY_TABLE,
    Key: { date: today },
  }));
  return Item?.word || null;
}

// Helper: check if mission should be reset based on period (consistent with getUserMissions)
function shouldReset(lastProgress, period) {
  // If no progress was ever made, don't reset
  if (!lastProgress) return false;
  
  const now = new Date();
  const last = new Date(lastProgress);
  
  if (period === 'daily') {
    // Convert to EST
    const estNow = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    const estLast = new Date(last.toLocaleString('en-US', { timeZone: 'America/New_York' }));
    return estNow.toDateString() !== estLast.toDateString();
  } else if (period === 'weekly') {
    // Reset every Monday (start of new week)
    const nowWeek = now.getFullYear() + '-' + getWeekNumber(now);
    const lastWeek = last.getFullYear() + '-' + getWeekNumber(last);
    return nowWeek !== lastWeek;
  }
  return false;
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    const { id, score, words, level, won, hintsUsed, shufflesUsed, transformsUsed, timeExtensionsUsed, allThemeWordsCompleted, themeWordsFoundToday, sessionDuration, gameStartTime } = JSON.parse(event.body || '{}');
    if (!id || typeof score !== 'number' || !Array.isArray(words)) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'id, score, and words are required.' }),
      };
    }
    console.log('Incoming request data:', { id, score, words, level, won, hintsUsed, shufflesUsed, transformsUsed, timeExtensionsUsed, allThemeWordsCompleted, themeWordsFoundToday, sessionDuration, gameStartTime });
    // Fetch current user data
    const { Item: user } = await dynamoDB.send(new GetCommand({ TableName: process.env.USERS_TABLE, Key: { id } }));
    if (!user) {
      return { statusCode: 404, body: JSON.stringify({ message: 'User not found.' }) };
    }
    // MIGRATION: If user has points but not flectcoins, copy points to flectcoins
    if (user.points !== undefined && user.flectcoins === undefined) {
      await dynamoDB.send(new UpdateCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id },
        UpdateExpression: 'SET flectcoins = :f',
        ExpressionAttributeValues: { ':f': user.points },
      }));
      user.flectcoins = user.points;
    }
    // Update stats
    const gamesPlayed = (user.gamesPlayed ?? 0) + 1;
    const topScore = Math.max(user.topScore ?? 0, score);
    const allFoundWordsArr = Array.isArray(user.allFoundWords) ? user.allFoundWords : [];
    function normalizeWordEntry(entry) {
      if (typeof entry === 'string') return { word: entry, date: null };
      if (entry && typeof entry.word === 'string') return { word: entry.word, date: entry.date || null };
      return null;
    }
    const combinedWords = [...allFoundWordsArr, ...words];
    const wordMap = {};
    for (const entry of combinedWords) {
      const norm = normalizeWordEntry(entry);
      if (!norm) continue;
      if (!wordMap[norm.word]) {
        wordMap[norm.word] = norm.date;
      } else if (norm.date && wordMap[norm.word] && norm.date < wordMap[norm.word]) {
        wordMap[norm.word] = norm.date;
      }
    }
    const allFoundWords = Object.entries(wordMap).map(([word, date]) => ({ word, date }));
    const longestWord = allFoundWords.length > 0 ? allFoundWords.reduce((longest, entry) => entry.word.length > longest.length ? entry.word : longest, '') : '';
    const newGamesPlayed = gamesPlayed;
    const newTopScore = topScore;
    const newLongestWord = longestWord;
    const highestLevel = Math.max(user.highestLevel ?? 1, level ?? 1);
    // Calculate time tracking data
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const thisWeek = `${now.getFullYear()}-W${getWeekNumber(now).toString().padStart(2, '0')}`;
    const thisMonth = now.toISOString().substring(0, 7);
    
    // Calculate session duration if provided
    let actualSessionDuration = 0;
    if (sessionDuration && typeof sessionDuration === 'number') {
      actualSessionDuration = sessionDuration;
    } else if (gameStartTime) {
      const startTime = new Date(gameStartTime);
      actualSessionDuration = Math.floor((now.getTime() - startTime.getTime()) / 1000);
    }
    
    // Update daily stats
    const dailyStats = user.dailyStats || {};
    const todayStats = dailyStats[today] || {
      gamesPlayed: 0,
      highScore: 0,
      totalScore: 0,
      wordsFound: 0,
      playTime: 0
    };
    
    todayStats.gamesPlayed += 1;
    todayStats.highScore = Math.max(todayStats.highScore, score);
    todayStats.totalScore += score;
    todayStats.wordsFound += words.length;
    todayStats.playTime += actualSessionDuration;
    
    dailyStats[today] = todayStats;
    
    // Update weekly stats
    const weeklyStats = user.weeklyStats || {};
    const thisWeekStats = weeklyStats[thisWeek] || {
      gamesPlayed: 0,
      highScore: 0,
      totalScore: 0,
      wordsFound: 0,
      playTime: 0
    };
    
    thisWeekStats.gamesPlayed += 1;
    thisWeekStats.highScore = Math.max(thisWeekStats.highScore, score);
    thisWeekStats.totalScore += score;
    thisWeekStats.wordsFound += words.length;
    thisWeekStats.playTime += actualSessionDuration;
    
    weeklyStats[thisWeek] = thisWeekStats;
    
    // Update monthly stats
    const monthlyStats = user.monthlyStats || {};
    const thisMonthStats = monthlyStats[thisMonth] || {
      gamesPlayed: 0,
      highScore: 0,
      totalScore: 0,
      wordsFound: 0,
      playTime: 0
    };
    
    thisMonthStats.gamesPlayed += 1;
    thisMonthStats.highScore = Math.max(thisMonthStats.highScore, score);
    thisMonthStats.totalScore += score;
    thisMonthStats.wordsFound += words.length;
    thisMonthStats.playTime += actualSessionDuration;
    
    monthlyStats[thisMonth] = thisMonthStats;
    
    // Update total play time
    const totalPlayTime = (user.totalPlayTime || 0) + actualSessionDuration;
    
    // Update daily play time
    const dailyPlayTime = user.dailyPlayTime || {};
    dailyPlayTime[today] = (dailyPlayTime[today] || 0) + actualSessionDuration;
    
    // Update longest session
    const longestSession = Math.max(user.longestSession || 0, actualSessionDuration);
    
    // Add session to history
    const sessionHistory = user.sessionHistory || [];
    const sessionData = {
      sessionId: `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      startTime: gameStartTime || now.toISOString(),
      endTime: now.toISOString(),
      duration: actualSessionDuration,
      score: score,
      level: level || 1,
      wordsFound: words.length
    };
    sessionHistory.push(sessionData);
    
    // Keep only last 100 sessions to prevent unlimited growth
    if (sessionHistory.length > 100) {
      sessionHistory.splice(0, sessionHistory.length - 100);
    }

    // Store theme words found today
    const themeWordsFoundTodayArray = Array.isArray(themeWordsFoundToday) ? themeWordsFoundToday : [];
    console.log('🎯 Storing theme words found today:', themeWordsFoundTodayArray);

    await dynamoDB.send(new UpdateCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id },
      UpdateExpression: 'SET gamesPlayed = :gp, topScore = :ts, longestWord = :lw, allFoundWords = :afw, highestLevel = :hl, dailyStats = :ds, weeklyStats = :ws, monthlyStats = :ms, totalPlayTime = :tpt, dailyPlayTime = :dpt, longestSession = :ls, sessionHistory = :sh, themeWordsFoundToday = :twft',
      ExpressionAttributeValues: {
        ':gp': newGamesPlayed,
        ':ts': newTopScore,
        ':lw': newLongestWord,
        ':afw': allFoundWords,
        ':hl': highestLevel,
        ':ds': dailyStats,
        ':ws': weeklyStats,
        ':ms': monthlyStats,
        ':tpt': totalPlayTime,
        ':dpt': dailyPlayTime,
        ':ls': longestSession,
        ':sh': sessionHistory,
        ':twft': themeWordsFoundTodayArray
      },
    }));

    let totalPointsToAdd = 0;
    let totalGemsToAdd = 0;
    // --- Dynamic Mission Logic ---
    const allMissions = await fetchAllMissions();
    let missions = user.missions || { daily: {}, weekly: {}, global: {} };
    let missionsStats = user.missionsStats || { dailyCompleted: 0, weeklyCompleted: 0, globalCompleted: 0 };
    const nowISOString = now.toISOString();
    let missionsUpdated = false;
    const gameData = { score, words, level, won: !!won, hintsUsed: hintsUsed || 0, shufflesUsed: shufflesUsed || 0, transformsUsed: transformsUsed || 0, timeExtensionsUsed: timeExtensionsUsed || 0, allThemeWordsCompleted: allThemeWordsCompleted || false };
    // Fetch today's word of the day
    let wordOfTheDay = null;
    try {
      wordOfTheDay = await fetchWordOfTheDay();
    } catch (e) {
      console.error('Failed to fetch word of the day:', e);
    }
    for (const mission of allMissions) {
      const { id: missionId, target = 1, objective = '', title = '', description = '' } = mission;
      const period = (mission.type || '').toLowerCase();
      if (!['daily','weekly','global'].includes(period)) {
        console.log(`[MISSIONS] Skipping mission with unknown period:`, { missionId, missionType: mission.type, title, objective });
        continue;
      }
      // Initialize mission progress if it doesn't exist
      if (!missions[period]) {
        missions[period] = {};
      }
      if (!missions[period][missionId]) {
        missions[period][missionId] = { progress: 0, completed: false, lastCompleted: null, lastProgress: null };
      }
      let userMission = missions[period][missionId];

      // Check if mission should be reset based on period (using consistent logic)
      if (period === 'daily' || period === 'weekly') {
        const shouldResetMission = shouldReset(userMission.lastProgress, period);
        
        console.log(`[RESET-CHECK] Mission ${missionId} (${title}) - lastProgress: ${userMission.lastProgress}, shouldReset: ${shouldResetMission}, period: ${period}`);
        
        // Reset mission if we're in a new period
        if (shouldResetMission) {
          console.log(`[RESET-DEBUG] Resetting mission ${missionId} (${title} | ${objective}) for user ${id} - lastProgress: ${userMission.lastProgress}, period: ${period}`);
          userMission = { progress: 0, completed: false, lastCompleted: null, lastProgress: nowISOString };
          missions[period][missionId] = userMission; // Update the missions object
        }
      }

      // Update progress for all missions
      const beforeProgress = userMission.progress || 0;
      let progressIncrement = getMissionProgressIncrement(mission, gameData, userMission, user, period, allFoundWords);
      console.log(`[MISSIONS] Increment calc`, { missionId, period, title, objective, beforeProgress, progressIncrement });
      
      // Debug theme word mission specifically
      if (mission.id === 'daily-find-daily-theme-words') {
        console.log(`🎯 Theme word mission debug: ${mission.id}`);
        console.log(`   Objective: "${mission.objective}"`);
        console.log(`   Lower objective: "${mission.objective.toLowerCase()}"`);
        console.log(`   All theme words completed: ${gameData.allThemeWordsCompleted}`);
        console.log(`   Progress increment: ${progressIncrement}`);
      }
      
      // For global missions with word length requirements, count unique words from user's history
      if (period === 'global' && mission.minWordLength && mission.maxWordLength) {
        const uniqueWordsOfLength = allFoundWords.filter(entry => {
          const wordLength = entry.word.length;
          return wordLength >= mission.minWordLength && wordLength <= mission.maxWordLength;
        }).length;
        progressIncrement = Math.max(0, uniqueWordsOfLength - beforeProgress); // Only count new progress, prevent negative
      }
      
      // For global word-finding missions, count total unique words from user's history
      if (period === 'global' && (textDescribesWordFinding(objective) || textDescribesWordFinding(mission.title))) {
        const totalUniqueWords = allFoundWords.length;
        progressIncrement = Math.max(0, totalUniqueWords - beforeProgress); // Only count new progress, prevent negative
      }
      
      // Don't add progress if mission is already completed (except for global missions that can continue)
      if (userMission.completed && period !== 'global') {
        progressIncrement = 0;
      }
      
      const newProgress = beforeProgress + progressIncrement;
      const targetNumber = typeof mission.target === 'number' ? mission.target : parseInt((mission.target || '0'), 10) || 0;
      const isCompleted = newProgress >= targetNumber;

      // Check if mission depends on word of the day and wordOfTheDay is null
      const missionDependsOnWOTD =
        (mission.objective && (mission.objective.includes('{word}') || mission.objective.includes('Word of the Day'))) ||
        (mission.title && (mission.title.includes('{word}') || mission.title.includes('Word of the Day'))) ||
        (mission.description && (mission.description.includes('{word}') || mission.description.includes('word of the day')));
      if (missionDependsOnWOTD && !wordOfTheDay) {
        console.log(`[WARNING] Mission ${missionId} depends on word of the day, but word of the day is not found. Skipping update.`);
        continue;
      }

      console.log('Mission update details:', {
        missionId,
        period,
        beforeProgress,
        progressIncrement,
        newProgress,
        isCompleted,
        alreadyCompleted: userMission.completed,
        mission: {
          id: mission.id,
          type: mission.type,
          title: mission.title,
          objective: mission.objective,
          target: mission.target
        }
      });

      // Update mission progress
      userMission.progress = newProgress;
      if (isCompleted) {
        // Only award points/gems if the mission was not already completed
        const lastCompletedDate = userMission.lastCompleted ? new Date(userMission.lastCompleted) : null;
        const completedInCurrentPeriod = lastCompletedDate && 
          ((period === 'daily' && !shouldReset(userMission.lastCompleted, 'daily')) ||
           (period === 'weekly' && !shouldReset(userMission.lastCompleted, 'weekly')));
        
        // For global missions, only award if never completed before
        // For daily/weekly missions, only award if not completed in current period
        const shouldAwardReward = period === 'global' 
          ? !userMission.completed 
          : !userMission.completed && !completedInCurrentPeriod;
        
        if (shouldAwardReward) {
          userMission.lastCompleted = nowISOString;
          missionsStats[`${period}Completed`] = (missionsStats[`${period}Completed`] || 0) + 1;
          if (mission.reward) {
            if (mission.reward.type === 'flectcoins') totalPointsToAdd += mission.reward.amount || 0; // 'flectcoins' means reflectcoins
            if (mission.reward.type === 'gems') totalGemsToAdd += mission.reward.amount || 0;
          }
          console.log(`[REWARD] Awarding ${mission.reward?.amount || 0} ${mission.reward?.type || 'none'} for mission ${missionId} (${title})`);
        } else {
          console.log(`[NO-REWARD] Mission ${missionId} (${title}) already completed in current period or already completed`);
        }
        userMission.completed = true;
      }
      if (period === 'daily' || period === 'weekly') {
        userMission.lastProgress = nowISOString;
      }

      console.log(`[UPDATE] Mission ${missionId} (${objective}) for user ${id} - progress: ${beforeProgress} -> ${newProgress}`);

      // Update missions object
      missions[period][missionId] = userMission;
      missionsUpdated = true;
    }
    // Calculate powerup costs
    const HINT_COST = 25;
    const SHUFFLE_COST = 40;
    const FREEZE_COST = 80;
    const TIME_EXTENSION_COST = 100;
    
    const totalPowerupCost = 
      (hintsUsed || 0) * HINT_COST +
      (shufflesUsed || 0) * SHUFFLE_COST +
      (transformsUsed || 0) * FREEZE_COST +
      (timeExtensionsUsed || 0) * TIME_EXTENSION_COST;
    
    console.log(`[POWERUP-COSTS] Powerup usage: ${hintsUsed || 0} hints, ${shufflesUsed || 0} shuffles, ${transformsUsed || 0} transforms, ${timeExtensionsUsed || 0} time extensions`);
    console.log(`[POWERUP-COSTS] Total cost: ${totalPowerupCost} flectcoins`);
    
    if (missionsUpdated) {
      // Calculate net flectcoin change (rewards - powerup costs)
      const netFlectcoinChange = totalPointsToAdd - totalPowerupCost;
      
      // Update missions, stats, and apply net flectcoin change
      const updateParams = {
        TableName: process.env.USERS_TABLE,
        Key: { id },
        UpdateExpression: 'SET missions = :m, missionsStats = :s' + 
          (netFlectcoinChange !== 0 ? ' ADD flectcoins :f' : '') + 
          (totalGemsToAdd ? ', gems :g' : ''),
        ExpressionAttributeValues: {
          ':m': missions,
          ':s': missionsStats,
        },
      };
      if (netFlectcoinChange !== 0) updateParams.ExpressionAttributeValues[':f'] = netFlectcoinChange;
      if (totalGemsToAdd) updateParams.ExpressionAttributeValues[':g'] = totalGemsToAdd;
      await dynamoDB.send(new UpdateCommand(updateParams));
    } else if (totalPowerupCost > 0) {
      // If no missions were updated but powerups were used, still deduct the cost
      await dynamoDB.send(new UpdateCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id },
        UpdateExpression: 'ADD flectcoins :pc',
        ExpressionAttributeValues: { ':pc': -totalPowerupCost },
      }));
    }
    // --- End mission logic ---
    console.log('Updated user stats:', {
      gamesPlayed: newGamesPlayed,
      topScore: newTopScore,
      longestWord: newLongestWord,
      allFoundWords: allFoundWords,
      highestLevel
    });
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Stats updated successfully.' }),
      headers: corsHeaders,
    };
  } catch (error) {
    console.error('Update user stats error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'An error occurred. Please try again later.' }),
      headers: corsHeaders,
    };
  }
}; 