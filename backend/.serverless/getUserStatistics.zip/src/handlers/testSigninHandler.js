const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  console.log('Test signin handler started');
  console.log('Event:', JSON.stringify(event, null, 2));
  
  try {
    // Parse the request body
    const body = JSON.parse(event.body || '{}');
    console.log('Parsed body:', body);
    
    const { email, password } = body;
    
    if (!email || !password) {
      console.log('Missing email or password');
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Email and password are required' }),
      };
    }
    
    console.log('Looking up user with email:', email);
    
    // Get user from DynamoDB
    const getUserResult = await dynamoDB.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { email: email }
    }));
    
    console.log('GetUser result:', JSON.stringify(getUserResult, null, 2));
    
    if (!getUserResult.Item) {
      console.log('User not found');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid credentials' }),
      };
    }
    
    const user = getUserResult.Item;
    console.log('User found:', { email: user.email, hasPassword: !!user.password });
    
    // Check password
    console.log('Checking password...');
    const isPasswordValid = await bcrypt.compare(password, user.password);
    console.log('Password valid:', isPasswordValid);
    
    if (!isPasswordValid) {
      console.log('Invalid password');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid credentials' }),
      };
    }
    
    // Generate JWT token
    console.log('Generating JWT token...');
    const token = jwt.sign(
      { 
        userId: user.userId, 
        email: user.email 
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    console.log('Token generated successfully');
    
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'Signin successful',
        token: token,
        user: {
          userId: user.userId,
          email: user.email,
          username: user.username
        }
      }),
    };
    
  } catch (error) {
    console.error('Test signin handler error:', error);
    console.error('Error stack:', error.stack);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'Internal server error',
        error: error.message,
        stack: error.stack
      }),
    };
  }
}; 