const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    // Check if there's an authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    
    if (authHeader) {
      // If there's a token, decode it and get user data
      const token = authHeader.replace('Bearer ', '');
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const userId = decoded.id;
      
      const result = await dynamoDB.send(new GetCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id: userId },
      }));
      
      const user = result.Item;
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          message: 'Test endpoint with user data',
          user: {
            id: user.id,
            username: user.username,
            email: user.email,
            highestLevel: user.highestLevel,
            level: user.level,
            points: user.points,
            flectcoins: user.flectcoins,
            unlockedFrames: user.unlockedFrames,
            selectedFrame: user.selectedFrame
          }
        }),
      };
    } else {
      // No token, return basic test response
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          message: 'Test endpoint working - no user data (no token provided)',
          timestamp: new Date().toISOString()
        }),
      };
    }
  } catch (error) {
    console.error('Test handler error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        message: 'Test handler error', 
        error: error.message,
        stack: error.stack
      }),
    };
  }
}; 