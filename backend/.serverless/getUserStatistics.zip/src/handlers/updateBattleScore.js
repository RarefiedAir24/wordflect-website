const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');

const dynamoDB = DynamoDBDocumentClient.from(new DynamoDBClient({}));

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    const { battleId, score } = JSON.parse(event.body);
    
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.error('No valid Authorization header found in updateBattleScore');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Verify and decode the JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      console.error('JWT verification failed in updateBattleScore:', jwtError);
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token', error: jwtError.message }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      console.error('No user ID found in JWT in updateBattleScore');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    if (!battleId || typeof score !== 'number') {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Battle ID and score are required' }),
      };
    }

    // Get the battle
    const battleResponse = await dynamoDB.send(new GetCommand({
      TableName: process.env.BATTLES_TABLE,
      Key: { id: battleId },
    }));

    if (!battleResponse.Item) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Battle not found' }),
      };
    }

    const battle = battleResponse.Item;

    // Verify the battle is active
    if (battle.status !== 'active') {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Battle is not active' }),
      };
    }

    // Verify the user is part of this battle
    if (battle.challengerId !== userId && battle.opponentId !== userId) {
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Not authorized to update this battle' }),
      };
    }

    // Determine which score to update
    const isChallenger = battle.challengerId === userId;
    const scoreField = isChallenger ? 'challengerScore' : 'opponentScore';

    // Update the score
    await dynamoDB.send(new UpdateCommand({
      TableName: process.env.BATTLES_TABLE,
      Key: { id: battleId },
      UpdateExpression: `SET ${scoreField} = :score`,
      ExpressionAttributeValues: {
        ':score': score,
      },
    }));

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'Battle score updated successfully',
        battleId,
        score,
      }),
    };
  } catch (error) {
    console.error('Error updating battle score:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Internal server error' }),
    };
  }
}; 