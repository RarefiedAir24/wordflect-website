console.log('getUserFrames.js loaded');

const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const defaultFrames = [
  // Regular frames (available to all users)
  { id: 'spiked-steel', name: 'Spiked Steel', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/spiked-steel.png', rarity: 'common', isDefault: true, price: 0 },
  { id: 'ice-crystal', name: 'Ice Crystal', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-crystal.png', rarity: 'common', isDefault: true, price: 0 },
  { id: 'heart-gold', name: 'Heart Gold', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/heart-gold.png', rarity: 'rare', unlockedAt: 5, price: 150 },
  { id: 'skull-bone', name: 'Skull Bone', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/skull-bone.png', rarity: 'rare', unlockedAt: 5, price: 200 },
  { id: 'blue-spikes', name: 'Blue Spikes', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-spikes.png', rarity: 'rare', unlockedAt: 5, price: 250 },
  { id: 'wood-diamonds', name: 'Wood Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wood-diamonds.png', rarity: 'rare', unlockedAt: 8, price: 300 },
  { id: 'fire-frame', name: 'Fire Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/fire-frame.png', rarity: 'rare', unlockedAt: 5, price: 200 },
  { id: 'halo', name: 'Halo', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/halo.png', rarity: 'epic', unlockedAt: 10, price: 400 },
  { id: 'blue-diamonds', name: 'Blue Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-diamonds.png', rarity: 'epic', unlockedAt: 15, price: 500 },
  { id: 'dark-bling', name: 'Dark Bling', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dark-bling.png', rarity: 'epic', unlockedAt: 18, price: 600 },
  { id: 'galaxy-frame', name: 'Galaxy Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/galaxy-frame.png', rarity: 'epic', unlockedAt: 12, price: 500 },
  { id: 'gradient-diamond', name: 'Gradient Diamond', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/gradient-diamond.png', rarity: 'legendary', unlockedAt: 20, price: 800 },
  { id: 'empress', name: 'Empress', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/empress.png', rarity: 'legendary', battleWinsRequired: 25, price: 1000 },
  { id: 'wings', name: 'Wings', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wings.png', rarity: 'legendary', battleWinsRequired: 10, price: 1200 },
  { id: 'dragon-frame', name: 'Dragon Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-frame.png', rarity: 'legendary', unlockedAt: 25, price: 1000 },
  { id: 'vine-frame', name: 'Vine Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/vine-frame.png', rarity: 'epic', unlockedAt: 15, price: 600 },
  { id: 'cyber-frame', name: 'Cyber Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/cyber-frame.png', rarity: 'epic', unlockedAt: 18, price: 700 },
  { id: 'ice-shard', name: 'Ice Shard', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-shard.png', rarity: 'epic', unlockedAt: 20, price: 800 },
  
  // Premium-exclusive frames (Month 1 - wordflect-premium and wordflect-pro)
  { id: 'crystal-crown', name: 'Crystal Crown', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/crystal-crown.png', rarity: 'premium', premiumRequired: 'wordflect-premium', price: 0 },
  
  // Pro-exclusive frames (Month 1 - wordflect-pro only)
  { id: 'phoenix-reign', name: 'Phoenix Reign', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/phoenix-reign.png', rarity: 'legendary', premiumRequired: 'wordflect-pro', price: 0 },
];

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    console.log('getUserFrames handler started.');
    console.log('Event:', JSON.stringify(event, null, 2));
    
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.error('No valid Authorization header found');
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Authorization header required' }),
        headers: corsHeaders,
      };
    }

    const token = authHeader.replace('Bearer ', '');
    console.log('Extracted token from header');

    // Verify and decode the JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
      console.log('JWT token verified successfully');
    } catch (jwtError) {
      console.error('JWT verification failed:', jwtError);
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Invalid token' }),
        headers: corsHeaders,
      };
    }

    const userId = decoded.id;
    console.log('Extracted userId from JWT:', userId);

    if (!userId) {
      console.error('No userId found in JWT token');
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'User not authorized.' }),
        headers: corsHeaders,
      };
    }

    console.log('Fetching user from DynamoDB with ID:', userId);
    console.log('Using table:', process.env.USERS_TABLE);

    const result = await dynamoDB.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
    }));

    const user = result.Item;
    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not found' })
      };
    }
    
    // Get user's unlocked frames
    const unlockedFrameIds = user.unlockedFrames || [];
    console.log('User unlocked frames:', unlockedFrameIds);
    console.log('User level data:', {
      highestLevel: user.highestLevel,
      level: user.level,
      points: user.points
    });

    // Fetch frames from database with fallback to hardcoded data
    console.log('Fetching frames from database table:', process.env.FRAMES_TABLE);
    let framesFromDB = [];
    
    try {
      const framesResult = await dynamoDB.send(new ScanCommand({
        TableName: process.env.FRAMES_TABLE,
      }));
      framesFromDB = framesResult.Items || [];
      console.log(`Found ${framesFromDB.length} frames in database`);
    } catch (dbError) {
      console.error('Database error, falling back to hardcoded frames:', dbError);
      framesFromDB = defaultFrames;
    }

    // Use database frames if available, otherwise fall back to hardcoded
    let framesToUse = framesFromDB.length > 0 ? framesFromDB : defaultFrames;
    
    // Always include premium frames for premium users
    const userPremiumTier = user.premiumTier || null;
    const isPremium = user.isPremium || false;
    
    if (isPremium) {
      // Add premium frames to the list if they're not already there
      const premiumFrames = defaultFrames.filter(frame => frame.premiumRequired);
      framesToUse = [...framesToUse, ...premiumFrames];
      
      // Remove duplicates based on frame ID
      const seen = new Set();
      framesToUse = framesToUse.filter(frame => {
        if (seen.has(frame.id)) {
          return false;
        }
        seen.add(frame.id);
        return true;
      });
    }
    
    const frames = framesToUse.map((frame) => {
      // Check premium requirements
      const userPremiumTier = user.premiumTier || null;
      const isPremium = user.isPremium || false;
      
      // Frame is unlocked if:
      // 1. It's default OR
      // 2. It's in the unlockedFrames array (purchased) OR
      // 3. It's a premium frame and user has the required tier
      let isUnlocked = frame.isDefault || unlockedFrameIds.includes(frame.id);
      
      // Handle premium frame requirements
      if (frame.premiumRequired) {
        if (frame.premiumRequired === 'wordflect-premium') {
          // Available to Premium and Pro users
          isUnlocked = isUnlocked || (isPremium && (userPremiumTier === 'wordflect-premium' || userPremiumTier === 'wordflect-pro'));
        } else if (frame.premiumRequired === 'wordflect-pro') {
          // Available only to Pro users
          isUnlocked = isUnlocked || (isPremium && userPremiumTier === 'wordflect-pro');
        }
      }
      
      console.log(`Frame ${frame.id} unlock check:`, {
        isDefault: frame.isDefault,
        inUnlockedFrames: unlockedFrameIds.includes(frame.id),
        userLevel: user.highestLevel || user.level || 1,
        frameUnlockedAt: frame.unlockedAt,
        premiumRequired: frame.premiumRequired,
        userPremiumTier: userPremiumTier,
        isPremium: isPremium,
        canPurchase: frame.unlockedAt && (user.highestLevel || user.level || 1) >= frame.unlockedAt,
        finalResult: isUnlocked
      });
      
      return {
        ...frame,
        isUnlocked,
      };
    });

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(frames),
    };
  } catch (error) {
    console.error('Get user frames error:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'An error occurred while fetching frames.', error: error.message }),
    };
  }
}; 