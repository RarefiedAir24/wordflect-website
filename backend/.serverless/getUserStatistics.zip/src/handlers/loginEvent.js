const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand, GetCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const USERS_TABLE = process.env.USERS_TABLE;
const MISSIONS_TABLE = process.env.MISSIONS_TABLE;

function getTodayString() {
  return new Date().toISOString().slice(0, 10);
}

function isSameDay(date1, date2) {
  return date1.getFullYear() === date2.getFullYear() && date1.getMonth() === date2.getMonth() && date1.getDate() === date2.getDate();
}

function isYesterday(date1, date2) {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  d1.setHours(0, 0, 0, 0);
  d2.setHours(0, 0, 0, 0);
  return (d1 - d2) === 86400000;
}

async function fetchAllMissions() {
  const result = await dynamoDB.send(new ScanCommand({ TableName: MISSIONS_TABLE }));
  return result.Items || [];
}

exports.handler = async (event) => {
  try {
    const { id } = JSON.parse(event.body || '{}');
    if (!id) {
      return { statusCode: 400, body: JSON.stringify({ message: 'id is required.' }) };
    }
    const { Item: user } = await dynamoDB.send(new GetCommand({ TableName: USERS_TABLE, Key: { id } }));
    if (!user) {
      return { statusCode: 404, body: JSON.stringify({ message: 'User not found.' }) };
    }
    const today = getTodayString();
    let loginDates = user.loginDates || [];
    let currentLoginStreak = user.currentLoginStreak || 0;
    let longestLoginStreak = user.longestLoginStreak || 0;
    let lastLoginDate = user.lastLoginDate || null;
    // Add today if not present
    if (!loginDates.includes(today)) {
      loginDates.push(today);
    }
    // Sort and dedupe
    loginDates = Array.from(new Set(loginDates)).sort();
    // Update streaks
    if (lastLoginDate) {
      const last = new Date(lastLoginDate);
      const now = new Date(today);
      if (isYesterday(now, last)) {
        currentLoginStreak += 1;
      } else if (!isSameDay(now, last)) {
        currentLoginStreak = 1;
      }
    } else {
      currentLoginStreak = 1;
    }
    if (currentLoginStreak > longestLoginStreak) {
      longestLoginStreak = currentLoginStreak;
    }
    // Save user login info
    await dynamoDB.send(new UpdateCommand({
      TableName: USERS_TABLE,
      Key: { id },
      UpdateExpression: 'SET loginDates = :ld, currentLoginStreak = :cs, longestLoginStreak = :ls, lastLoginDate = :ll',
      ExpressionAttributeValues: {
        ':ld': loginDates,
        ':cs': currentLoginStreak,
        ':ls': longestLoginStreak,
        ':ll': today,
      },
    }));
    // --- Mission Progress Update ---
    const allMissions = await fetchAllMissions();
    let missions = user.missions || { daily: {}, weekly: {}, global: {} };
    let missionsStats = user.missionsStats || { dailyCompleted: 0, weeklyCompleted: 0, globalCompleted: 0 };
    const now = new Date();
    const nowISOString = now.toISOString();
    // Helper: get week dates
    function getWeekDates(date) {
      const d = new Date(date);
      const day = d.getDay();
      const monday = new Date(d);
      monday.setDate(d.getDate() - ((day + 6) % 7));
      const weekDates = [];
      for (let i = 0; i < 7; i++) {
        const wd = new Date(monday);
        wd.setDate(monday.getDate() + i);
        weekDates.push(wd.toISOString().slice(0, 10));
      }
      return weekDates;
    }
    const thisWeekDates = getWeekDates(today);
    console.log(`[LOGIN-EVENT] Processing ${allMissions.length} missions for user ${id}`);
    console.log(`[LOGIN-EVENT] This week dates: ${thisWeekDates.join(', ')}`);
    console.log(`[LOGIN-EVENT] Logins this week: ${loginDates.filter(d => thisWeekDates.includes(d)).length}`);
    
    // Create a set of valid mission IDs for quick lookup
    const validMissionIds = new Set(allMissions.map(m => m.id));
    console.log(`[LOGIN-EVENT] Valid mission IDs: ${validMissionIds.size} missions`);
    
    for (const mission of allMissions) {
      const { id: missionId, type: period, target = 1, objective = '', title = '' } = mission;
      
      // Skip the deleted "Login 5 Days" mission
      if (title === 'Login 5 Days') {
        console.log(`[LOGIN-EVENT] Skipping deleted mission: ${title} (${missionId})`);
        continue;
      }
      
      if (!missions[period]) missions[period] = {};
      if (!missions[period][missionId]) missions[period][missionId] = { progress: 0, completed: false, lastCompleted: null, lastProgress: null };
      let userMission = missions[period][missionId];
      
      // Debug: Check if this is a login-related mission
      const lowerObj = (objective || title).toLowerCase();
      const lowerTitle = (title || '').toLowerCase();
      const isLoginMission = lowerObj.includes('login') || lowerObj.includes('play every day') || lowerTitle.includes('login 5 days');
      
      if (isLoginMission) {
        console.log(`[LOGIN-EVENT] Processing login mission: ${title} (${missionId})`);
        console.log(`[LOGIN-EVENT]   Objective: ${objective}`);
        console.log(`[LOGIN-EVENT]   Current progress: ${userMission.progress || 0}`);
      }
      
      // Reset for new period
      if (period === 'daily' || period === 'weekly') {
        const lastProgressDate = userMission.lastProgress ? new Date(userMission.lastProgress) : null;
        const shouldResetMission = !lastProgressDate || 
          (period === 'daily' && !isSameDay(lastProgressDate, now)) || 
          (period === 'weekly' && !thisWeekDates.includes(lastProgressDate.toISOString().slice(0, 10)));
        if (shouldResetMission) {
          userMission = { progress: 0, completed: false, lastCompleted: null, lastProgress: nowISOString };
          if (isLoginMission) {
            console.log(`[LOGIN-EVENT]   Reset mission for new period`);
          }
        }
      }
      
      // Update progress for login missions
      let progressIncrement = 0;
      if (lowerObj.includes('login streak')) {
        progressIncrement = currentLoginStreak - (userMission.progress || 0);
        if (isLoginMission) {
          console.log(`[LOGIN-EVENT]   Login streak mission: ${currentLoginStreak} - ${userMission.progress || 0} = ${progressIncrement}`);
        }
      } else if ((lowerObj.includes('login') && lowerObj.includes('day')) || lowerTitle.includes('login 5 days')) {
        // e.g., Login 5 Days
        // Count unique days this week
        const loginsThisWeek = loginDates.filter(d => thisWeekDates.includes(d)).length;
        progressIncrement = loginsThisWeek - (userMission.progress || 0);
        if (isLoginMission) {
          console.log(`[LOGIN-EVENT]   Login 5 days mission: ${loginsThisWeek} - ${userMission.progress || 0} = ${progressIncrement}`);
        }
      } else if (lowerObj.includes('play every day')) {
        // Play Every Day this week: track the number of days logged in (up to 7)
        const loginsThisWeek = loginDates.filter(d => thisWeekDates.includes(d)).length;
        progressIncrement = loginsThisWeek - (userMission.progress || 0);
        if (isLoginMission) {
          console.log(`[LOGIN-EVENT]   Play every day mission: ${loginsThisWeek} - ${userMission.progress || 0} = ${progressIncrement}`);
        }
      }
      
      const beforeProgress = userMission.progress || 0;
      const newProgress = beforeProgress + progressIncrement;
      const isCompleted = newProgress >= (mission.target || 1);
      userMission.progress = newProgress;
      
      if (isLoginMission) {
        console.log(`[LOGIN-EVENT]   Progress: ${beforeProgress} → ${newProgress} (completed: ${isCompleted})`);
      }
      
      if (isCompleted) {
        if (!userMission.completed) {
          userMission.lastCompleted = nowISOString;
          missionsStats[`${period}Completed`] = (missionsStats[`${period}Completed`] || 0) + 1;
          if (isLoginMission) {
            console.log(`[LOGIN-EVENT]   Mission completed!`);
          }
        }
        userMission.completed = true;
      }
      if (period === 'daily' || period === 'weekly') {
        userMission.lastProgress = nowISOString;
      }
      missions[period][missionId] = userMission;
    }
    // Clean up invalid missions from user's mission progress
    for (const period of ['daily', 'weekly', 'global']) {
      if (missions[period]) {
        const validMissionsForPeriod = allMissions.filter(m => m.type === period);
        const validIdsForPeriod = new Set(validMissionsForPeriod.map(m => m.id));
        
        // Remove missions that no longer exist
        const invalidMissionIds = Object.keys(missions[period]).filter(missionId => !validIdsForPeriod.has(missionId));
        if (invalidMissionIds.length > 0) {
          console.log(`[LOGIN-EVENT] Removing ${invalidMissionIds.length} invalid ${period} missions: ${invalidMissionIds.join(', ')}`);
          invalidMissionIds.forEach(missionId => {
            delete missions[period][missionId];
          });
        }
      }
    }
    
    // Save missions
    console.log(`[LOGIN-EVENT] Saving missions to database...`);
    console.log(`[LOGIN-EVENT] Table name: ${USERS_TABLE}`);
    console.log(`[LOGIN-EVENT] User ID: ${id}`);
    console.log(`[LOGIN-EVENT] Missions object keys: ${Object.keys(missions).join(', ')}`);
    console.log(`[LOGIN-EVENT] Weekly missions count: ${Object.keys(missions.weekly || {}).length}`);
    
    try {
      await dynamoDB.send(new UpdateCommand({
        TableName: USERS_TABLE,
        Key: { id },
        UpdateExpression: 'SET missions = :m, missionsStats = :s',
        ExpressionAttributeValues: { ':m': missions, ':s': missionsStats },
      }));
      console.log(`[LOGIN-EVENT] ✅ Missions saved successfully!`);
    } catch (error) {
      console.error(`[LOGIN-EVENT] ❌ Error saving missions:`, error);
      throw error;
    }
    return { statusCode: 200, body: JSON.stringify({ message: 'Login event processed', currentLoginStreak, longestLoginStreak }) };
  } catch (err) {
    console.error('Error in loginEvent handler:', err);
    return { statusCode: 500, body: JSON.stringify({ message: 'Internal server error' }) };
  }
}; 