const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoDB = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-2' });
const docClient = DynamoDBDocumentClient.from(dynamoDB);

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const allowedOrigins = [
    'https://wordflect.com',
    'https://www.wordflect.com',
    'https://wordflect.app',
    'https://www.wordflect.app',
    'http://localhost:3000',
    'http://localhost:3001'
  ];

  return {
    'Access-Control-Allow-Origin': allowedOrigins.includes(origin) ? origin : '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };
}

// Helper function to get date strings
function getTodayString() {
  return new Date().toISOString().split('T')[0];
}

function getWeekString(date = new Date()) {
  const year = date.getFullYear();
  const week = getWeekNumber(date);
  return `${year}-W${week.toString().padStart(2, '0')}`;
}

function getWeekNumber(date) {
  const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
  const pastDaysOfYear = (date - firstDayOfYear) / 86400000;
  return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
}

function getMonthString(date = new Date()) {
  return date.toISOString().substring(0, 7);
}

// Get theme name for a given date
function getThemeNameForDate(date) {
  const dayOfWeek = new Date(date).toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
  const themeNames = {
    monday: 'Food & Drinks',
    tuesday: 'Common Nouns',
    wednesday: 'Nature',
    thursday: 'Verbs',
    friday: 'Adjectives',
    saturday: 'Colors',
    sunday: 'Animals'
  };
  return themeNames[dayOfWeek] || 'Food & Drinks';
}

// Calculate theme word analytics from user's allFoundWords
function calculateThemeAnalytics(user) {
  const allFoundWords = user.allFoundWords || [];
  const now = new Date();
  const today = getTodayString();
  
  // Theme word sets (from mobile app)
  const THEME_WORD_SETS = {
    monday: {
      name: 'Food & Drinks',
      words: ['PIZZA', 'BURGER', 'SALAD', 'COFFEE', 'JUICE', 'BREAD', 'CHEESE', 'APPLE', 'BANANA', 'GRAPE', 'ORANGE', 'LEMON'],
      dailyGoal: 12
    },
    tuesday: {
      name: 'Common Nouns',
      words: ['HOUSE', 'CAR', 'TREE', 'BOOK', 'PHONE', 'CHAIR', 'TABLE', 'DOOR', 'WINDOW', 'CLOCK', 'MONEY', 'MUSIC'],
      dailyGoal: 12
    },
    wednesday: {
      name: 'Nature',
      words: ['SUN', 'MOON', 'STAR', 'WIND', 'RAIN', 'SNOW', 'FIRE', 'WATER', 'EARTH', 'SKY', 'OCEAN', 'MOUNTAIN'],
      dailyGoal: 12
    },
    thursday: {
      name: 'Verbs',
      words: ['RUN', 'WALK', 'JUMP', 'SWIM', 'DANCE', 'SING', 'READ', 'WRITE', 'DRAW', 'PAINT', 'COOK', 'CLEAN'],
      dailyGoal: 12
    },
    friday: {
      name: 'Adjectives',
      words: ['BIG', 'SMALL', 'FAST', 'SLOW', 'HOT', 'COLD', 'NEW', 'OLD', 'GOOD', 'BAD', 'HAPPY', 'SAD'],
      dailyGoal: 12
    },
    saturday: {
      name: 'Colors',
      words: ['RED', 'BLUE', 'GREEN', 'YELLOW', 'ORANGE', 'PURPLE', 'PINK', 'BLACK', 'WHITE', 'BROWN', 'GRAY', 'SILVER'],
      dailyGoal: 12
    },
    sunday: {
      name: 'Animals',
      words: ['DOG', 'CAT', 'BIRD', 'FISH', 'BEAR', 'LION', 'TIGER', 'ELEPHANT', 'MONKEY', 'RABBIT', 'MOUSE', 'SNAKE'],
      dailyGoal: 12
    }
  };
  
  // Calculate theme analytics
  const themeAnalytics = {};
  const dailyThemeStats = {};
  const weeklyThemeStats = {};
  const monthlyThemeStats = {};
  
  // Process each word found
  allFoundWords.forEach(wordEntry => {
    const word = wordEntry.word || wordEntry;
    const wordDate = wordEntry.date ? new Date(wordEntry.date).toISOString().split('T')[0] : today;
    const wordDateObj = new Date(wordDate);
    const dayOfWeek = wordDateObj.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
    
    // Get theme for this date
    const theme = THEME_WORD_SETS[dayOfWeek];
    if (!theme) return;
    
    // Check if word is a theme word
    if (theme.words.includes(word.toUpperCase())) {
      const themeName = theme.name;
      
      // Initialize theme analytics if not exists
      if (!themeAnalytics[themeName]) {
        themeAnalytics[themeName] = {
          themeName,
          totalWordsFound: 0,
          totalDaysPlayed: 0,
          averageWordsPerDay: 0,
          bestDay: { date: null, wordsFound: 0 },
          completionRate: 0,
          daysCompleted: 0,
          totalPossibleWords: theme.words.length,
          wordsFound: []
        };
      }
      
      // Add word to theme analytics
      themeAnalytics[themeName].wordsFound.push({
        word: word.toUpperCase(),
        date: wordDate
      });
      themeAnalytics[themeName].totalWordsFound++;
      
      // Update daily stats
      if (!dailyThemeStats[wordDate]) {
        dailyThemeStats[wordDate] = {
          date: wordDate,
          themeName,
          wordsFound: [],
          totalFound: 0,
          completed: false
        };
      }
      
      if (!dailyThemeStats[wordDate].wordsFound.includes(word.toUpperCase())) {
        dailyThemeStats[wordDate].wordsFound.push(word.toUpperCase());
        dailyThemeStats[wordDate].totalFound++;
        
        // Check if theme was completed this day
        if (dailyThemeStats[wordDate].totalFound >= theme.dailyGoal) {
          dailyThemeStats[wordDate].completed = true;
          themeAnalytics[themeName].daysCompleted++;
        }
        
        // Update best day
        if (dailyThemeStats[wordDate].totalFound > themeAnalytics[themeName].bestDay.wordsFound) {
          themeAnalytics[themeName].bestDay = {
            date: wordDate,
            wordsFound: dailyThemeStats[wordDate].totalFound
          };
        }
      }
    }
  });
  
  // Calculate final analytics for each theme
  Object.keys(themeAnalytics).forEach(themeName => {
    const analytics = themeAnalytics[themeName];
    const daysPlayed = Object.keys(dailyThemeStats).filter(date => 
      dailyThemeStats[date].themeName === themeName
    ).length;
    
    analytics.totalDaysPlayed = daysPlayed;
    analytics.averageWordsPerDay = daysPlayed > 0 ? 
      Math.round((analytics.totalWordsFound / daysPlayed) * 10) / 10 : 0;
    analytics.completionRate = daysPlayed > 0 ? 
      Math.round((analytics.daysCompleted / daysPlayed) * 100) : 0;
  });
  
  // Calculate weekly and monthly stats
  const thisWeek = getWeekString(now);
  const thisMonth = getMonthString(now);
  
  // Weekly stats
  Object.keys(dailyThemeStats).forEach(date => {
    const dateObj = new Date(date);
    const week = getWeekString(dateObj);
    const month = getMonthString(dateObj);
    
    if (week === thisWeek) {
      if (!weeklyThemeStats[week]) {
        weeklyThemeStats[week] = {
          week,
          themes: {},
          totalWordsFound: 0,
          totalDaysCompleted: 0
        };
      }
      
      const dayStats = dailyThemeStats[date];
      if (!weeklyThemeStats[week].themes[dayStats.themeName]) {
        weeklyThemeStats[week].themes[dayStats.themeName] = {
          themeName: dayStats.themeName,
          wordsFound: 0,
          daysCompleted: 0
        };
      }
      
      weeklyThemeStats[week].themes[dayStats.themeName].wordsFound += dayStats.totalFound;
      if (dayStats.completed) {
        weeklyThemeStats[week].themes[dayStats.themeName].daysCompleted++;
        weeklyThemeStats[week].totalDaysCompleted++;
      }
      weeklyThemeStats[week].totalWordsFound += dayStats.totalFound;
    }
    
    if (month === thisMonth) {
      if (!monthlyThemeStats[month]) {
        monthlyThemeStats[month] = {
          month,
          themes: {},
          totalWordsFound: 0,
          totalDaysCompleted: 0
        };
      }
      
      const dayStats = dailyThemeStats[date];
      if (!monthlyThemeStats[month].themes[dayStats.themeName]) {
        monthlyThemeStats[month].themes[dayStats.themeName] = {
          themeName: dayStats.themeName,
          wordsFound: 0,
          daysCompleted: 0
        };
      }
      
      monthlyThemeStats[month].themes[dayStats.themeName].wordsFound += dayStats.totalFound;
      if (dayStats.completed) {
        monthlyThemeStats[month].themes[dayStats.themeName].daysCompleted++;
        monthlyThemeStats[month].totalDaysCompleted++;
      }
      monthlyThemeStats[month].totalWordsFound += dayStats.totalFound;
    }
  });
  
  // Find most successful theme
  let mostSuccessfulTheme = null;
  let bestCompletionRate = 0;
  
  Object.values(themeAnalytics).forEach(theme => {
    if (theme.completionRate > bestCompletionRate) {
      bestCompletionRate = theme.completionRate;
      mostSuccessfulTheme = theme;
    }
  });
  
  return {
    themeAnalytics,
    dailyThemeStats,
    weeklyThemeStats,
    monthlyThemeStats,
    mostSuccessfulTheme,
    summary: {
      totalThemeWordsFound: allFoundWords.filter(entry => {
        const word = entry.word || entry;
        const wordDate = entry.date ? new Date(entry.date).toISOString().split('T')[0] : today;
        const dayOfWeek = new Date(wordDate).toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
        const theme = THEME_WORD_SETS[dayOfWeek];
        return theme && theme.words.includes(word.toUpperCase());
      }).length,
      totalThemeDaysPlayed: Object.keys(dailyThemeStats).length,
      totalThemeDaysCompleted: Object.values(dailyThemeStats).filter(day => day.completed).length,
      averageThemeWordsPerDay: Object.keys(dailyThemeStats).length > 0 ? 
        Math.round((Object.values(dailyThemeStats).reduce((sum, day) => sum + day.totalFound, 0) / Object.keys(dailyThemeStats).length) * 10) / 10 : 0
    }
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  
  try {
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Verify and decode the JWT token
    const jwt = require('jsonwebtoken');
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token' }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    // Get user data
    const { Item: user } = await docClient.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId }
    }));

    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    // Calculate theme analytics
    const analytics = calculateThemeAnalytics(user);

    return {
      statusCode: 200,
      headers: {
        ...corsHeaders,
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      },
      body: JSON.stringify({
        success: true,
        analytics
      }),
    };

  } catch (error) {
    console.error('Error getting user theme analytics:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'Internal server error',
        error: error.message 
      }),
    };
  }
};
