const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');

const dynamoDB = DynamoDBDocumentClient.from(new DynamoDBClient({}));

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    const { accept, cancel } = JSON.parse(event.body);
    const invitationId = event.pathParameters.invitationId;

    // Extract and verify JWT token
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }
    const token = authHeader.replace('Bearer ', '');
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token', error: jwtError.message }),
      };
    }
    const userId = decoded.id;

    // Get the invitation
    const invitationResponse = await dynamoDB.send(new GetCommand({
      TableName: process.env.BATTLES_TABLE,
      Key: { id: invitationId },
    }));

    if (!invitationResponse.Item) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Battle invitation not found' }),
      };
    }

    const invitation = invitationResponse.Item;

    // Challenger can cancel their own pending invitation
    if (cancel === true && invitation.challengerId === userId && invitation.status === 'pending') {
      await dynamoDB.send(new UpdateCommand({
        TableName: process.env.BATTLES_TABLE,
        Key: { id: invitationId },
        UpdateExpression: 'SET #status = :status, cancelledAt = :cancelledAt',
        ExpressionAttributeNames: { '#status': 'status' },
        ExpressionAttributeValues: {
          ':status': 'cancelled',
          ':cancelledAt': new Date().toISOString(),
        },
      }));
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Battle invitation cancelled' }),
      };
    }

    if (typeof accept !== 'boolean') {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Accept parameter must be a boolean' }),
      };
    }

    // Only opponent can accept/decline
    if (invitation.opponentId !== userId) {
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Not authorized to respond to this invitation' }),
      };
    }

    // Verify the invitation is still pending
    if (invitation.status !== 'pending') {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Battle invitation is no longer pending' }),
      };
    }

    if (accept) {
      // Accept the invitation - start the battle
      await dynamoDB.send(new UpdateCommand({
        TableName: process.env.BATTLES_TABLE,
        Key: { id: invitationId },
        UpdateExpression: 'SET #status = :status, startedAt = :startedAt',
        ExpressionAttributeNames: { '#status': 'status' },
        ExpressionAttributeValues: {
          ':status': 'active',
          ':startedAt': new Date().toISOString(),
        },
      }));

      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          message: 'Battle invitation accepted',
          battleId: invitationId,
        }),
      };
    } else {
      // Decline the invitation
      await dynamoDB.send(new UpdateCommand({
        TableName: process.env.BATTLES_TABLE,
        Key: { id: invitationId },
        UpdateExpression: 'SET #status = :status, declinedAt = :declinedAt',
        ExpressionAttributeNames: { '#status': 'status' },
        ExpressionAttributeValues: {
          ':status': 'declined',
          ':declinedAt': new Date().toISOString(),
        },
      }));

      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          message: 'Battle invitation declined',
        }),
      };
    }
  } catch (error) {
    console.error('Error responding to battle invitation:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Internal server error' }),
    };
  }
}; 