const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoDB = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-2' });
const docClient = DynamoDBDocumentClient.from(dynamoDB);

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const allowedOrigins = [
    'https://wordflect.com',
    'https://www.wordflect.com',
    'https://wordflect.app',
    'https://www.wordflect.app',
    'http://localhost:3000',
    'http://localhost:3001'
  ];

  return {
    'Access-Control-Allow-Origin': allowedOrigins.includes(origin) ? origin : '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };
}

// Helper function to get date strings
function getDateString(date) {
  return date.toISOString().split('T')[0];
}

// Get theme name for a given date
function getThemeNameForDate(date) {
  const dayOfWeek = new Date(date).toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
  const themeNames = {
    monday: 'Food & Drinks',
    tuesday: 'Common Nouns',
    wednesday: 'Nature',
    thursday: 'Verbs',
    friday: 'Adjectives',
    saturday: 'Colors',
    sunday: 'Animals'
  };
  return themeNames[dayOfWeek] || 'Food & Drinks';
}

// Get theme words for a given date (with rotation logic matching mobile app)
function getThemeWordsForDate(date) {
  const dayOfWeek = new Date(date).toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
  
  // Theme word sets for rotation (3-8 letters only, 20 words each, 4 sets per theme)
  const THEME_WORD_SETS = {
    monday: {
      name: "Food & Drinks",
      sets: [
        // Set 0 - 20 words
        ["PIZZA", "BURGER", "SALAD", "COFFEE", "JUICE", "BREAD", "CHEESE", "APPLE", "BANANA", "GRAPE", "ORANGE", "LEMON", "PASTA", "RICE", "SOUP", "CAKE", "COOKIE", "CANDY", "CHOCOLATE", "SANDWICH"],
        // Set 1 - 20 words
        ["TACO", "SUSHI", "STEAK", "CHICKEN", "FISH", "SHRIMP", "CRAB", "LOBSTER", "SALMON", "TUNA", "BEEF", "PORK", "LAMB", "DUCK", "TURKEY", "HAM", "BACON", "SAUSAGE", "HOTDOG", "PIZZA"],
        // Set 2 - 20 words
        ["MILK", "WATER", "SODA", "BEER", "WINE", "WHISKEY", "VODKA", "RUM", "GIN", "TEQUILA", "BRANDY", "CHAMPAGNE", "COCKTAIL", "MARTINI", "MARGARITA", "DAIQUIRI", "MOJITO", "COSMO", "MANHATTAN", "OLD"],
        // Set 3 - 20 words
        ["TEA", "COCOA", "LATTE", "ESPRESSO", "CAPPUCCINO", "MOCHA", "FRAPPE", "SMOOTHIE", "SHAKE", "FLOAT", "PUNCH", "LEMONADE", "ICED", "HOT", "COLD", "WARM", "FRESH", "SWEET", "SOUR", "BITTER"]
      ]
    },
    tuesday: {
      name: "Common Nouns",
      sets: [
        // Set 0 - 20 words
        ["HOUSE", "CAR", "TREE", "BOOK", "PHONE", "CHAIR", "TABLE", "DOOR", "WINDOW", "CLOCK", "MONEY", "MUSIC", "MOVIE", "GAME", "SPORT", "BALL", "TOY", "GIFT", "CARD", "LETTER"],
        // Set 1 - 20 words
        ["COMPUTER", "LAPTOP", "TABLET", "CAMERA", "WATCH", "RING", "NECKLACE", "BRACELET", "EARRING", "GLASSES", "HAT", "SHIRT", "PANTS", "SHOES", "SOCKS", "JACKET", "COAT", "DRESS", "SKIRT", "SUIT"],
        // Set 2 - 20 words
        ["BED", "PILLOW", "BLANKET", "SHEET", "TOWEL", "SOAP", "SHAMPOO", "TOOTHBRUSH", "TOOTHPASTE", "MIRROR", "BRUSH", "COMB", "RAZOR", "LOTION", "CREAM", "OIL", "PERFUME", "DEODORANT", "VITAMIN", "MEDICINE"],
        // Set 3 - 20 words
        ["BAG", "PURSE", "WALLET", "KEY", "LOCK", "CHAIN", "ROPE", "STRING", "WIRE", "CABLE", "PLUG", "SWITCH", "BUTTON", "KNOB", "HANDLE", "GRIP", "HOLD", "CATCH", "GRAB", "TOUCH"]
      ]
    },
    wednesday: {
      name: "Nature",
      sets: [
        // Set 0 - 20 words
        ["SUN", "MOON", "STAR", "WIND", "RAIN", "SNOW", "FIRE", "WATER", "EARTH", "SKY", "OCEAN", "MOUNTAIN", "RIVER", "LAKE", "FOREST", "TREE", "FLOWER", "GRASS", "LEAF", "BRANCH"],
        // Set 1 - 20 words
        ["ROCK", "STONE", "SAND", "DIRT", "MUD", "CLAY", "GOLD", "SILVER", "COPPER", "IRON", "STEEL", "BRONZE", "DIAMOND", "RUBY", "EMERALD", "SAPPHIRE", "PEARL", "CRYSTAL", "GEM", "JEWEL"],
        // Set 2 - 20 words
        ["BIRD", "FISH", "FROG", "SNAKE", "LIZARD", "TURTLE", "SPIDER", "ANT", "BEE", "FLY", "MOSQUITO", "BUTTERFLY", "MOTH", "BEETLE", "GRASSHOPPER", "CRICKET", "CICADA", "DRAGONFLY", "LADYBUG", "WORM"],
        // Set 3 - 20 words
        ["PLANT", "SEED", "ROOT", "STEM", "BARK", "THORN", "PETAL", "POLLEN", "NECTAR", "HONEY", "WAX", "RESIN", "SAP", "JUICE", "PULP", "FIBER", "WOOD", "LUMBER", "TIMBER", "LOG"]
      ]
    },
    thursday: {
      name: "Verbs",
      sets: [
        // Set 0 - 20 words
        ["RUN", "WALK", "JUMP", "SWIM", "FLY", "CRAWL", "CLIMB", "DIVE", "DANCE", "SING", "PLAY", "WORK", "STUDY", "READ", "WRITE", "DRAW", "PAINT", "COOK", "EAT", "DRINK"],
        // Set 1 - 20 words
        ["SLEEP", "WAKE", "DREAM", "THINK", "LEARN", "TEACH", "HELP", "SAVE", "FIND", "LOSE", "WIN", "LOSE", "BUY", "SELL", "GIVE", "TAKE", "MAKE", "DO", "HAVE", "GET"],
        // Set 2 - 20 words
        ["GO", "COME", "STAY", "LEAVE", "ENTER", "EXIT", "OPEN", "CLOSE", "START", "STOP", "BEGIN", "END", "FINISH", "COMPLETE", "CREATE", "BUILD", "DESTROY", "BREAK", "FIX", "REPAIR"],
        // Set 3 - 20 words
        ["CATCH", "THROW", "HIT", "MISS", "PUSH", "PULL", "LIFT", "DROP", "CARRY", "HOLD", "TOUCH", "FEEL", "SEE", "LOOK", "WATCH", "LISTEN", "HEAR", "SMELL", "TASTE", "KNOW"]
      ]
    },
    friday: {
      name: "Adjectives",
      sets: [
        // Set 0 - 20 words
        ["BIG", "SMALL", "FAST", "SLOW", "HOT", "COLD", "HARD", "SOFT", "LONG", "SHORT", "WIDE", "NARROW", "HIGH", "LOW", "DEEP", "SHALLOW", "THICK", "THIN", "HEAVY", "LIGHT"],
        // Set 1 - 20 words
        ["STRONG", "WEAK", "RICH", "POOR", "YOUNG", "OLD", "NEW", "OLD", "FRESH", "STALE", "CLEAN", "DIRTY", "DRY", "WET", "FULL", "EMPTY", "OPEN", "CLOSED", "FREE", "BUSY"],
        // Set 2 - 20 words
        ["HAPPY", "SAD", "ANGRY", "CALM", "EXCITED", "BORED", "TIRED", "ENERGETIC", "SICK", "HEALTHY", "SAFE", "DANGEROUS", "EASY", "HARD", "SIMPLE", "COMPLEX", "QUIET", "LOUD", "BRIGHT", "DARK"],
        // Set 3 - 20 words
        ["BEAUTIFUL", "UGLY", "PRETTY", "HANDSOME", "CUTE", "SCARY", "FUNNY", "SERIOUS", "SMART", "STUPID", "KIND", "MEAN", "GENTLE", "ROUGH", "SMOOTH", "ROUGH", "SHARP", "DULL", "CURVED", "STRAIGHT"]
      ]
    },
    saturday: {
      name: "Colors",
      sets: [
        // Set 0 - 20 words
        ["RED", "BLUE", "GREEN", "YELLOW", "ORANGE", "PURPLE", "PINK", "BLACK", "WHITE", "BROWN", "GRAY", "SILVER", "GOLD", "BRONZE", "COPPER", "ROSE", "LIME", "CYAN", "MAGENTA", "VIOLET"],
        // Set 1 - 20 words
        ["CRIMSON", "SCARLET", "BURGUNDY", "MAROON", "RUST", "CORAL", "SALMON", "PEACH", "APRICOT", "TANGERINE", "AMBER", "CHARTREUSE", "OLIVE", "FOREST", "EMERALD", "TURQUOISE", "TEAL", "NAVY", "ROYAL", "INDIGO"],
        // Set 2 - 20 words
        ["LAVENDER", "LILAC", "MAUVE", "BEIGE", "TAN", "KHAKI", "CREAM", "IVORY", "PEARL", "PLATINUM", "CHARCOAL", "SLATE", "STEEL", "GUNMETAL", "BRONZE", "BRASS", "COPPER", "RUST", "PATINA", "VERDIGRIS"],
        // Set 3 - 20 words
        ["AQUA", "AZURE", "CERULEAN", "COBALT", "ULTRAMARINE", "PRUSSIAN", "SAPPHIRE", "PERIWINKLE", "CORNFLOWER", "SKY", "POWDER", "BABY", "ROBIN", "EGG", "MINT", "SEAFOAM", "JADE", "MOSS", "SAGE", "HUNTER"]
      ]
    },
    sunday: {
      name: "Animals",
      sets: [
        // Set 0 - 20 words
        ["DOG", "CAT", "BIRD", "FISH", "BEAR", "LION", "TIGER", "ELEPHANT", "MONKEY", "RABBIT", "MOUSE", "SNAKE", "HORSE", "COW", "PIG", "SHEEP", "GOAT", "CHICKEN", "DUCK", "OWL"],
        // Set 1 - 20 words
        ["EAGLE", "WOLF", "FOX", "DEER", "BUTTERFLY", "TURTLE", "SNAIL", "CRAB", "SEAL", "WHALE", "DOLPHIN", "SHARK", "OCTOPUS", "SQUID", "JELLYFISH", "STARFISH", "CLAM", "OYSTER", "MUSSEL", "SHRIMP"],
        // Set 2 - 20 words
        ["PANDA", "KOALA", "KANGAROO", "ZEBRA", "GIRAFFE", "RHINO", "HIPPO", "CROCODILE", "ALLIGATOR", "LIZARD", "CHAMELEON", "GECKO", "IGUANA", "SALAMANDER", "NEWT", "FROG", "TOAD", "TADPOLE", "POLAR", "PENGUIN"],
        // Set 3 - 20 words
        ["BAT", "RACCOON", "SKUNK", "OPOSSUM", "BEAVER", "OTTER", "WEASEL", "FERRET", "MINK", "MARTEN", "FISHER", "WOLVERINE", "BADGER", "MARMOT", "PRAIRIE", "CHIPMUNK", "SQUIRREL", "PORCUPINE", "HEDGEHOG", "ARMADILLO"]
      ]
    }
  };

  const themeData = THEME_WORD_SETS[dayOfWeek] || THEME_WORD_SETS.monday;
  
  // Calculate which set to use based on week number (matching mobile app logic)
  const now = new Date(date);
  const startOfYear = new Date(now.getFullYear(), 0, 1);
  const weekNumber = Math.floor((now.getTime() - startOfYear.getTime()) / (7 * 24 * 60 * 60 * 1000));
  const setIndex = weekNumber % themeData.sets.length;
  
  console.log('=== BACKEND THEME ROTATION DEBUG ===');
  console.log('Date:', date);
  console.log('Day of week:', dayOfWeek);
  console.log('Week number:', weekNumber);
  console.log('Set index (0-3):', setIndex);
  console.log('Theme data sets length:', themeData.sets.length);
  console.log('Selected theme words:', themeData.sets[setIndex]);
  console.log('Selected theme words length:', themeData.sets[setIndex].length);
  
  return {
    name: themeData.name,
    words: themeData.sets[setIndex],
    dailyGoal: 20
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  
  try {
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Verify and decode the JWT token
    const jwt = require('jsonwebtoken');
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token' }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    // Parse query parameters
    const queryParams = event.queryStringParameters || {};
    const requestedDate = queryParams.date;
    
    let targetDate;
    if (requestedDate) {
      // Validate date format (YYYY-MM-DD)
      if (!/^\d{4}-\d{2}-\d{2}$/.test(requestedDate)) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ message: 'Invalid date format. Use YYYY-MM-DD' }),
        };
      }
      targetDate = new Date(requestedDate + 'T00:00:00.000Z');
    } else {
      targetDate = new Date();
    }

    const dateString = getDateString(targetDate);

    // Get user data
    const { Item: user } = await docClient.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId }
    }));

    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    // Get theme for this date
    const theme = getThemeWordsForDate(targetDate);
    const themeName = theme.name;
    const themeWords = theme.words;
    const dailyGoal = theme.dailyGoal;

    // Get words found on this specific date
    const allFoundWords = user.allFoundWords || [];
    const wordsFoundOnDate = allFoundWords.filter(wordEntry => {
      if (!wordEntry.date) return false;
      const wordDate = new Date(wordEntry.date).toISOString().split('T')[0];
      return wordDate === dateString;
    });

    // Filter theme words found on this date
    const themeWordsFound = wordsFoundOnDate.filter(wordEntry => {
      const word = wordEntry.word || wordEntry;
      return themeWords.includes(word.toUpperCase());
    });

    // Get unique theme words found
    const uniqueThemeWordsFound = [...new Set(themeWordsFound.map(entry => 
      (entry.word || entry).toUpperCase()
    ))];

    // Calculate statistics
    const totalThemeWordsFound = uniqueThemeWordsFound.length;
    const completionRate = Math.round((totalThemeWordsFound / dailyGoal) * 100);
    const isCompleted = totalThemeWordsFound >= dailyGoal;
    const remainingWords = themeWords.filter(word => !uniqueThemeWordsFound.includes(word));

    // Get all words found on this date (not just theme words)
    const allWordsFoundOnDate = wordsFoundOnDate.map(entry => ({
      word: entry.word || entry,
      length: (entry.word || entry).length,
      isThemeWord: themeWords.includes((entry.word || entry).toUpperCase()),
      time: entry.time || null
    }));

    // Calculate theme word success rate
    const totalWordsFound = allWordsFoundOnDate.length;
    const themeWordSuccessRate = totalWordsFound > 0 ? 
      Math.round((totalThemeWordsFound / totalWordsFound) * 100) : 0;

    const response = {
      success: true,
      date: dateString,
      theme: {
        name: themeName,
        words: themeWords,
        dailyGoal,
        totalWords: themeWords.length
      },
      stats: {
        totalThemeWordsFound,
        completionRate,
        isCompleted,
        remainingWords,
        themeWordSuccessRate,
        totalWordsFound,
        wordsFound: allWordsFoundOnDate
      },
      themeWordsFound: uniqueThemeWordsFound.map(word => ({
        word,
        length: word.length,
        found: true
      })),
      remainingThemeWords: remainingWords.map(word => ({
        word,
        length: word.length,
        found: false
      }))
    };

    return {
      statusCode: 200,
      headers: {
        ...corsHeaders,
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      },
      body: JSON.stringify(response),
    };

  } catch (error) {
    console.error('Error getting user theme day stats:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'Internal server error',
        error: error.message 
      }),
    };
  }
};
