const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);
const WORD_OF_THE_DAY_TABLE = process.env.WORD_OF_THE_DAY_TABLE || 'WordOfTheDay';

function getTodayDateString() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

exports.handler = async (event) => {
  try {
    const date = event.queryStringParameters?.date || getTodayDateString();
    const { Item } = await dynamoDB.send(new GetCommand({
      TableName: WORD_OF_THE_DAY_TABLE,
      Key: { date },
    }));
    if (!Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'Word of the day not found for this date.' }),
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({ date: Item.date, word: Item.word }),
    };
  } catch (error) {
    console.error('getWordOfTheDay error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Failed to fetch word of the day.' }),
    };
  }
}; 