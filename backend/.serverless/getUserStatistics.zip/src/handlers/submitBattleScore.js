const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand, GetCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');

const dynamoDB = DynamoDBDocumentClient.from(new DynamoDBClient({}));

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

// Helper function to update battle mission progress
async function updateBattleMissionProgress(userId, score, words = [], won = false) {
  console.log(`[BATTLE-MISSION-PROGRESS] Starting update for user ${userId}, score: ${score}, won: ${won}, words: ${words.length}`);
  try {
    // Get user data
    const { Item: user } = await dynamoDB.send(new GetCommand({ 
      TableName: process.env.USERS_TABLE, 
      Key: { id: userId } 
    }));
    
    if (!user) {
      console.log(`User ${userId} not found for battle mission progress update`);
      return;
    }

    // Fetch all missions
    const { Items: allMissions } = await dynamoDB.send(new ScanCommand({
      TableName: process.env.MISSIONS_TABLE
    }));

    console.log(`[BATTLE-MISSION-PROGRESS] Found ${allMissions.length} total missions`);

    let missions = user.missions || { daily: {}, weekly: {}, global: {} };
    let missionsStats = user.missionsStats || { dailyCompleted: 0, weeklyCompleted: 0, globalCompleted: 0 };
    const now = new Date();
    const nowISOString = now.toISOString();
    let missionsUpdated = false;
    let totalPointsToAdd = 0;
    let totalGemsToAdd = 0;

    const gameData = { score, words, level: user.highestLevel || 1, won };

    for (const mission of allMissions) {
      const { id: missionId, type: period, target = 1, objective = '', title = '' } = mission;
      
      // Initialize mission progress if it doesn't exist
      if (!missions[period]) {
        missions[period] = {};
      }
      if (!missions[period][missionId]) {
        missions[period][missionId] = { progress: 0, completed: false, lastCompleted: null, lastProgress: null };
      }
      
      let userMission = missions[period][missionId];

      // Check if mission should be reset based on period
      if (period === 'daily' || period === 'weekly') {
        const lastProgressDate = userMission.lastProgress ? new Date(userMission.lastProgress) : null;
        const shouldResetMission = !lastProgressDate || 
          (period === 'daily' && !isSameDay(lastProgressDate, now)) || 
          (period === 'weekly' && !isSameWeek(lastProgressDate, now));
        
        if (shouldResetMission && userMission.completed) {
          userMission = { progress: 0, completed: false, lastCompleted: null, lastProgress: nowISOString };
        } else if (shouldResetMission && !userMission.completed) {
          userMission.lastProgress = nowISOString;
        }
      }

      // Calculate progress increment for battle missions
      const missionObjective = (mission.objective || mission.title || '').toString();
      const lowerObjective = missionObjective.toLowerCase();
      
      let progressIncrement = 0;
      
      // Handle battle-specific missions
      if (lowerObjective.includes('battle')) {
        console.log(`[BATTLE-MISSION-PROGRESS] Processing battle mission: ${title} (${objective})`);
        if (lowerObjective.includes('win') && lowerObjective.includes('battle')) {
          progressIncrement = won ? 1 : 0;
          console.log(`[BATTLE-MISSION-PROGRESS] Win battle mission - won: ${won}, increment: ${progressIncrement}`);
        } else if (lowerObjective.includes('play') && lowerObjective.includes('battle')) {
          progressIncrement = 1; // Count each battle played
          console.log(`[BATTLE-MISSION-PROGRESS] Play battle mission - increment: ${progressIncrement}`);
        } else if (lowerObjective.includes('score') && lowerObjective.includes('battle')) {
          progressIncrement = score;
          console.log(`[BATTLE-MISSION-PROGRESS] Score battle mission - score: ${score}, increment: ${progressIncrement}`);
        } else if (lowerObjective.includes('find') && lowerObjective.includes('word') && lowerObjective.includes('battle')) {
          progressIncrement = words.length;
          console.log(`[BATTLE-MISSION-PROGRESS] Find words battle mission - words: ${words.length}, increment: ${progressIncrement}`);
        }
      }

      // Don't add progress if mission is already completed (except for global missions)
      if (userMission.completed && period !== 'global') {
        progressIncrement = 0;
      }
      
      const beforeProgress = userMission.progress || 0;
      const newProgress = beforeProgress + progressIncrement;
      const isCompleted = newProgress >= (mission.target || 1);

      // Update mission progress
      userMission.progress = newProgress;
      if (isCompleted) {
        // Only award points/gems if the mission was not already completed
        const lastCompletedDate = userMission.lastCompleted ? new Date(userMission.lastCompleted) : null;
        const completedInCurrentPeriod = lastCompletedDate && 
          ((period === 'daily' && isSameDay(lastCompletedDate, now)) ||
           (period === 'weekly' && isSameWeek(lastCompletedDate, now)));
        
        // For global missions, only award if never completed before
        // For daily/weekly missions, only award if not completed in current period
        const shouldAwardReward = period === 'global' 
          ? !userMission.completed 
          : !userMission.completed && !completedInCurrentPeriod;
        
        if (shouldAwardReward) {
          userMission.lastCompleted = nowISOString;
          missionsStats[`${period}Completed`] = (missionsStats[`${period}Completed`] || 0) + 1;
          if (mission.reward) {
            if (mission.reward.type === 'points') totalPointsToAdd += mission.reward.amount || 0;
            if (mission.reward.type === 'gems') totalGemsToAdd += mission.reward.amount || 0;
          }
          console.log(`[BATTLE-REWARD] Awarding ${mission.reward?.amount || 0} ${mission.reward?.type || 'none'} for mission ${missionId} (${title}) to user ${userId}`);
        }
        userMission.completed = true;
      }
      if (period === 'daily' || period === 'weekly') {
        userMission.lastProgress = nowISOString;
      }

      // Update missions object
      missions[period][missionId] = userMission;
      missionsUpdated = true;
    }

    if (missionsUpdated) {
      console.log(`[BATTLE-MISSION-PROGRESS] Updating user ${userId} with ${totalPointsToAdd} points and ${totalGemsToAdd} gems`);
      // Update missions, stats, and add points/gems if any
      const updateParams = {
        TableName: process.env.USERS_TABLE,
        Key: { id: userId },
        UpdateExpression: 'SET missions = :m, missionsStats = :s' + (totalPointsToAdd ? ' ADD flectcoins :p' : '') + (totalGemsToAdd ? ', gems :g' : ''),
        ExpressionAttributeValues: {
          ':m': missions,
          ':s': missionsStats,
        },
      };
      if (totalPointsToAdd) updateParams.ExpressionAttributeValues[':p'] = totalPointsToAdd;
      if (totalGemsToAdd) updateParams.ExpressionAttributeValues[':g'] = totalGemsToAdd;
      await dynamoDB.send(new UpdateCommand(updateParams));
      console.log(`[BATTLE-MISSION-PROGRESS] Successfully updated user ${userId}`);
    } else {
      console.log(`[BATTLE-MISSION-PROGRESS] No missions updated for user ${userId}`);
    }
  } catch (error) {
    console.error(`Error updating battle mission progress for user ${userId}:`, error);
  }
}

// Helper functions for date comparison
function isSameDay(date1, date2) {
  return date1.getFullYear() === date2.getFullYear() && 
         date1.getMonth() === date2.getMonth() && 
         date1.getDate() === date2.getDate();
}

function isSameWeek(date1, date2) {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  d1.setHours(0, 0, 0, 0);
  d2.setHours(0, 0, 0, 0);
  
  // Get Monday of each week
  const getMonday = (date) => {
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(date.setDate(diff));
  };
  
  const monday1 = getMonday(d1);
  const monday2 = getMonday(d2);
  
  return monday1.getTime() === monday2.getTime();
}

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    const { battleId, score, wordsFound } = JSON.parse(event.body);
    
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.error('No valid Authorization header found in submitBattleScore');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Verify and decode the JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      console.error('JWT verification failed in submitBattleScore:', jwtError);
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token', error: jwtError.message }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      console.error('No user ID found in JWT in submitBattleScore');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    if (!battleId || typeof score !== 'number') {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Battle ID and score are required' }),
      };
    }

    // Get the battle
    const battleResponse = await dynamoDB.send(new GetCommand({
      TableName: process.env.BATTLES_TABLE,
      Key: { id: battleId },
    }));

    if (!battleResponse.Item) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Battle not found' }),
      };
    }

    const battle = battleResponse.Item;

    // Verify the battle is active
    if (battle.status !== 'active') {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Battle is not active' }),
      };
    }

    // Verify the user is part of this battle
    if (battle.challengerId !== userId && battle.opponentId !== userId) {
      return {
        statusCode: 403,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Not authorized to submit score for this battle' }),
      };
    }

    // Determine which player is submitting the score
    const isChallenger = battle.challengerId === userId;
    const scoreField = isChallenger ? 'challengerScore' : 'opponentScore';
    const completedField = isChallenger ? 'challengerCompleted' : 'opponentCompleted';

    // Update the battle with the player's score
    let updateExpression = `SET ${scoreField} = :score, ${completedField} = :completed, ${completedField}At = :completedAt`;
    let expressionAttributeValues = {
      ':score': score,
      ':completed': true,
      ':completedAt': new Date().toISOString(),
    };

    // Check if both players have completed their games
    const challengerCompleted = isChallenger ? true : (battle.challengerCompleted || false);
    const opponentCompleted = isChallenger ? (battle.opponentCompleted || false) : true;

    let battleCompleted = false;
    let winner = null;
    let loser = null;

    if (challengerCompleted && opponentCompleted) {
      // Both players have completed - determine winner
      const challengerScore = isChallenger ? score : (battle.challengerScore || 0);
      const opponentScore = isChallenger ? (battle.opponentScore || 0) : score;

      if (challengerScore > opponentScore) {
        winner = battle.challengerId;
        loser = battle.opponentId;
      } else if (opponentScore > challengerScore) {
        winner = battle.opponentId;
        loser = battle.challengerId;
      }
      // If scores are equal, it's a draw (winner remains null)

      battleCompleted = true;
      updateExpression += ', #status = :status, completedAt = :completedAt, winner = :winner';
      expressionAttributeValues[':status'] = 'completed';
      expressionAttributeValues[':completedAt'] = new Date().toISOString();
      expressionAttributeValues[':winner'] = winner;
    }

    const updateParams = {
      TableName: process.env.BATTLES_TABLE,
      Key: { id: battleId },
      UpdateExpression: updateExpression,
      ExpressionAttributeValues: expressionAttributeValues,
    };
    if (updateExpression.includes('#status')) {
      updateParams.ExpressionAttributeNames = { '#status': 'status' };
    }

    await dynamoDB.send(new UpdateCommand(updateParams));

    // Update user stats for wins/losses if battle completed and not a draw
    if (battleCompleted && winner && loser) {
      console.log(`[BATTLE-COMPLETE] Battle ${battleId} completed with winner: ${winner}, loser: ${loser}`);
      
      // Increment battleWins for winner
      await dynamoDB.send(new UpdateCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id: winner },
        UpdateExpression: 'SET battleWins = if_not_exists(battleWins, :zero) + :inc',
        ExpressionAttributeValues: {
          ':inc': 1,
          ':zero': 0,
        },
      }));
      // Increment battleLosses for loser
      await dynamoDB.send(new UpdateCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id: loser },
        UpdateExpression: 'SET battleLosses = if_not_exists(battleLosses, :zero) + :inc',
        ExpressionAttributeValues: {
          ':inc': 1,
          ':zero': 0,
        },
      }));
      
      // Update mission progress for both players ONLY when battle is completed
      const winnerScore = winner === battle.challengerId ? (isChallenger ? score : battle.challengerScore) : (isChallenger ? battle.opponentScore : score);
      const loserScore = loser === battle.challengerId ? (isChallenger ? score : battle.challengerScore) : (isChallenger ? battle.opponentScore : score);
      
      console.log(`[BATTLE-MISSIONS] Updating mission progress for winner ${winner} (score: ${winnerScore}, won: true)`);
      // Update winner's mission progress
      await updateBattleMissionProgress(winner, winnerScore, wordsFound, true);
      console.log(`[BATTLE-MISSIONS] Updating mission progress for loser ${loser} (score: ${loserScore}, won: false)`);
      // Update loser's mission progress  
      await updateBattleMissionProgress(loser, loserScore, wordsFound, false);
    } else if (battleCompleted) {
      console.log(`[BATTLE-COMPLETE] Battle ${battleId} completed as a draw`);
      // Battle completed but it's a draw - update mission progress for both players
      const challengerScore = isChallenger ? score : (battle.challengerScore || 0);
      const opponentScore = isChallenger ? (battle.opponentScore || 0) : score;
      
      console.log(`[BATTLE-MISSIONS] Updating mission progress for challenger ${battle.challengerId} (score: ${challengerScore}, won: false)`);
      await updateBattleMissionProgress(battle.challengerId, challengerScore, wordsFound, false);
      console.log(`[BATTLE-MISSIONS] Updating mission progress for opponent ${battle.opponentId} (score: ${opponentScore}, won: false)`);
      await updateBattleMissionProgress(battle.opponentId, opponentScore, wordsFound, false);
    } else {
      console.log(`[BATTLE-COMPLETE] Battle ${battleId} not completed yet - waiting for other player`);
    }

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'Battle score submitted successfully',
        battleCompleted,
        winner,
        challengerScore: isChallenger ? score : (battle.challengerScore || 0),
        opponentScore: isChallenger ? (battle.opponentScore || 0) : score,
      }),
    };
  } catch (error) {
    console.error('Error submitting battle score:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Internal server error' }),
    };
  }
}; 