const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const USERS_TABLE = process.env.USERS_TABLE;
const MISSIONS_TABLE = process.env.MISSIONS_TABLE;

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    const userId = event.requestContext.authorizer?.claims.sub;
    if (!userId) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Unauthorized' }),
      };
    }

    const { missionId } = JSON.parse(event.body || '{}');
    if (!missionId) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Mission ID is required' }),
      };
    }

    // Get mission
    const missionResult = await dynamoDB.send(new GetCommand({
      TableName: MISSIONS_TABLE,
      Key: { id: missionId },
    }));
    const mission = missionResult.Item;
    if (!mission) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Mission not found' }),
      };
    }

    // Get user
    const userResult = await dynamoDB.send(new GetCommand({
      TableName: USERS_TABLE,
      Key: { id: userId },
    }));
    const user = userResult.Item;
    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    // Check if mission is already completed
    if (user.completedMissions?.includes(missionId)) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Mission already completed' }),
      };
    }

    const rewards = calculateRewards(mission, user);
    const newLevel = calculateNewLevel(user.level, rewards.xp);

    // Update user data
    await dynamoDB.send(new UpdateCommand({
      TableName: USERS_TABLE,
      Key: { id: userId },
      UpdateExpression: 'SET points = if_not_exists(points, :zero) + :points, coins = if_not_exists(coins, :zero) + :coins, xp = if_not_exists(xp, :zero) + :xp, level = :level, completedMissions = list_append(if_not_exists(completedMissions, :empty_list), :missionId)',
      ExpressionAttributeValues: {
        ':points': rewards.points,
        ':coins': rewards.coins,
        ':xp': rewards.xp,
        ':level': newLevel,
        ':missionId': [missionId],
        ':empty_list': [],
        ':zero': 0,
      },
    }));

    // Update mission stats
    await dynamoDB.send(new UpdateCommand({
      TableName: USERS_TABLE,
      Key: { id: userId },
      UpdateExpression: 'SET missionStats.#type = missionStats.#type + :inc',
      ExpressionAttributeNames: {
        '#type': `${mission.type}Completed`,
      },
      ExpressionAttributeValues: {
        ':inc': 1,
      },
    }));

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'Mission completed successfully',
        rewards: rewards,
        newLevel: newLevel,
      }),
    };
  } catch (error) {
    console.error('Error completing mission:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Internal server error' }),
    };
  }
};

function calculateRewards(mission, user) {
  const baseReward = mission.reward.amount;
  const streakMultiplier = calculateStreakMultiplier(user);
  const levelMultiplier = 1 + (user.level * 0.1); // 10% increase per level
  const totalMultiplier = streakMultiplier * levelMultiplier;
  
  return {
    points: Math.floor(baseReward * totalMultiplier),
    coins: Math.floor(baseReward * 0.5 * totalMultiplier),
    xp: Math.floor(baseReward * 0.2 * totalMultiplier),
  };
}

function calculateStreakMultiplier(user) {
  const streak = user.currentStreak || 0;
  if (streak >= 7) return 2.0;
  if (streak >= 5) return 1.5;
  if (streak >= 3) return 1.2;
  return 1.0;
}

function calculateNewLevel(currentLevel, xpGained) {
  const xpPerLevel = 1000; // Base XP required per level
  const totalXp = (currentLevel * xpPerLevel) + xpGained;
  return Math.floor(totalXp / xpPerLevel);
} 