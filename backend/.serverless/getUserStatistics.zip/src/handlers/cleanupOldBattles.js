const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, DeleteCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoDB = DynamoDBDocumentClient.from(new DynamoDBClient({}));

exports.handler = async (event) => {
  try {
    console.log('Starting battle cleanup process...');
    
    // Define cleanup thresholds
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - (30 * 24 * 60 * 60 * 1000)); // 30 days
    const sevenDaysAgo = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000)); // 7 days
    const fourteenDaysAgo = new Date(now.getTime() - (14 * 24 * 60 * 60 * 1000)); // 14 days
    
    // Scan for battles to clean up
    const scanParams = {
      TableName: process.env.BATTLES_TABLE,
      // Get all battles (could be optimized with indexes if needed)
    };
    
    const result = await dynamoDB.send(new ScanCommand(scanParams));
    const battles = result.Items || [];
    
    console.log(`Found ${battles.length} battles to check for cleanup`);
    
    let deletedCount = 0;
    let cancelledCount = 0;
    let skippedCount = 0;
    
    for (const battle of battles) {
      const battleDate = new Date(battle.createdAt);
      let shouldDelete = false;
      let shouldCancel = false;
      let reason = '';
      
      // Delete pending/declined battles older than 7 days
      if ((battle.status === 'pending' || battle.status === 'declined') && battleDate < sevenDaysAgo) {
        shouldDelete = true;
        reason = 'old pending/declined battle';
      }
      // Delete completed battles older than 30 days
      else if (battle.status === 'completed' && battleDate < thirtyDaysAgo) {
        shouldDelete = true;
        reason = 'old completed battle';
      }
      // Auto-cancel and delete active battles older than 14 days
      else if (battle.status === 'active' && battleDate < fourteenDaysAgo) {
        shouldCancel = true;
        reason = 'stale active battle (auto-cancelled)';
      }
      
      if (shouldDelete) {
        try {
          await dynamoDB.send(new DeleteCommand({
            TableName: process.env.BATTLES_TABLE,
            Key: { id: battle.id }
          }));
          deletedCount++;
          console.log(`Deleted battle ${battle.id}: ${reason}`);
        } catch (deleteError) {
          console.error(`Failed to delete battle ${battle.id}:`, deleteError);
        }
      } else if (shouldCancel) {
        try {
          // Set status to 'cancelled' (no stats/rewards)
          await dynamoDB.send(new UpdateCommand({
            TableName: process.env.BATTLES_TABLE,
            Key: { id: battle.id },
            UpdateExpression: 'SET #status = :cancelled, cancelledAt = :now',
            ExpressionAttributeNames: { '#status': 'status' },
            ExpressionAttributeValues: {
              ':cancelled': 'cancelled',
              ':now': now.toISOString(),
            },
          }));
          // Delete after marking as cancelled
          await dynamoDB.send(new DeleteCommand({
            TableName: process.env.BATTLES_TABLE,
            Key: { id: battle.id }
          }));
          cancelledCount++;
          console.log(`Auto-cancelled and deleted battle ${battle.id}: ${reason}`);
        } catch (cancelError) {
          console.error(`Failed to auto-cancel/delete battle ${battle.id}:`, cancelError);
        }
      } else {
        skippedCount++;
      }
    }
    
    console.log(`Cleanup complete: ${deletedCount} deleted, ${cancelledCount} auto-cancelled, ${skippedCount} kept`);
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Battle cleanup completed',
        deletedCount,
        cancelledCount,
        skippedCount,
        totalProcessed: battles.length
      })
    };
  } catch (error) {
    console.error('Error during battle cleanup:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal server error during cleanup' })
    };
  }
}; 