const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const bcrypt = require('bcryptjs');
const { DynamoDBDocumentClient, GetCommand, DeleteCommand, UpdateCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoDB = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoDB);

const PASSWORD_RESET_TABLE = process.env.PASSWORD_RESET_TABLE;
const USERS_TABLE = process.env.USERS_TABLE;

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    const { email, token, newPassword } = JSON.parse(event.body || '{}');
    if (!email || !token || !newPassword) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Email, token, and new password are required.' }),
        headers: corsHeaders,
      };
    }

    // 1. Look up the token for the email using DocumentClient
    const tokenResult = await docClient.send(new GetCommand({
      TableName: PASSWORD_RESET_TABLE,
      Key: { email: email },
    }));
    const item = tokenResult.Item;
    if (!item || !item.token || !item.expiresAt) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Invalid or expired token.' }),
        headers: corsHeaders,
      };
    }
    // 2. Verify token matches and is not expired
    const now = Math.floor(Date.now() / 1000);
    if (item.token !== token || now > item.expiresAt) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Invalid or expired token.' }),
        headers: corsHeaders,
      };
    }

    // 3. Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // 4. Find user by email (scan)
    const { Items: users } = await docClient.send(new ScanCommand({
      TableName: USERS_TABLE,
      FilterExpression: '#email = :email',
      ExpressionAttributeNames: { '#email': 'email' },
      ExpressionAttributeValues: { ':email': email },
    }));
    if (!users || users.length === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'User not found.' }),
        headers: corsHeaders,
      };
    }
    const user = users[0];

    // 5. Update the user's password in the users table by id
    await docClient.send(new UpdateCommand({
      TableName: USERS_TABLE,
      Key: { id: user.id },
      UpdateExpression: 'SET #pw = :pw',
      ExpressionAttributeNames: { '#pw': 'password' },
      ExpressionAttributeValues: { ':pw': hashedPassword },
    }));

    // 6. Delete the used token
    await docClient.send(new DeleteCommand({
      TableName: PASSWORD_RESET_TABLE,
      Key: { email: email },
    }));

    // 7. Return success
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Password has been reset successfully.' }),
      headers: corsHeaders,
    };
  } catch (error) {
    console.error('Reset password error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'An error occurred. Please try again later.' }),
      headers: corsHeaders,
    };
  }
}; 