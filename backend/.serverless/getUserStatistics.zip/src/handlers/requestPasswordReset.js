const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');
const crypto = require('crypto');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);
const ses = new SESClient({});

const PASSWORD_RESET_TABLE = process.env.PASSWORD_RESET_TABLE;
const SES_FROM_EMAIL = process.env.SES_FROM_EMAIL;
const TOKEN_EXPIRY_MINUTES = 30;

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    console.log('SES_FROM_EMAIL:', SES_FROM_EMAIL);
    const { email } = JSON.parse(event.body || '{}');
    if (!email) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Email is required' }),
      };
    }

    // Generate secure token
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = Math.floor(Date.now() / 1000) + TOKEN_EXPIRY_MINUTES * 60; // Unix timestamp (seconds)

    // Store token in DynamoDB
    await dynamoDB.send(new PutCommand({
      TableName: PASSWORD_RESET_TABLE,
      Item: {
        email,
        token,
        expiresAt,
      },
    }));

    // Compose email with deep link
    const resetLink = `wordflect://reset-password?token=${token}&email=${encodeURIComponent(email)}`;
    const emailBodyText = `Hello,

You requested to reset your password for your Wordflect account.

To reset your password, click the link below:

${resetLink}

This link will expire in 30 minutes for security reasons.

If you did not request this password reset, please ignore this email. Your account remains secure.

Best regards,
The Wordflect Team

---
Wordflect - Word Puzzle Game
This is an automated message. Please do not reply to this email.`;
    const emailBodyHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Password Reset - Wordflect</title>
        </head>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f8f9fa;">
          <div style="background-color: white; border-radius: 8px; padding: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <div style="text-align: center; margin-bottom: 30px;">
              <h1 style="color: #1976d2; margin: 0; font-size: 24px;">Wordflect</h1>
              <p style="color: #666; margin: 5px 0 0 0; font-size: 14px;">Word Puzzle Game</p>
            </div>
            
            <h2 style="color: #333; margin-bottom: 20px;">Password Reset Request</h2>
            
            <p>Hello,</p>
            
            <p>You requested to reset your password for your Wordflect account.</p>
            
            <p>To reset your password, click the button below:</p>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${resetLink}" style="background-color: #1976d2; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: 600; font-size: 16px;">Reset My Password</a>
            </div>
            
            <p style="color: #666; font-size: 14px; margin-top: 30px;">
              <strong>Security Note:</strong> This link will expire in 30 minutes for your security.
            </p>
            
            <p style="color: #666; font-size: 14px;">
              If you did not request this password reset, please ignore this email. Your account remains secure.
            </p>
            
            <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
            
            <p style="color: #999; font-size: 12px; text-align: center; margin: 0;">
              Best regards,<br>
              The Wordflect Team<br><br>
              This is an automated message. Please do not reply to this email.
            </p>
          </div>
        </body>
      </html>
    `;
    const emailParams = {
      Destination: {
        ToAddresses: [email],
      },
      Message: {
        Body: {
          Text: {
            Data: emailBodyText,
          },
          Html: {
            Data: emailBodyHtml,
          },
        },
        Subject: {
          Data: 'Reset your Wordflect password',
        },
      },
      Source: SES_FROM_EMAIL,
      ReplyToAddresses: [SES_FROM_EMAIL],
      ReturnPath: SES_FROM_EMAIL,
    };

    console.log('SES emailParams:', JSON.stringify(emailParams, null, 2));
    await ses.send(new SendEmailCommand(emailParams));

    // Always return success (do not reveal if email exists)
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'If an account with that email exists, a password reset link has been sent.' }),
    };
  } catch (error) {
    console.error('Password reset error:', error);
    
    // Check for specific error types
    if (error.name === 'ValidationError') {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid email format' }),
      };
    }
    
    if (error.name === 'SESError') {
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Error sending email. Please try again later.' }),
      };
    }

    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'An error occurred. Please try again later.' }),
    };
  }
}; 