const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, PutCommand } = require('@aws-sdk/lib-dynamodb');

// Use bcrypt for password hashing to match signin handler
async function hashPassword(password) {
  const saltRounds = 10;
  return await bcrypt.hash(password, saltRounds);
}

// Simple JWT-like token generation (same as original, but with proper payload)
function generateToken(payload) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const encodedHeader = Buffer.from(JSON.stringify(header)).toString('base64url');
  const encodedPayload = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto.createHmac('sha256', process.env.JWT_SECRET || 'fallback-secret')
    .update(`${encodedHeader}.${encodedPayload}`)
    .digest('base64url');
  return `${encodedHeader}.${encodedPayload}.${signature}`;
}

// Initialize DynamoDB client
const client = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-2' });
const docClient = DynamoDBDocumentClient.from(client);

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  console.log('Signup handler called with event:', JSON.stringify(event, null, 2));
  
  // Handle OPTIONS request for CORS
  if (event.httpMethod === 'OPTIONS') {
    console.log('Handling OPTIONS request');
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: '',
    };
  }
  
  try {
    const { username, email, password } = JSON.parse(event.body);
    
    // Validate input
    if (!username || !email || !password) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Username, email, and password are required' })
      };
    }

    // Additional validation
    if (username.length < 3 || username.length > 20) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Username must be between 3 and 20 characters' })
      };
    }

    if (password.length < 6) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Password must be at least 6 characters long' })
      };
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Please enter a valid email address' })
      };
    }

    // Convert email to lowercase for consistency
    const emailLower = email.toLowerCase();
    console.log('Original email:', email);
    console.log('Storing email as:', emailLower);

    // Check if username already exists
    const scanParams = {
      TableName: process.env.USERS_TABLE || 'wordflect-users-prod',
      FilterExpression: 'username = :username',
      ExpressionAttributeValues: {
        ':username': username
      }
    };

    const existingUsers = await docClient.send(new ScanCommand(scanParams));
    
    if (existingUsers.Items && existingUsers.Items.length > 0) {
      return {
        statusCode: 409,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Username is already taken' })
      };
    }

    // Check if email already exists (case-insensitive)
    const emailScanParams = {
      TableName: process.env.USERS_TABLE || 'wordflect-users-prod'
    };

    const existingEmails = await docClient.send(new ScanCommand(emailScanParams));
    
    // Filter for existing emails case-insensitively
    const existingUser = existingEmails.Items?.find(item => 
      item.email && item.email.toLowerCase() === emailLower
    );
    
    if (existingUser) {
      console.log('Email already exists:', existingUser.email);
      return {
        statusCode: 409,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Email is already registered' })
      };
    }

    // Create user
    const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const hashedPassword = await hashPassword(password);
    
    const userItem = {
      id: userId,
      username: username,
      email: emailLower, // Store email in lowercase
      password: hashedPassword,
      createdAt: new Date().toISOString(),
      level: 1,
      highestLevel: 1,
      experience: 0,
      points: 0,
      gems: 0,
      flectcoins: 150,  // Increased from 100 to allow 2 shuffles + 1 hint (40+40+25=105) plus extra for flexibility
      coins: 100,
      selectedFrame: null,
      unlockedFrames: ['spiked-steel'],
      frames: ['spiked-steel'],
      missions: { daily: {}, weekly: {}, global: {} }, // Initialize missions object properly
      missionsStats: { dailyCompleted: 0, weeklyCompleted: 0, globalCompleted: 0 }, // Initialize missions stats
      gamesPlayed: 0,
      topScore: 0,
      longestWord: '',
      allFoundWords: [],
      profileImageUrl: null,
      profileImageKey: null,
      selectedBackground: null,
      usernameColor: null,
      firstPlaceFinishes: 0,
      secondPlaceFinishes: 0,
      thirdPlaceFinishes: 0,
      stats: {
        gamesPlayed: 0,
        gamesWon: 0,
        totalScore: 0,
        averageScore: 0
      }
    };

    await docClient.send(new PutCommand({
      TableName: process.env.USERS_TABLE || 'wordflect-users-prod',
      Item: userItem
    }));

    console.log('User created successfully:', {
      id: userId,
      username: username,
      email: email
    });

    // Generate token using proper JWT library to match signin handler
    const token = generateToken({
      id: userId,
      email: email,
      username: username,
    });

    console.log('JWT generated successfully');

    // Return success response
    return {
      statusCode: 201,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'User created successfully',
        user: {
          id: userId,
          email: email,
          username: username,
          createdAt: userItem.createdAt,
        },
        token,
      })
    };

  } catch (error) {
    console.error('Error in signup handler:', error);
    console.error('Error stack:', error.stack);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Internal server error', error: error.message })
    };
  }
}; 