const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

// Initialize S3 client with proper configuration
const s3 = new S3Client({ region: 'us-east-2' });

const BUCKET = 'wordflect-profile-images';
const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    console.log('getProfileImageUploadUrl event:', event);
    const { id, fileType } = JSON.parse(event.body || '{}');
    console.log('Parsed id:', id, 'fileType:', fileType);
    if (!id) {
      console.error('Missing id');
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Unauthorized: id required.' }),
      };
    }
    // Always use encodeURIComponent(id) for the key
    const ext = fileType && fileType.split('/')[1] ? fileType.split('/')[1] : 'jpg';
    const encodedId = encodeURIComponent(id);
    const key = `profile-images/${encodedId}/profile.${ext}`;
    
    // Debug: print the AWS Access Key ID being used
    const currentCreds = await s3.config.credentials();
    console.log('S3 client using accessKeyId:', currentCreds.accessKeyId);
    
    console.log('Generating presigned URL for:', { Bucket: BUCKET, Key: key });
    const command = new PutObjectCommand({
      Bucket: BUCKET,
      Key: key,
      ContentType: fileType || 'image/jpeg'
    });

    try {
      const uploadUrl = await getSignedUrl(s3, command, { expiresIn: 300 }); // 5 min expiry
      console.log('Generated presigned URL:', uploadUrl);
      
      const imageUrl = `https://${BUCKET}.s3.us-east-2.amazonaws.com/${key}`;
      // Save the key in the user's DynamoDB record for reliable retrieval
      await dynamoDB.send(new UpdateCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id },
        UpdateExpression: 'SET profileImageKey = :key',
        ExpressionAttributeValues: {
          ':key': key,
        },
      }));

      return {
        statusCode: 200,
        body: JSON.stringify({ uploadUrl, imageUrl }),
        headers: corsHeaders,
      };
    } catch (s3Error) {
      console.error('S3 presigned URL generation error:', s3Error);
      throw s3Error;
    }
  } catch (error) {
    console.error('getProfileImageUploadUrl error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Failed to generate upload URL.' }),
    };
  }
}; 