const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
  try {
    // Extract and verify JWT
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Authorization header required' }),
        headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Credentials': true },
      };
    }
    const token = authHeader.replace('Bearer ', '');
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Invalid token' }),
        headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Credentials': true },
      };
    }

    // Get query param
    const query = event.queryStringParameters?.username?.toLowerCase() || '';
    
    // If no query, return all users (for initial load)
    if (!query) {
      const scanResult = await dynamoDB.send(new ScanCommand({
        TableName: process.env.USERS_TABLE,
        ProjectionExpression: 'id, username, #lvl, highestLevel, profileImageUrl',
        ExpressionAttributeNames: {
          '#lvl': 'level'
        }
      }));
      const allUsers = scanResult.Items || [];
      return {
        statusCode: 200,
        body: JSON.stringify({ users: allUsers }),
        headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Credentials': true },
      };
    }
    
    // If query is too short, return error
    if (query.length < 2) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Username parameter required (min 2 chars)' }),
        headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Credentials': true },
      };
    }

    // Scan users table (for demo, in production use an index or search service)
    const scanResult = await dynamoDB.send(new ScanCommand({
      TableName: process.env.USERS_TABLE,
      ProjectionExpression: 'id, username, #lvl, highestLevel, profileImageUrl',
      ExpressionAttributeNames: {
        '#lvl': 'level'
      }
    }));
    const allUsers = scanResult.Items || [];
    // Filter users by username (case-insensitive, partial match)
    const users = allUsers.filter(u =>
      u.username && u.username.toLowerCase().includes(query)
    ).slice(0, 20); // Limit to 20 results

    return {
      statusCode: 200,
      body: JSON.stringify({ users }),
      headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Credentials': true },
    };
  } catch (error) {
    console.error('User search error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal server error' }),
      headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Credentials': true },
    };
  }
}; 