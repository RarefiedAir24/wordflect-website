const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);
const USERS_TABLE = process.env.USERS_TABLE;
const MISSIONS_TABLE = process.env.MISSIONS_TABLE;

exports.handler = async (event) => {
  try {
    console.log('completeUserMission event:', event);
    const { id, missionId, period } = JSON.parse(event.body || '{}');
    if (!id || !missionId || !period) {
      console.log('Missing required fields:', { id, missionId, period });
      return { statusCode: 400, body: JSON.stringify({ message: 'id, missionId, and period required' }) };
    }
    // Get user
    const { Item: user } = await dynamoDB.send(new GetCommand({ TableName: USERS_TABLE, Key: { id } }));
    if (!user) {
      console.log('User not found:', id);
      return { statusCode: 404, body: JSON.stringify({ message: 'User not found' }) };
    }
    // Fetch mission definition from global missions table
    const { Item: missionDef } = await dynamoDB.send(new GetCommand({ TableName: MISSIONS_TABLE, Key: { id: missionId } }));
    console.log('Fetched missionDef:', missionDef);
    let reflectcoinsToAdd = 0;
    let gemsToAdd = 0;
    if (missionDef && missionDef.reward) {
      if (missionDef.reward.type === 'flectcoins') reflectcoinsToAdd = missionDef.reward.amount || 0;
      if (missionDef.reward.type === 'gems') gemsToAdd = missionDef.reward.amount || 0;
    }
    console.log('reflectcoinsToAdd:', reflectcoinsToAdd, 'gemsToAdd:', gemsToAdd);
    // Update mission progress
    const now = new Date();
    const nowISOString = now.toISOString();
    let missions = user.missions || { daily: {}, weekly: {}, global: {} };
    let missionsStats = user.missionsStats || { dailyCompleted: 0, weeklyCompleted: 0, globalCompleted: 0 };

    // Helper to check if a date is today (UTC)
    function isToday(dateString) {
      if (!dateString) return false;
      const date = new Date(dateString);
      return date.getFullYear() === now.getFullYear() &&
        date.getMonth() === now.getMonth() &&
        date.getDate() === now.getDate();
    }

    // Helper to check if a date is in the current week (local time, week starts Monday)
    function isThisWeek(dateString) {
      if (!dateString) return false;
      const date = new Date(dateString);
      const nowDate = new Date(now);
      
      // Get Monday of each week
      const getMonday = (date) => {
        const day = date.getDay();
        const diff = date.getDate() - day + (day === 0 ? -6 : 1); // Adjust when day is Sunday
        const monday = new Date(date);
        monday.setDate(diff);
        return monday;
      };
      
      const monday1 = getMonday(new Date(date));
      const monday2 = getMonday(new Date(nowDate));
      
      return monday1.getTime() === monday2.getTime();
    }

    let canComplete = false;
    if (!missions[period][missionId]) {
      canComplete = true;
    } else if (period === 'daily') {
      // For daily missions, check if it was completed today
      const lastCompleted = missions[period][missionId].lastCompleted;
      if (!lastCompleted || !isToday(lastCompleted)) {
        canComplete = true;
      }
    } else if (period === 'weekly') {
      // For weekly missions, check if it was completed this week
      const lastCompleted = missions[period][missionId].lastCompleted;
      if (!lastCompleted || !isThisWeek(lastCompleted)) {
        canComplete = true;
      }
    } else if (period === 'global') {
      // For global missions, only allow completion if never completed before
      canComplete = !missions[period][missionId].completed;
    }

    // Additional check: prevent manual completion for auto-tracked missions
    // This prevents double rewards when both updateUserStats and completeUserMission could award rewards
    if (canComplete && missions[period][missionId]) {
      const userMission = missions[period][missionId];
      
      // For auto-tracked missions (like "Play 1 Game Today"), prevent manual completion
      // These missions are automatically completed by updateUserStats during gameplay
      const autoTrackedMissions = [
        'daily-play-1-game-today',
        'daily-play-3-games',
        'daily-score-100-points',
        'daily-score-200-points',
        'daily-find-10-words',
        'daily-find-15-words',
        'daily-find-20-words',
        'daily-find-25-words',
        'daily-find-30-words',
        'daily-find-40-words',
        'daily-find-50-words',
        'daily-find-75-words',
        'daily-find-100-words',
        'daily-find-125-words',
        'daily-find-150-words',
        'daily-find-200-words',
        'daily-find-3-long-words',
        'daily-find-a-long-word',
        'daily-complete-game-without-hints',
        'daily-find-the-word-of-the-day'
      ];
      
      if (autoTrackedMissions.includes(missionId)) {
        console.log(`[DOUBLE-REWARD-PREVENTION] Mission ${missionId} is auto-tracked, preventing manual completion`);
        canComplete = false;
      }
      
      // Also check if mission was already completed today (additional safety)
      if (period === 'daily' && userMission.lastCompleted) {
        const lastCompletedDate = new Date(userMission.lastCompleted);
        const isToday = lastCompletedDate.getUTCFullYear() === now.getUTCFullYear() &&
          lastCompletedDate.getUTCMonth() === now.getUTCMonth() &&
          lastCompletedDate.getUTCDate() === now.getUTCDate();
        
        if (isToday && userMission.completed) {
          console.log(`[DOUBLE-REWARD-PREVENTION] Mission ${missionId} already completed today, preventing manual completion`);
          canComplete = false;
        }
      }
    }

    if (canComplete) {
      const currentProgress = missions[period][missionId]?.progress || 0;
      missions[period][missionId] = { 
        completed: true, 
        lastCompleted: nowISOString,
        progress: currentProgress 
      };
      // Increment stat
      if (period === 'daily') missionsStats.dailyCompleted++;
      if (period === 'weekly') missionsStats.weeklyCompleted++;
      if (period === 'global') missionsStats.globalCompleted++;
      // Save and award points
      console.log('Preparing to update user for mission completion:', {
        id,
        missions,
        missionsStats,
        reflectcoinsToAdd,
        gemsToAdd
      });
      try {
        const updateResult = await dynamoDB.send(new UpdateCommand({
          TableName: USERS_TABLE,
          Key: { id },
          UpdateExpression: 'SET missions = :m, missionsStats = :s ADD flectcoins :f, gems :g',
          ExpressionAttributeValues: { ':m': missions, ':s': missionsStats, ':f': reflectcoinsToAdd, ':g': gemsToAdd },
        }));
        console.log('User update complete, DynamoDB result:', updateResult);
      } catch (err) {
        console.error('Error updating user points/gems:', err);
      }
    } else {
      // If not eligible, just update the lastCompleted if needed (no points)
      const currentProgress = missions[period][missionId]?.progress || 0;
      missions[period][missionId] = missions[period][missionId] || { 
        completed: false, 
        lastCompleted: null,
        progress: currentProgress 
      };
      console.log('Mission already completed today, not awarding points.');
      await dynamoDB.send(new UpdateCommand({
        TableName: USERS_TABLE,
        Key: { id },
        UpdateExpression: 'SET missions = :m, missionsStats = :s',
        ExpressionAttributeValues: { ':m': missions, ':s': missionsStats },
      }));
    }
    
    // Get updated user data to include reflectcoins in response
    const { Item: updatedUser } = await dynamoDB.send(new GetCommand({ 
      TableName: USERS_TABLE, 
      Key: { id },
      ProjectionExpression: 'flectcoins, gems'
    }));
    
    return { 
      statusCode: 200, 
      body: JSON.stringify({ 
        success: true, 
        missions, 
        missionsStats,
        reflectcoins: updatedUser.flectcoins || 0,
        gems: updatedUser.gems || 0
      }) 
    };
  } catch (error) {
    console.error('Complete user mission error:', error);
    return { statusCode: 500, body: JSON.stringify({ message: 'An error occurred.' }) };
  }
}; 