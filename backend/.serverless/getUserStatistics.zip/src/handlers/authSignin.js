const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : '';
  const headers = {
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
  if (corsOrigin) {
    headers['Access-Control-Allow-Origin'] = corsOrigin;
  }
  return headers;
}

exports.handler = async (event) => {
  console.log('Signin handler started');
  console.log('HTTP Method:', event.httpMethod);
  console.log('Event:', JSON.stringify(event, null, 2));
  const corsHeaders = getCorsHeaders(event);
  console.log('CORS Headers:', JSON.stringify(corsHeaders, null, 2));
  
  // Handle OPTIONS request for CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    console.log('Handling OPTIONS request');
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: '',
    };
  }

  try {
    console.log('Parsing request body...');
    const { email, password } = JSON.parse(event.body);
    console.log('Attempting signin for email:', email);
    console.log('Password provided:', password ? 'Yes' : 'No');

    // Validate input
    if (!email || !password) {
      console.log('Missing email or password');
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Email and password are required' }),
      };
    }

    console.log('Environment variables:');
    console.log('USERS_TABLE:', process.env.USERS_TABLE);
    console.log('JWT_SECRET:', process.env.JWT_SECRET ? 'Set' : 'Not set');

    // Scan for all users and filter by email case-insensitively
    console.log('Scanning user table:', process.env.USERS_TABLE);
    const scanResult = await dynamoDB.send(new ScanCommand({
      TableName: process.env.USERS_TABLE
    }));
    
    // Filter users by email case-insensitively
    const user = scanResult.Items?.find(item => 
      item.email && item.email.toLowerCase() === email.toLowerCase()
    );
    
    console.log('Found user:', user ? 'Yes' : 'No');
    if (user) {
      console.log('User email:', user.email);
      console.log('Input email:', email);
      console.log('Case-insensitive match:', user.email.toLowerCase() === email.toLowerCase());
    }
    console.log('Scan result count:', scanResult.Items?.length || 0);
    
    if (!user) {
      console.log('No user found with email:', email);
      // Log char codes and length for debugging
      console.log('Received email:', email, 'Length:', email.length, 'Char codes:', email.split('').map(c => c.charCodeAt(0)));
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid credentials' }),
      };
    }

    // Log stored email details for debugging
    console.log('Found user:', JSON.stringify(user, null, 2));
    console.log('Stored email:', user.email, 'Length:', user.email.length, 'Char codes:', user.email.split('').map(c => c.charCodeAt(0)));
    console.log('Stored password hash:', user.password);

    // Compare password with stored hash
    console.log('Comparing passwords...');
    const isMatch = await bcrypt.compare(password, user.password);
    console.log('Password match:', isMatch);
    
    if (!isMatch) {
      console.log('Password does not match');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid credentials' }),
      };
    }

    console.log('Password verified, generating JWT...');
    // Generate JWT token
    const token = jwt.sign(
      { 
        id: user.id,
        email: user.email,
        username: user.username,
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    console.log('JWT generated successfully');

    // Return token and user info, including id
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'Sign in successful',
        user: {
          id: user.id,
          email: user.email,
          username: user.username,
          createdAt: user.createdAt,
        },
        token,
      }),
    };
  } catch (error) {
    console.error('Error in signin handler:', error);
    console.error('Error stack:', error.stack);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Internal server error', error: error.message }),
    };
  }
}; 