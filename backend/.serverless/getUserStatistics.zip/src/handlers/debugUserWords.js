const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  
  try {
    // Get user ID from query parameters
    const userId = event.queryStringParameters?.userId;
    if (!userId) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'userId parameter is required' })
      };
    }

    // Fetch user data
    const { Item: user } = await dynamoDB.send(new GetCommand({ 
      TableName: process.env.USERS_TABLE, 
      Key: { id: userId } 
    }));
    
    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'User not found' })
      };
    }

    // Get today's date
    const today = new Date().toISOString().split('T')[0];
    
    // Filter words found today
    const allFoundWords = user.allFoundWords || [];
    const todayWords = allFoundWords.filter(w => {
      if (typeof w === 'string') return false; // Skip old format
      if (w.date) {
        const wordDate = new Date(w.date).toISOString().split('T')[0];
        return wordDate === today;
      }
      return false;
    });

    // Check if SEAL is in today's words
    const sealFound = todayWords.find(w => w.word && w.word.toUpperCase() === 'SEAL');

    // Get all words with dates (last 20)
    const wordsWithDates = allFoundWords
      .filter(w => typeof w === 'object' && w.date)
      .slice(-20);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        debug: {
          userId,
          today,
          totalWords: allFoundWords.length,
          todayWordsCount: todayWords.length,
          todayWords: todayWords.map(w => ({ word: w.word, date: w.date })),
          sealFound: sealFound ? { word: sealFound.word, date: sealFound.date } : null,
          recentWordsWithDates: wordsWithDates.map(w => ({ word: w.word, date: w.date })),
          allFoundWordsSample: allFoundWords.slice(-10) // Last 10 entries
        }
      })
    };

  } catch (error) {
    console.error('Debug error:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        error: 'Internal server error',
        details: error.message 
      })
    };
  }
};

