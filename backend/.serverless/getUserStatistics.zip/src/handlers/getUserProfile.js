const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const jwt = require('jsonwebtoken');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);
const s3 = new S3Client({ region: 'us-east-2' });
const BUCKET = 'wordflect-profile-images';
const MISSIONS_TABLE = process.env.MISSIONS_TABLE;

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

// Helper: fetch all missions from DynamoDB
async function fetchAllMissions() {
  const result = await dynamoDB.send(new ScanCommand({ TableName: MISSIONS_TABLE }));
  return result.Items || [];
}

// Add defaultFrames definition (copy from selectUserFrame.js)
const defaultFrames = [
  { id: 'spiked-steel', name: 'Spiked Steel', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/spiked-steel.png', rarity: 'common', isDefault: true, price: 0 },
  { id: 'ice-crystal', name: 'Ice Crystal', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-crystal.png', rarity: 'common', isDefault: true, price: 0 },
  { id: 'heart-gold', name: 'Heart Gold', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/heart-gold.png', rarity: 'rare', unlockedAt: 5, price: 150 },
  { id: 'skull-bone', name: 'Skull Bone', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/skull-bone.png', rarity: 'rare', unlockedAt: 5, price: 200 },
  { id: 'blue-spikes', name: 'Blue Spikes', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-spikes.png', rarity: 'rare', unlockedAt: 5, price: 250 },
  { id: 'wood-diamonds', name: 'Wood Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wood-diamonds.png', rarity: 'rare', unlockedAt: 8, price: 300 },
  { id: 'fire-frame', name: 'Fire Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/fire-frame.png', rarity: 'rare', unlockedAt: 5, price: 200 },
  { id: 'halo', name: 'Halo', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/halo.png', rarity: 'epic', unlockedAt: 10, price: 400 },
  { id: 'blue-diamonds', name: 'Blue Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-diamonds.png', rarity: 'epic', unlockedAt: 15, price: 500 },
  { id: 'dark-bling', name: 'Dark Bling', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dark-bling.png', rarity: 'epic', unlockedAt: 18, price: 600 },
  { id: 'galaxy-frame', name: 'Galaxy Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/galaxy-frame.png', rarity: 'epic', unlockedAt: 12, price: 500 },
  { id: 'gradient-diamond', name: 'Gradient Diamond', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/gradient-diamond.png', rarity: 'legendary', unlockedAt: 20, price: 800 },
  { id: 'empress', name: 'Empress', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/empress.png', rarity: 'legendary', battleWinsRequired: 25, price: 1000 },
  { id: 'wings', name: 'Wings', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wings.png', rarity: 'legendary', battleWinsRequired: 10, price: 1200 },
  { id: 'dragon-frame', name: 'Dragon Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-frame.png', rarity: 'legendary', unlockedAt: 25, price: 1000 },
  { id: 'vine-frame', name: 'Vine Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/vine-frame.png', rarity: 'epic', unlockedAt: 15, price: 600 },
  { id: 'cyber-frame', name: 'Cyber Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/cyber-frame.png', rarity: 'epic', unlockedAt: 18, price: 700 },
  { id: 'ice-shard', name: 'Ice Shard', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-shard.png', rarity: 'epic', unlockedAt: 20, price: 800 },
];

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    console.log('getUserProfile handler started.');
    console.log('Event:', JSON.stringify(event, null, 2));
    
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.error('No valid Authorization header found');
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Authorization header required' }),
        headers: corsHeaders,
      };
    }

    const token = authHeader.replace('Bearer ', '');
    console.log('Extracted token from header');

    // Verify and decode the JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
      console.log('JWT token verified successfully');
    } catch (jwtError) {
      console.error('JWT verification failed:', jwtError);
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'Invalid token' }),
        headers: corsHeaders,
      };
    }

    const userId = decoded.id;
    console.log('Extracted userId from JWT:', userId);

    if (!userId) {
      console.error('No userId found in JWT token');
      return {
        statusCode: 401,
        body: JSON.stringify({ message: 'User not authorized.' }),
        headers: corsHeaders,
      };
    }

    console.log('Fetching user from DynamoDB with ID:', userId);
    console.log('Using table:', process.env.USERS_TABLE);

    // Fetch the user from DynamoDB using the secure userId
    const { Item: user } = await dynamoDB.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
    }));

    if (!user) {
      console.log('User not found in DynamoDB with id:', userId);
      return {
        statusCode: 404,
        body: JSON.stringify({ message: 'User not found' }),
        headers: corsHeaders,
      };
    }

    console.log('Found user profile:', user.id);
    // Use public URL for profile image since S3 bucket is publicly accessible
    let profileImageUrl = '';
    if (user.profileImageKey) {
      console.log('Using public URL for profile image key:', user.profileImageKey);
      profileImageUrl = `https://${BUCKET}.s3.us-east-2.amazonaws.com/${user.profileImageKey}`;
      console.log('Generated public URL:', profileImageUrl);
    } else if (user.profileImageUrl) {
      // fallback for legacy
      profileImageUrl = user.profileImageUrl;
      console.log('Using legacy profile image URL:', profileImageUrl);
    }

    // --- Sum points and gems from completed missions ---
    // REMOVE sumCompleted logic
    // Use persistent points and gems fields
    const totalPoints = user.points || 0;
    const totalGems = user.gems || 0;
    // --- End sum points/gems ---

    // Get user's unlocked frames
    const unlockedFrames = user.unlockedFrames || [];
    console.log('User unlocked frames:', unlockedFrames);

    // Get user's selected frame
    let selectedFrame = user.selectedFrame;
    console.log('User selected frame from DB:', selectedFrame);

    // If selectedFrame is a string (frame ID), get the full frame object
    if (selectedFrame && typeof selectedFrame === 'string') {
      selectedFrame = defaultFrames.find(f => f.id === selectedFrame);
      console.log('Found selected frame from defaultFrames:', selectedFrame);
    }

    // Return user profile with selected frame
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        id: user.id,
        username: user.username,
        email: user.email,
        profileImageUrl: profileImageUrl || user.profileImageUrl,
        highestLevel: user.highestLevel || 1,
        flectcoins: user.flectcoins !== undefined ? user.flectcoins : (user.points || 0),
        points: user.points || 0,
        gems: user.gems || 0,
        allFoundWords: user.allFoundWords || [],
        selectedFrame: selectedFrame || null,
        gamesPlayed: user.gamesPlayed || 0,
        topScore: user.topScore || 0,
        longestWord: user.longestWord || '',
        leaderboardPlacements: user.leaderboardPlacements || 0,
        battleWins: user.battleWins || 0,
        battleLosses: user.battleLosses || 0,
        firstPlaceFinishes: user.firstPlaceFinishes || 0,
        secondPlaceFinishes: user.secondPlaceFinishes || 0,
        thirdPlaceFinishes: user.thirdPlaceFinishes || 0,
        isPremium: user.isPremium || false,
        selectedBackground: user.selectedBackground || null,
        usernameColor: user.usernameColor || null,
        premiumTier: user.premiumTier || null,
        subscriptionEndDate: user.subscriptionEndDate || null,
        themeWordsFoundToday: user.themeWordsFoundToday || []
      }),
    };
  } catch (error) {
    console.error('Get user profile error:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'An error occurred. Please try again later.', error: error.message }),
    };
  }
}; 