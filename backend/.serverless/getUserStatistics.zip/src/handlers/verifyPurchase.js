const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');
const fetch = require('node-fetch');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const APPLE_VALIDATION_URL = 'https://buy.itunes.apple.com/verifyReceipt';
const APPLE_SANDBOX_VALIDATION_URL = 'https://sandbox.itunes.apple.com/verifyReceipt';

const gemProducts = {
  'gems_100': 100,
  'gems_500': 500,
  'gems_1200': 1200,
  'gems_2500': 2500,
  'gems_5000': 5000,
  'gems_12000': 12000,
};

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

async function validateReceipt(receipt, isSandbox) {
  const url = isSandbox ? APPLE_SANDBOX_VALIDATION_URL : APPLE_VALIDATION_URL;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ 'receipt-data': receipt }),
  });

  if (!response.ok) {
    throw new Error(`Failed to validate receipt. Status: ${response.status}`);
  }

  const jsonResponse = await response.json();

  // If the receipt is from the sandbox, but we sent to production, Apple sends back a specific status code.
  // We should retry against the sandbox environment.
  if (jsonResponse.status === 21007 && !isSandbox) {
    return validateReceipt(receipt, true);
  }

  if (jsonResponse.status !== 0) {
    throw new Error(`Invalid receipt. Status: ${jsonResponse.status}`);
  }

  return jsonResponse;
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  const authHeader = event.headers?.Authorization || event.headers?.authorization;
  if (!authHeader) {
    return { statusCode: 401, body: JSON.stringify({ message: 'Authorization header is required' }) };
  }

  try {
    const token = authHeader.replace('Bearer ', '');
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id;

    const { receipt, productId, isDevelopment } = JSON.parse(event.body);

    if (!receipt || !productId) {
      return { statusCode: 400, body: JSON.stringify({ message: 'Receipt and productId are required.' }) };
    }

    // Handle development mode
    if (isDevelopment) {
      console.log('Development mode: Bypassing Apple receipt validation');
      
      const gemsToAdd = gemProducts[productId];
      if (!gemsToAdd) {
        return { statusCode: 400, body: JSON.stringify({ message: 'Invalid product ID.' }) };
      }
      
      const userResult = await dynamoDB.send(new GetCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id: userId },
      }));

      if (!userResult.Item) {
        return { statusCode: 404, body: JSON.stringify({ message: 'User not found.' }) };
      }

      const currentUser = userResult.Item;
      const newGemCount = (currentUser.gems || 0) + gemsToAdd;

      await dynamoDB.send(new UpdateCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id: userId },
        UpdateExpression: 'set gems = :gems',
        ExpressionAttributeValues: { ':gems': newGemCount },
      }));

      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({ success: true, gems: newGemCount }),
      };
    }

    const validationResponse = await validateReceipt(receipt, false); // Assume production first

    // Ensure the product ID from the validated receipt matches the one sent from the client
    const purchasedProductId = validationResponse.receipt.in_app[0].product_id;
    if (purchasedProductId !== productId) {
        return { statusCode: 400, body: JSON.stringify({ message: 'Product ID mismatch.' }) };
    }
    
    const gemsToAdd = gemProducts[productId];
    if (!gemsToAdd) {
      return { statusCode: 400, body: JSON.stringify({ message: 'Invalid product ID.' }) };
    }
    
    const userResult = await dynamoDB.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
    }));

    if (!userResult.Item) {
      return { statusCode: 404, body: JSON.stringify({ message: 'User not found.' }) };
    }

    const currentUser = userResult.Item;
    const newGemCount = (currentUser.gems || 0) + gemsToAdd;

    await dynamoDB.send(new UpdateCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
      UpdateExpression: 'set gems = :gems',
      ExpressionAttributeValues: { ':gems': newGemCount },
    }));

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ success: true, gems: newGemCount }),
    };

  } catch (error) {
    console.error('Error verifying purchase:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal server error', error: error.message }),
    };
  }
}; 