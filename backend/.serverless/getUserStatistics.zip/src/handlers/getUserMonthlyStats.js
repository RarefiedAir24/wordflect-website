const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoDB = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-2' });
const docClient = DynamoDBDocumentClient.from(dynamoDB);

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const allowedOrigins = [
    'https://wordflect.com',
    'https://www.wordflect.com',
    'https://wordflect.app',
    'https://www.wordflect.app',
    'http://localhost:3000',
    'http://localhost:3001'
  ];

  return {
    'Access-Control-Allow-Origin': allowedOrigins.includes(origin) ? origin : '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };
}

// Helper function to get month strings
function getMonthString(date) {
  return date.toISOString().substring(0, 7); // YYYY-MM
}

function getDateString(date) {
  return date.toISOString().split('T')[0];
}

function formatTime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  if (hours > 0) {
    return `${hours}h ${minutes}m ${secs}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${secs}s`;
  } else {
    return `${secs}s`;
  }
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  
  try {
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Verify and decode the JWT token
    const jwt = require('jsonwebtoken');
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token' }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    // Parse query parameters
    const queryParams = event.queryStringParameters || {};
    const requestedMonth = queryParams.month;
    
    let targetMonth;
    if (requestedMonth) {
      // Validate month format (YYYY-MM)
      if (!/^\d{4}-\d{2}$/.test(requestedMonth)) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ message: 'Invalid month format. Use YYYY-MM' }),
        };
      }
      targetMonth = requestedMonth;
    } else {
      targetMonth = getMonthString(new Date());
    }

    // Get user data
    const { Item: user } = await docClient.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId }
    }));

    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    // Get monthly stats for the requested month
    const monthlyStats = user.monthlyStats || {};
    const monthStats = monthlyStats[targetMonth] || {
      gamesPlayed: 0,
      highScore: 0,
      totalScore: 0,
      wordsFound: 0,
      playTime: 0
    };

    // Calculate daily breakdown for this month
    const dailyStats = user.dailyStats || {};
    const dailyBreakdown = [];
    
    // Get the start and end dates for this month
    const [year, month] = targetMonth.split('-');
    const monthStart = new Date(parseInt(year), parseInt(month) - 1, 1);
    const monthEnd = new Date(parseInt(year), parseInt(month), 0);
    const daysInMonth = monthEnd.getDate();
    
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(parseInt(year), parseInt(month) - 1, day);
      const dateString = getDateString(date);
      const dayStats = dailyStats[dateString] || {
        gamesPlayed: 0,
        highScore: 0,
        totalScore: 0,
        wordsFound: 0,
        playTime: 0
      };
      
      dailyBreakdown.push({
        date: dateString,
        dayOfMonth: day,
        dayOfWeek: date.toLocaleDateString('en-US', { weekday: 'short' }),
        ...dayStats,
        playTimeFormatted: formatTime(dayStats.playTime)
      });
    }

    // Get session history for this month
    const sessionHistory = user.sessionHistory || [];
    const sessionsThisMonth = sessionHistory.filter(session => {
      if (!session.startTime) return false;
      const sessionMonth = getMonthString(new Date(session.startTime));
      return sessionMonth === targetMonth;
    });

    // Calculate session statistics
    const totalSessions = sessionsThisMonth.length;
    const averageSessionTime = totalSessions > 0 ? 
      Math.round(monthStats.playTime / totalSessions) : 0;

    // Calculate additional metrics
    const averageScore = monthStats.gamesPlayed > 0 ? 
      Math.round(monthStats.totalScore / monthStats.gamesPlayed) : 0;

    // Calculate weekly breakdown
    const weeklyBreakdown = [];
    const weeksInMonth = Math.ceil(daysInMonth / 7);
    
    for (let week = 0; week < weeksInMonth; week++) {
      const weekStart = new Date(monthStart);
      weekStart.setDate(weekStart.getDate() + (week * 7));
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      
      // Don't go beyond the month
      if (weekEnd > monthEnd) {
        weekEnd.setTime(monthEnd.getTime());
      }
      
      let weekStats = {
        gamesPlayed: 0,
        highScore: 0,
        totalScore: 0,
        wordsFound: 0,
        playTime: 0
      };
      
      // Aggregate daily stats for this week
      for (let day = weekStart.getDate(); day <= weekEnd.getDate(); day++) {
        const date = new Date(parseInt(year), parseInt(month) - 1, day);
        const dateString = getDateString(date);
        const dayStats = dailyStats[dateString];
        
        if (dayStats) {
          weekStats.gamesPlayed += dayStats.gamesPlayed || 0;
          weekStats.highScore = Math.max(weekStats.highScore, dayStats.highScore || 0);
          weekStats.totalScore += dayStats.totalScore || 0;
          weekStats.wordsFound += dayStats.wordsFound || 0;
          weekStats.playTime += dayStats.playTime || 0;
        }
      }
      
      weeklyBreakdown.push({
        week: week + 1,
        startDate: getDateString(weekStart),
        endDate: getDateString(weekEnd),
        ...weekStats,
        playTimeFormatted: formatTime(weekStats.playTime)
      });
    }

    const response = {
      success: true,
      month: targetMonth,
      stats: {
        gamesPlayed: monthStats.gamesPlayed,
        highScore: monthStats.highScore,
        totalScore: monthStats.totalScore,
        averageScore,
        wordsFound: monthStats.wordsFound,
        playTime: monthStats.playTime,
        playTimeFormatted: formatTime(monthStats.playTime),
        totalSessions,
        averageSessionTime,
        averageSessionTimeFormatted: formatTime(averageSessionTime)
      },
      dailyBreakdown,
      weeklyBreakdown,
      sessions: sessionsThisMonth.map(session => ({
        date: getDateString(new Date(session.startTime)),
        startTime: session.startTime,
        endTime: session.endTime,
        duration: session.duration,
        durationFormatted: formatTime(session.duration || 0),
        score: session.score || 0,
        level: session.level || 1,
        wordsFound: session.wordsFound || 0
      }))
    };

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response),
    };

  } catch (error) {
    console.error('Error getting user monthly stats:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'Internal server error',
        error: error.message 
      }),
    };
  }
};
