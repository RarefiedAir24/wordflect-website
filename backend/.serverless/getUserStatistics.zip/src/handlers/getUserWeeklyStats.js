const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoDB = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-2' });
const docClient = DynamoDBDocumentClient.from(dynamoDB);

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const allowedOrigins = [
    'https://wordflect.com',
    'https://www.wordflect.com',
    'https://wordflect.app',
    'https://www.wordflect.app',
    'http://localhost:3000',
    'http://localhost:3001'
  ];

  return {
    'Access-Control-Allow-Origin': allowedOrigins.includes(origin) ? origin : '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };
}

// Helper function to get week strings
function getWeekString(date) {
  const year = date.getFullYear();
  const week = getWeekNumber(date);
  return `${year}-W${week.toString().padStart(2, '0')}`;
}

function getWeekNumber(date) {
  const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
  const pastDaysOfYear = (date - firstDayOfYear) / 86400000;
  return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
}

function getDateString(date) {
  return date.toISOString().split('T')[0];
}

function formatTime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  if (hours > 0) {
    return `${hours}h ${minutes}m ${secs}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${secs}s`;
  } else {
    return `${secs}s`;
  }
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  
  try {
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Verify and decode the JWT token
    const jwt = require('jsonwebtoken');
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token' }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    // Parse query parameters
    const queryParams = event.queryStringParameters || {};
    const requestedWeek = queryParams.week;
    
    let targetWeek;
    if (requestedWeek) {
      // Validate week format (YYYY-WW)
      if (!/^\d{4}-W\d{2}$/.test(requestedWeek)) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ message: 'Invalid week format. Use YYYY-WW' }),
        };
      }
      targetWeek = requestedWeek;
    } else {
      targetWeek = getWeekString(new Date());
    }

    // Get user data
    const { Item: user } = await docClient.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId }
    }));

    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    // Get weekly stats for the requested week
    const weeklyStats = user.weeklyStats || {};
    const weekStats = weeklyStats[targetWeek] || {
      gamesPlayed: 0,
      highScore: 0,
      totalScore: 0,
      wordsFound: 0,
      playTime: 0
    };

    // Calculate daily breakdown for this week
    const dailyStats = user.dailyStats || {};
    const dailyBreakdown = [];
    
    // Get the start and end dates for this week
    const [year, weekNum] = targetWeek.split('-W');
    const weekStart = getWeekStartDate(parseInt(year), parseInt(weekNum));
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(weekStart);
      date.setDate(date.getDate() + i);
      const dateString = getDateString(date);
      const dayStats = dailyStats[dateString] || {
        gamesPlayed: 0,
        highScore: 0,
        totalScore: 0,
        wordsFound: 0,
        playTime: 0
      };
      
      dailyBreakdown.push({
        date: dateString,
        dayOfWeek: date.toLocaleDateString('en-US', { weekday: 'short' }),
        ...dayStats,
        playTimeFormatted: formatTime(dayStats.playTime)
      });
    }

    // Get session history for this week
    const sessionHistory = user.sessionHistory || [];
    const sessionsThisWeek = sessionHistory.filter(session => {
      if (!session.startTime) return false;
      const sessionWeek = getWeekString(new Date(session.startTime));
      return sessionWeek === targetWeek;
    });

    // Calculate session statistics
    const totalSessions = sessionsThisWeek.length;
    const averageSessionTime = totalSessions > 0 ? 
      Math.round(weekStats.playTime / totalSessions) : 0;

    // Calculate additional metrics
    const averageScore = weekStats.gamesPlayed > 0 ? 
      Math.round(weekStats.totalScore / weekStats.gamesPlayed) : 0;

    const response = {
      success: true,
      week: targetWeek,
      stats: {
        gamesPlayed: weekStats.gamesPlayed,
        highScore: weekStats.highScore,
        totalScore: weekStats.totalScore,
        averageScore,
        wordsFound: weekStats.wordsFound,
        playTime: weekStats.playTime,
        playTimeFormatted: formatTime(weekStats.playTime),
        totalSessions,
        averageSessionTime,
        averageSessionTimeFormatted: formatTime(averageSessionTime)
      },
      dailyBreakdown,
      sessions: sessionsThisWeek.map(session => ({
        date: getDateString(new Date(session.startTime)),
        startTime: session.startTime,
        endTime: session.endTime,
        duration: session.duration,
        durationFormatted: formatTime(session.duration || 0),
        score: session.score || 0,
        level: session.level || 1,
        wordsFound: session.wordsFound || 0
      }))
    };

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response),
    };

  } catch (error) {
    console.error('Error getting user weekly stats:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'Internal server error',
        error: error.message 
      }),
    };
  }
};

function getWeekStartDate(year, week) {
  const jan1 = new Date(year, 0, 1);
  const daysToFirstMonday = (8 - jan1.getDay()) % 7;
  const firstMonday = new Date(jan1);
  firstMonday.setDate(jan1.getDate() + daysToFirstMonday);
  
  const weekStart = new Date(firstMonday);
  weekStart.setDate(firstMonday.getDate() + (week - 1) * 7);
  
  return weekStart;
}
