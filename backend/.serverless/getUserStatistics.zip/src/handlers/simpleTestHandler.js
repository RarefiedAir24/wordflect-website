const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  console.log('Simple test handler started');
  
  const corsHeaders = getCorsHeaders(event);
  
  return {
    statusCode: 200,
    headers: corsHeaders,
    body: JSON.stringify({ 
      message: 'Simple test handler working',
      timestamp: new Date().toISOString()
    }),
  };
}; 