const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand, GetCommand } = require('@aws-sdk/lib-dynamodb');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { v4: uuidv4 } = require('uuid');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);
const s3 = new S3Client({ region: 'us-east-2' });
const BUCKET = 'wordflect-profile-images';

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    console.log('Starting profile image update...'); // Force deployment
    console.log('Event body type:', typeof event.body);
    console.log('Event body length:', event.body ? event.body.length : 'no body');
    console.log('Environment variables:', {
      USERS_TABLE: process.env.USERS_TABLE,
      STAGE: process.env.STAGE,
      AWS_REGION: process.env.AWS_REGION
    });
    console.log('All env vars:', Object.keys(process.env).filter(key => key.includes('TABLE')));
    
    let imageData;
    let imageType = 'image/jpeg';
    
    // Check if body is base64 encoded
    if (event.body && event.isBase64Encoded) {
      console.log('Body is base64 encoded, decoding...');
      imageData = Buffer.from(event.body, 'base64');
      console.log('Decoded image data length:', imageData.length);
    } else if (event.body) {
      // Try to parse as JSON first
      try {
        const jsonBody = JSON.parse(event.body);
        if (jsonBody.image && jsonBody.imageType) {
          console.log('Found image data in JSON body');
          imageData = Buffer.from(jsonBody.image, 'base64');
          imageType = jsonBody.imageType;
          console.log('Parsed image data length:', imageData.length);
        } else {
          throw new Error('No image data in JSON');
        }
      } catch (jsonError) {
        console.log('Not JSON, treating as raw binary data');
        imageData = Buffer.from(event.body, 'binary');
        console.log('Raw image data length:', imageData.length);
      }
    }
    
    if (!imageData || imageData.length === 0) {
      console.log('No valid image data found');
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'No image data provided.' }),
      };
    }
    
    // Verify it's a valid image by checking the first few bytes
    const header = imageData.slice(0, 4);
    console.log('Image header (hex):', header.toString('hex'));
    
    // Check for common image formats
    if (header[0] === 0xFF && header[1] === 0xD8 && header[2] === 0xFF) {
      console.log('Valid JPEG detected');
      imageType = 'image/jpeg';
    } else if (header[0] === 0x89 && header[1] === 0x50 && header[2] === 0x4E && header[3] === 0x47) {
      console.log('Valid PNG detected');
      imageType = 'image/png';
    } else {
      console.log('Unknown image format, assuming JPEG');
      imageType = 'image/jpeg';
    }
    
    const userId = event.requestContext.authorizer?.context?.userId || event.requestContext.authorizer?.principalId;
    console.log('User ID from authorizer:', userId);
    console.log('Full authorizer context:', JSON.stringify(event.requestContext.authorizer, null, 2));
    
    if (!userId) {
      console.log('No user ID found in authorizer context');
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Unauthorized' }),
      };
    }
    
    // Generate unique filename
    const fileExtension = imageType.split('/')[1] || 'jpg';
    const fileName = `profile-images/${userId}/profile.${fileExtension}`;
    console.log('Generated filename:', fileName);
    
    // Upload to S3
    const uploadCommand = new PutObjectCommand({
      Bucket: BUCKET,
      Key: fileName,
      Body: imageData,
      ContentType: imageType,
    });
    
    console.log('Uploading to S3...');
    await s3.send(uploadCommand);
    console.log('S3 upload successful');
    
    // Generate the public S3 URL
    const imageUrl = `https://${BUCKET}.s3.us-east-2.amazonaws.com/${fileName}`;
    console.log('Generated image URL:', imageUrl);
    
    // Update user profile in DynamoDB
    const tableName = process.env.USERS_TABLE || 'wordflect-backend-users-prod';
    console.log('Updating DynamoDB with table:', tableName);
    await dynamoDB.send(new UpdateCommand({
      TableName: tableName,
      Key: { id: userId },
      UpdateExpression: 'set profileImageKey = :key, profileImageUrl = :url',
      ExpressionAttributeValues: { 
        ':key': fileName,
        ':url': imageUrl 
      },
    }));
    console.log('DynamoDB update successful');
    
    // Test: Get the updated user data to verify the upload
    console.log('Testing: Getting updated user data...');
    const testResult = await dynamoDB.send(new GetCommand({
      TableName: tableName,
      Key: { id: userId },
    }));
    console.log('Updated user data:', JSON.stringify(testResult.Item, null, 2));
    
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ imageUrl }),
    };
  } catch (err) {
    console.error('Update profile image error:', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'Failed to update profile image.' }),
    };
  }
}; 