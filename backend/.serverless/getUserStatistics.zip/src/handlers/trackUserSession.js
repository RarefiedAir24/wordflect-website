const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoDB = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-2' });
const docClient = DynamoDBDocumentClient.from(dynamoDB);

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const allowedOrigins = [
    'https://wordflect.com',
    'https://www.wordflect.com',
    'https://wordflect.app',
    'https://www.wordflect.app',
    'http://localhost:3000',
    'http://localhost:3001'
  ];

  return {
    'Access-Control-Allow-Origin': allowedOrigins.includes(origin) ? origin : '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };
}

// Helper function to get date strings
function getTodayString() {
  return new Date().toISOString().split('T')[0];
}

function getWeekString(date = new Date()) {
  const year = date.getFullYear();
  const week = getWeekNumber(date);
  return `${year}-W${week.toString().padStart(2, '0')}`;
}

function getWeekNumber(date) {
  const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
  const pastDaysOfYear = (date - firstDayOfYear) / 86400000;
  return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
}

function getMonthString(date = new Date()) {
  return date.toISOString().substring(0, 7); // YYYY-MM
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  
  try {
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Verify and decode the JWT token
    const jwt = require('jsonwebtoken');
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token' }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    // Parse request body
    const { action, sessionId, score, level, wordsFound } = JSON.parse(event.body || '{}');
    
    if (!action || !['start', 'end'].includes(action)) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Action must be "start" or "end"' }),
      };
    }

    // Get user data
    const { Item: user } = await docClient.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId }
    }));

    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    const now = new Date();
    const nowISO = now.toISOString();
    const today = getTodayString();
    const thisWeek = getWeekString(now);
    const thisMonth = getMonthString(now);

    if (action === 'start') {
      // Start a new session
      const newSessionId = sessionId || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const sessionData = {
        sessionId: newSessionId,
        startTime: nowISO,
        endTime: null,
        duration: 0,
        score: 0,
        level: 1,
        wordsFound: 0
      };

      // Update user with new session
      await docClient.send(new UpdateCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id: userId },
        UpdateExpression: 'SET currentSession = :session, currentSessionId = :sessionId',
        ExpressionAttributeValues: {
          ':session': sessionData,
          ':sessionId': newSessionId
        }
      }));

      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          success: true,
          message: 'Session started',
          sessionId: newSessionId,
          startTime: nowISO
        }),
      };

    } else if (action === 'end') {
      // End current session
      if (!user.currentSession || !user.currentSessionId) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ message: 'No active session to end' }),
        };
      }

      const sessionStartTime = new Date(user.currentSession.startTime);
      const sessionDuration = Math.floor((now.getTime() - sessionStartTime.getTime()) / 1000); // in seconds
      
      const completedSession = {
        ...user.currentSession,
        endTime: nowISO,
        duration: sessionDuration,
        score: score || 0,
        level: level || 1,
        wordsFound: wordsFound || 0
      };

      // Update session history
      const sessionHistory = user.sessionHistory || [];
      sessionHistory.push(completedSession);

      // Update daily stats
      const dailyStats = user.dailyStats || {};
      const todayStats = dailyStats[today] || {
        gamesPlayed: 0,
        highScore: 0,
        totalScore: 0,
        wordsFound: 0,
        playTime: 0
      };

      todayStats.playTime += sessionDuration;
      if (score && score > todayStats.highScore) {
        todayStats.highScore = score;
      }
      if (score) {
        todayStats.totalScore += score;
      }
      if (wordsFound) {
        todayStats.wordsFound += wordsFound;
      }

      dailyStats[today] = todayStats;

      // Update weekly stats
      const weeklyStats = user.weeklyStats || {};
      const thisWeekStats = weeklyStats[thisWeek] || {
        gamesPlayed: 0,
        highScore: 0,
        totalScore: 0,
        wordsFound: 0,
        playTime: 0
      };

      thisWeekStats.playTime += sessionDuration;
      if (score && score > thisWeekStats.highScore) {
        thisWeekStats.highScore = score;
      }
      if (score) {
        thisWeekStats.totalScore += score;
      }
      if (wordsFound) {
        thisWeekStats.wordsFound += wordsFound;
      }

      weeklyStats[thisWeek] = thisWeekStats;

      // Update monthly stats
      const monthlyStats = user.monthlyStats || {};
      const thisMonthStats = monthlyStats[thisMonth] || {
        gamesPlayed: 0,
        highScore: 0,
        totalScore: 0,
        wordsFound: 0,
        playTime: 0
      };

      thisMonthStats.playTime += sessionDuration;
      if (score && score > thisMonthStats.highScore) {
        thisMonthStats.highScore = score;
      }
      if (score) {
        thisMonthStats.totalScore += score;
      }
      if (wordsFound) {
        thisMonthStats.wordsFound += wordsFound;
      }

      monthlyStats[thisMonth] = thisMonthStats;

      // Update total play time
      const totalPlayTime = (user.totalPlayTime || 0) + sessionDuration;

      // Update daily play time
      const dailyPlayTime = user.dailyPlayTime || {};
      dailyPlayTime[today] = (dailyPlayTime[today] || 0) + sessionDuration;

      // Calculate longest session
      const longestSession = Math.max(user.longestSession || 0, sessionDuration);

      // Update user with completed session and stats
      await docClient.send(new UpdateCommand({
        TableName: process.env.USERS_TABLE,
        Key: { id: userId },
        UpdateExpression: 'SET sessionHistory = :sh, dailyStats = :ds, weeklyStats = :ws, monthlyStats = :ms, totalPlayTime = :tpt, dailyPlayTime = :dpt, longestSession = :ls, currentSession = :null, currentSessionId = :null',
        ExpressionAttributeValues: {
          ':sh': sessionHistory,
          ':ds': dailyStats,
          ':ws': weeklyStats,
          ':ms': monthlyStats,
          ':tpt': totalPlayTime,
          ':dpt': dailyPlayTime,
          ':ls': longestSession,
          ':null': null
        }
      }));

      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          success: true,
          message: 'Session ended',
          sessionId: user.currentSessionId,
          duration: sessionDuration,
          durationFormatted: formatTime(sessionDuration),
          score: score || 0,
          level: level || 1,
          wordsFound: wordsFound || 0
        }),
      };
    }

  } catch (error) {
    console.error('Error tracking user session:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'Internal server error',
        error: error.message 
      }),
    };
  }
};

function formatTime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  if (hours > 0) {
    return `${hours}h ${minutes}m ${secs}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${secs}s`;
  } else {
    return `${secs}s`;
  }
}
