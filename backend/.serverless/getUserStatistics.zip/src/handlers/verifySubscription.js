const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');
const fetch = require('node-fetch');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const APPLE_VALIDATION_URL = 'https://buy.itunes.apple.com/verifyReceipt';
const APPLE_SANDBOX_VALIDATION_URL = 'https://sandbox.itunes.apple.com/verifyReceipt';

// Subscription product mapping
const subscriptionProducts = {
  'wordflectbasic': {
    name: 'Wordflect Basic',
    tierId: 'wordflect-basic',
    duration: 30, // days
    monthlyGems: 0
  },
  'wordflectpremium': {
    name: 'Wordflect Premium',
    tierId: 'wordflect-premium',
    duration: 30,
    monthlyGems: 300
  },
  'wordflectpro': {
    name: 'Wordflect Pro',
    tierId: 'wordflect-pro',
    duration: 30,
    monthlyGems: 600
  }
};

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

async function validateReceipt(receipt, isSandbox) {
  const url = isSandbox ? APPLE_SANDBOX_VALIDATION_URL : APPLE_VALIDATION_URL;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ 'receipt-data': receipt }),
  });

  if (!response.ok) {
    throw new Error(`Failed to validate receipt. Status: ${response.status}`);
  }

  const jsonResponse = await response.json();

  // If the receipt is from the sandbox, but we sent to production, Apple sends back a specific status code.
  // We should retry against the sandbox environment.
  if (jsonResponse.status === 21007 && !isSandbox) {
    return validateReceipt(receipt, true);
  }

  if (jsonResponse.status !== 0) {
    throw new Error(`Invalid receipt. Status: ${jsonResponse.status}`);
  }

  return jsonResponse;
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  
  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  try {
    // Get user ID from JWT token
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Authorization header required' })
      };
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id;

    // Parse request body
    const requestBody = JSON.parse(event.body || '{}');
    const { receipt, productId } = requestBody;

    if (!receipt || !productId) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Receipt and productId are required' })
      };
    }

    // Validate the receipt with Apple
    const validationResponse = await validateReceipt(receipt, false); // Assume production first

    // Check if the product ID matches what we expect
    const purchasedProductId = validationResponse.receipt.in_app[0].product_id;
    if (purchasedProductId !== productId) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Product ID mismatch' })
      };
    }

    // Get subscription details
    const subscriptionProduct = subscriptionProducts[productId];
    if (!subscriptionProduct) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Invalid subscription product' })
      };
    }

    // Get user from DynamoDB
    const userResult = await dynamoDB.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
    }));

    const user = userResult.Item;
    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'User not found' })
      };
    }

    // Calculate subscription end date
    const now = new Date();
    const subscriptionEndDate = new Date(now.getTime() + (subscriptionProduct.duration * 24 * 60 * 60 * 1000));

    // Update user with premium status
    const updateParams = {
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
      UpdateExpression: 'SET isPremium = :isPremium, premiumTier = :premiumTier, subscriptionEndDate = :subscriptionEndDate, updatedAt = :updatedAt',
      ExpressionAttributeValues: {
        ':isPremium': true,
        ':premiumTier': subscriptionProduct.tierId,
        ':subscriptionEndDate': subscriptionEndDate.toISOString(),
        ':updatedAt': now.toISOString()
      },
      ReturnValues: 'ALL_NEW'
    };

    // Add monthly gems if applicable
    if (subscriptionProduct.monthlyGems) {
      updateParams.UpdateExpression += ', gems = :gems';
      updateParams.ExpressionAttributeValues[':gems'] = (user.gems || 0) + subscriptionProduct.monthlyGems;
    }

    const result = await dynamoDB.send(new UpdateCommand(updateParams));

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        message: 'Subscription activated successfully',
        tier: subscriptionProduct.name,
        subscriptionEndDate: subscriptionEndDate.toISOString(),
        user: result.Attributes
      })
    };

  } catch (error) {
    console.error('Error in verifySubscription:', error);
    
    if (error.name === 'JsonWebTokenError') {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Invalid token' })
      };
    }

    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
}; 