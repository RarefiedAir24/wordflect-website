const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);
const s3 = new S3Client({ region: 'us-east-2' });
const BUCKET = 'wordflect-profile-images';

// Add defaultFrames definition (copy from getUserProfile.js)
const defaultFrames = [
  { id: 'spiked-steel', name: 'Spiked Steel', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/spiked-steel.png', rarity: 'common', isDefault: true, price: 0 },
  { id: 'ice-crystal', name: 'Ice Crystal', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-crystal.png', rarity: 'common', isDefault: true, price: 0 },
  { id: 'heart-gold', name: 'Heart Gold', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/heart-gold.png', rarity: 'rare', unlockedAt: 5, price: 150 },
  { id: 'skull-bone', name: 'Skull Bone', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/skull-bone.png', rarity: 'rare', unlockedAt: 5, price: 200 },
  { id: 'blue-spikes', name: 'Blue Spikes', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-spikes.png', rarity: 'rare', unlockedAt: 5, price: 250 },
  { id: 'wood-diamonds', name: 'Wood Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wood-diamonds.png', rarity: 'rare', unlockedAt: 8, price: 300 },
  { id: 'fire-frame', name: 'Fire Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/fire-frame.png', rarity: 'rare', unlockedAt: 5, price: 200 },
  { id: 'halo', name: 'Halo', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/halo.png', rarity: 'epic', unlockedAt: 10, price: 400 },
  { id: 'blue-diamonds', name: 'Blue Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-diamonds.png', rarity: 'epic', unlockedAt: 15, price: 500 },
  { id: 'dark-bling', name: 'Dark Bling', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dark-bling.png', rarity: 'epic', unlockedAt: 18, price: 600 },
  { id: 'galaxy-frame', name: 'Galaxy Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/galaxy-frame.png', rarity: 'epic', unlockedAt: 12, price: 500 },
  { id: 'gradient-diamond', name: 'Gradient Diamond', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/gradient-diamond.png', rarity: 'legendary', unlockedAt: 20, price: 800 },
  { id: 'empress', name: 'Empress', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/empress.png', rarity: 'legendary', battleWinsRequired: 25, price: 1000 },
  { id: 'wings', name: 'Wings', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wings.png', rarity: 'legendary', battleWinsRequired: 10, price: 1200 },
  { id: 'dragon-frame', name: 'Dragon Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-frame.png', rarity: 'legendary', unlockedAt: 25, price: 1000 },
  { id: 'vine-frame', name: 'Vine Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/vine-frame.png', rarity: 'epic', unlockedAt: 15, price: 600 },
  { id: 'cyber-frame', name: 'Cyber Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/cyber-frame.png', rarity: 'epic', unlockedAt: 18, price: 700 },
  { id: 'ice-shard', name: 'Ice Shard', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-shard.png', rarity: 'epic', unlockedAt: 20, price: 800 },
];

const allowedOrigins = [
  'https://wordflect.com',
  'https://www.wordflect.com',
  'http://localhost:3000',
  'http://localhost:3001'
];

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  try {
    // Query all users from DynamoDB
    const params = {
      TableName: process.env.USERS_TABLE,
      ProjectionExpression: 'id, username, topScore, gamesPlayed, highestLevel, longestWord, profileImageUrl, profileImageKey, selectedFrame, selectedBackground, usernameColor, allFoundWords, firstPlaceFinishes, secondPlaceFinishes, thirdPlaceFinishes'
    };

    const result = await dynamoDB.send(new ScanCommand(params));
    
    // Get the start of the current month
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    startOfMonth.setHours(0, 0, 0, 0);
    
    // Calculate monthly scores and filter by recent activity
    const usersWithMonthlyScores = result.Items
      .map(user => {
        // Calculate monthly score from allFoundWords
        const allFoundWords = user.allFoundWords || [];
        const monthlyWords = allFoundWords.filter(wordEntry => {
          const wordDate = new Date(wordEntry.date);
          return wordDate >= startOfMonth;
        });
        
        // Calculate monthly score (sum of word lengths found this month)
        const monthlyScore = monthlyWords.reduce((total, wordEntry) => {
          return total + (wordEntry.word ? wordEntry.word.length : 0);
        }, 0);
        
        return {
          ...user,
          monthlyScore
        };
      })
      .filter(user => {
        // Must have played in the current month and have a monthly score > 0
        return user.monthlyScore > 0;
      })
      .sort((a, b) => b.monthlyScore - a.monthlyScore)
      .slice(0, 100); // Limit to top 100 users

    // Format the response with presigned URLs
    const leaderboard = await Promise.all(usersWithMonthlyScores.map(async (user, index) => {
      const rank = index + 1;
      
      let profileImageUrl = null;
      if (user.profileImageUrl && user.profileImageUrl.startsWith('http')) {
        // Use the public URL directly
        profileImageUrl = user.profileImageUrl;
      } else if (user.profileImageKey) {
        // Generate a presigned URL for private S3 objects
        const command = new GetObjectCommand({ Bucket: BUCKET, Key: user.profileImageKey });
        profileImageUrl = await getSignedUrl(s3, command, { expiresIn: 3600 });
      }
      // Find the full selectedFrame object
      let selectedFrame = null;
      if (user.selectedFrame) {
        if (typeof user.selectedFrame === 'string') {
          selectedFrame = defaultFrames.find(f => f.id === user.selectedFrame) || null;
        } else if (typeof user.selectedFrame === 'object') {
          selectedFrame = {
            ...user.selectedFrame,
            id: user.selectedFrame.id || user.selectedFrame.name.toLowerCase().replace(/\s+/g, '-'),
            isUnlocked: true
          };
        }
      }
      return {
        rank: rank,
        userId: user.id,
        username: user.username,
        topScore: user.monthlyScore, // Show monthly score instead of lifetime topScore
        gamesPlayed: user.gamesPlayed || 0,
        highestLevel: user.highestLevel || 1,
        longestWord: user.longestWord || '',
        profileImageUrl: profileImageUrl || null,
        selectedFrame,
        selectedBackground: user.selectedBackground || null,
        usernameColor: user.usernameColor || null
      };
    }));

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        leaderboard,
        totalUsers: result.Count
      })
    };

  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'Error fetching leaderboard data'
      })
    };
  }
}; 