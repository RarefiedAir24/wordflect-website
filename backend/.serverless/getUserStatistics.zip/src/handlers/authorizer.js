const jwt = require('jsonwebtoken');

const generatePolicy = (principalId, effect, resource, context = {}) => {
  return {
    principalId,
    policyDocument: {
      Version: '2012-10-17',
      Statement: [
        {
          Action: 'execute-api:Invoke',
          Effect: effect,
          Resource: resource,
        },
      ],
    },
    context,
  };
};

module.exports.handler = async (event) => {
  const token = event.authorizationToken || (event.headers && (event.headers.Authorization || event.headers.authorization));
  if (!token) {
    return generatePolicy('user', 'Deny', event.methodArn);
  }

  const jwtToken = token.replace(/^Bearer /, '');
  try {
    const decoded = jwt.verify(jwtToken, process.env.JWT_SECRET);

    // This is the standard and secure way to create a policy for a lambda authorizer.
    // It allows the authenticated user to access any method on this API.
    const resource = event.methodArn.split('/').slice(0, 2).join('/') + '/*';

    return generatePolicy(decoded.id || 'user', 'Allow', resource, {
      userId: decoded.id,
      username: decoded.username,
      email: decoded.email
    });
  } catch (err) {
    console.error('Authorization error:', err);
    return generatePolicy('user', 'Deny', event.methodArn);
  }
}; 