const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const fetch = require('node-fetch');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin || '*';
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

// Google OAuth - Disabled for iOS-only app
// async function verifyGoogleToken(accessToken) {
//   try {
//     const response = await fetch(`https://www.googleapis.com/oauth2/v2/userinfo?access_token=${accessToken}`);
//     if (!response.ok) {
//       throw new Error('Invalid Google token');
//     }
//     return await response.json();
//   } catch (error) {
//     console.error('Google token verification error:', error);
//     throw new Error('Failed to verify Google token');
//   }
// }

// Verify Apple token (simplified - in production you'd verify the JWT signature)
async function verifyAppleToken(idToken) {
  try {
    // In production, you should verify the JWT signature with Apple's public keys
    // For now, we'll decode the token and trust the userInfo passed from frontend
    const payload = JSON.parse(Buffer.from(idToken.split('.')[1], 'base64').toString());
    return {
      sub: payload.sub,
      email: payload.email,
      email_verified: payload.email_verified,
    };
  } catch (error) {
    console.error('Apple token verification error:', error);
    throw new Error('Failed to verify Apple token');
  }
}

// Check if user exists
async function checkUserExists(provider, userInfo) {
  const { email, sub: providerUserId } = userInfo;
  
  // Check if user exists by email
  const emailScanResult = await dynamoDB.send(new ScanCommand({
    TableName: process.env.USERS_TABLE,
    FilterExpression: 'email = :email',
    ExpressionAttributeValues: { ':email': email }
  }));

  if (emailScanResult.Items && emailScanResult.Items.length > 0) {
    // User exists, return user info for sign-in
    const user = emailScanResult.Items[0];
    console.log('Found existing user by email:', user.id);
    return {
      exists: true,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        oauthProviders: user.oauthProviders || {}
      }
    };
  }

  // Check if user exists by OAuth provider ID
  const oauthScanResult = await dynamoDB.send(new ScanCommand({
    TableName: process.env.USERS_TABLE,
    FilterExpression: 'oauthProviders.#provider.providerUserId = :providerUserId',
    ExpressionAttributeNames: { '#provider': provider },
    ExpressionAttributeValues: { ':providerUserId': providerUserId }
  }));

  if (oauthScanResult.Items && oauthScanResult.Items.length > 0) {
    // User exists by OAuth provider, return user info for sign-in
    const user = oauthScanResult.Items[0];
    console.log('Found existing user by OAuth provider:', user.id);
    return {
      exists: true,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        oauthProviders: user.oauthProviders || {}
      }
    };
  }

  // User doesn't exist, return OAuth info for signup
  console.log('User does not exist, returning OAuth info for signup');
  return {
    exists: false,
    oauthInfo: {
      provider,
      email,
      providerUserId,
      userInfo
    }
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  console.log('OAuth check handler started');
  console.log('Event:', JSON.stringify(event, null, 2));

  // Handle OPTIONS request for CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: '',
    };
  }

  try {
    const { provider, accessToken, idToken, userInfo } = JSON.parse(event.body);
    
    if (!provider || !userInfo) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Provider and userInfo are required' }),
      };
    }

    let verifiedUserInfo;

    // Verify the OAuth token (Apple only for iOS)
    if (provider === 'apple') {
      if (!idToken) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ message: 'Apple ID token is required' }),
        };
      }
      verifiedUserInfo = await verifyAppleToken(idToken);
    } else {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Only Apple Sign-In is supported' }),
      };
    }

    // Check if user exists
    const result = await checkUserExists(provider, verifiedUserInfo);

    console.log('OAuth check result:', result);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(result),
    };

  } catch (error) {
    console.error('Error in OAuth check handler:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'OAuth check failed',
        error: error.message 
      }),
    };
  }
};
