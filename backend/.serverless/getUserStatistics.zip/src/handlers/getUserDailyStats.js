const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoDB = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-2' });
const docClient = DynamoDBDocumentClient.from(dynamoDB);

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const allowedOrigins = [
    'https://wordflect.com',
    'https://www.wordflect.com',
    'https://wordflect.app',
    'https://www.wordflect.app',
    'http://localhost:3000',
    'http://localhost:3001'
  ];

  return {
    'Access-Control-Allow-Origin': allowedOrigins.includes(origin) ? origin : '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };
}

// Helper function to get date strings
function getDateString(date) {
  return date.toISOString().split('T')[0];
}

function formatTime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  if (hours > 0) {
    return `${hours}h ${minutes}m ${secs}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${secs}s`;
  } else {
    return `${secs}s`;
  }
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  
  try {
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Verify and decode the JWT token
    const jwt = require('jsonwebtoken');
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token' }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    // Parse query parameters
    const queryParams = event.queryStringParameters || {};
    const requestedDate = queryParams.date;
    
    let targetDate;
    if (requestedDate) {
      // Validate date format (YYYY-MM-DD)
      if (!/^\d{4}-\d{2}-\d{2}$/.test(requestedDate)) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ message: 'Invalid date format. Use YYYY-MM-DD' }),
        };
      }
      targetDate = new Date(requestedDate + 'T00:00:00.000Z');
    } else {
      targetDate = new Date();
    }

    const dateString = getDateString(targetDate);

    // Get user data
    const { Item: user } = await docClient.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId }
    }));

    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    // Get daily stats for the requested date
    const dailyStats = user.dailyStats || {};
    const dayStats = dailyStats[dateString] || {
      gamesPlayed: 0,
      highScore: 0,
      totalScore: 0,
      wordsFound: 0,
      playTime: 0,
      averageScore: 0,
      longestWord: '',
      levelReached: 1
    };

    // Get words found on this specific date
    const allFoundWords = user.allFoundWords || [];
    const wordsFoundToday = allFoundWords.filter(wordEntry => {
      if (!wordEntry.date) return false;
      const wordDate = new Date(wordEntry.date).toISOString().split('T')[0];
      return wordDate === dateString;
    });

    // Calculate additional metrics
    const averageScore = dayStats.gamesPlayed > 0 ? 
      Math.round(dayStats.totalScore / dayStats.gamesPlayed) : 0;

    const longestWordToday = wordsFoundToday.length > 0 ? 
      wordsFoundToday.reduce((longest, entry) => 
        entry.word.length > longest.length ? entry.word : longest, ''
      ) : '';

    // Get session history for this date
    const sessionHistory = user.sessionHistory || [];
    const sessionsToday = sessionHistory.filter(session => {
      if (!session.startTime) return false;
      const sessionDate = new Date(session.startTime).toISOString().split('T')[0];
      return sessionDate === dateString;
    });

    // Calculate session statistics
    const totalSessions = sessionsToday.length;
    const averageSessionTime = totalSessions > 0 ? 
      Math.round(dayStats.playTime / totalSessions) : 0;

    const response = {
      success: true,
      date: dateString,
      stats: {
        gamesPlayed: dayStats.gamesPlayed,
        highScore: dayStats.highScore,
        totalScore: dayStats.totalScore,
        averageScore,
        wordsFound: dayStats.wordsFound,
        longestWord: longestWordToday,
        playTime: dayStats.playTime,
        playTimeFormatted: formatTime(dayStats.playTime),
        levelReached: dayStats.levelReached || 1,
        totalSessions,
        averageSessionTime,
        averageSessionTimeFormatted: formatTime(averageSessionTime)
      },
      wordsFound: wordsFoundToday.map(entry => ({
        word: entry.word,
        length: entry.word.length,
        time: entry.time || null
      })),
      sessions: sessionsToday.map(session => ({
        startTime: session.startTime,
        endTime: session.endTime,
        duration: session.duration,
        durationFormatted: formatTime(session.duration || 0),
        score: session.score || 0,
        level: session.level || 1
      }))
    };

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response),
    };

  } catch (error) {
    console.error('Error getting user daily stats:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'Internal server error',
        error: error.message 
      }),
    };
  }
};
