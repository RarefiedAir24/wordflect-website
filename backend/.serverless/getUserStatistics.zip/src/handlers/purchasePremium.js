const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const jwt = require('jsonwebtoken');

const client = new DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

function getCorsHeaders(event) {
  const allowedOrigins = [
    'https://wordflect.com',
    'https://www.wordflect.com',
    'http://localhost:3000',
    'http://localhost:3001'
  ];
  const origin = event.headers?.origin || event.headers?.Origin;
  const corsOrigin = allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
  return {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  };
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  
  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  try {
    // Get user ID from JWT token
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Authorization header required' })
      };
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id;

    // Parse request body
    const requestBody = JSON.parse(event.body || '{}');
    const { tierId, paymentMethod, receipt } = requestBody;

    // Validate required fields
    if (!tierId) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Tier ID is required' })
      };
    }

    // Get user from DynamoDB
    const userResult = await dynamoDB.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
    }));

    const user = userResult.Item;
    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'User not found' })
      };
    }

    // Define premium tiers
    const premiumTiers = {
      'wordflect-basic': {
        name: 'Wordflect Basic',
        price: 0.99,
        duration: 30, // days
        features: ['profile_backgrounds', 'username_colors', 'premium_frames', 'enhanced_statistics']
      },
      'wordflect-premium': {
        name: 'Wordflect Premium',
        price: 1.99,
        duration: 30,
        features: ['profile_backgrounds', 'username_colors', 'premium_frames', 'enhanced_statistics', 'extended_colors', 'monthly_gems', 'animated_backgrounds'],
        monthlyGems: 300
      },
      'wordflect-pro': {
        name: 'Wordflect Pro',
        price: 3.99,
        duration: 30,
        features: ['profile_backgrounds', 'username_colors', 'premium_frames', 'enhanced_statistics', 'extended_colors', 'monthly_gems', 'animated_backgrounds', 'legendary_frames', 'unlimited_customization'],
        monthlyGems: 600
      }
    };

    const selectedTier = premiumTiers[tierId];
    if (!selectedTier) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Invalid tier ID' })
      };
    }

    // TODO: Implement actual payment processing here
    // For now, we'll simulate a successful purchase
    
    // Calculate subscription end date
    const now = new Date();
    const subscriptionEndDate = new Date(now.getTime() + (selectedTier.duration * 24 * 60 * 60 * 1000));

    // Update user with premium status
    const updateParams = {
      TableName: process.env.USERS_TABLE,
      Key: { id: userId },
      UpdateExpression: 'SET isPremium = :isPremium, premiumTier = :premiumTier, subscriptionEndDate = :subscriptionEndDate, updatedAt = :updatedAt',
      ExpressionAttributeValues: {
        ':isPremium': true,
        ':premiumTier': tierId,
        ':subscriptionEndDate': subscriptionEndDate.toISOString(),
        ':updatedAt': now.toISOString()
      },
      ReturnValues: 'ALL_NEW'
    };

    // Add monthly gems if applicable
    if (selectedTier.monthlyGems) {
      updateParams.UpdateExpression += ', gems = :gems';
      updateParams.ExpressionAttributeValues[':gems'] = (user.gems || 0) + selectedTier.monthlyGems;
    }

    const result = await dynamoDB.send(new UpdateCommand(updateParams));

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        message: 'Premium subscription activated successfully',
        tier: selectedTier.name,
        subscriptionEndDate: subscriptionEndDate.toISOString(),
        user: result.Attributes
      })
    };

  } catch (error) {
    console.error('Error in purchasePremium:', error);
    
    if (error.name === 'JsonWebTokenError') {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Invalid token' })
      };
    }

    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
}; 