const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');

const dynamoDB = new DynamoDBClient({ region: process.env.AWS_REGION || 'us-east-2' });
const docClient = DynamoDBDocumentClient.from(dynamoDB);

function getCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const allowedOrigins = [
    'https://wordflect.com',
    'https://www.wordflect.com',
    'https://wordflect.app',
    'https://www.wordflect.app',
    'http://localhost:3000',
    'http://localhost:3001'
  ];

  return {
    'Access-Control-Allow-Origin': allowedOrigins.includes(origin) ? origin : '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };
}

// Helper function to get date strings
function getTodayString() {
  return new Date().toISOString().split('T')[0];
}

function getWeekString(date = new Date()) {
  const year = date.getFullYear();
  const week = getWeekNumber(date);
  return `${year}-W${week.toString().padStart(2, '0')}`;
}

function getWeekNumber(date) {
  const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
  const pastDaysOfYear = (date - firstDayOfYear) / 86400000;
  return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
}

function getMonthString(date = new Date()) {
  return date.toISOString().substring(0, 7); // YYYY-MM
}

// Calculate statistics from user data
function calculateStatistics(user) {
  const now = new Date();
  const today = getTodayString();
  const thisWeek = getWeekString(now);
  const thisMonth = getMonthString(now);
  
  // Basic stats
  const totalGamesPlayed = user.gamesPlayed || 0;
  const topScore = user.topScore || 0;
  const longestWord = user.longestWord || '';
  const highestLevel = user.highestLevel || 1;
  const totalWordsFound = user.allFoundWords?.length || 0;
  
  // Time tracking
  const totalPlayTime = user.totalPlayTime || 0; // in seconds
  const dailyPlayTime = user.dailyPlayTime || {};
  const sessionHistory = user.sessionHistory || [];
  
  // Daily stats
  const dailyStats = user.dailyStats || {};
  const todayStats = dailyStats[today] || {
    gamesPlayed: 0,
    highScore: 0,
    totalScore: 0,
    wordsFound: 0,
    playTime: 0
  };
  
  // Weekly stats
  const weeklyStats = user.weeklyStats || {};
  const thisWeekStats = weeklyStats[thisWeek] || {
    gamesPlayed: 0,
    highScore: 0,
    totalScore: 0,
    wordsFound: 0,
    playTime: 0
  };
  
  // Monthly stats
  const monthlyStats = user.monthlyStats || {};
  const thisMonthStats = monthlyStats[thisMonth] || {
    gamesPlayed: 0,
    highScore: 0,
    totalScore: 0,
    wordsFound: 0,
    playTime: 0
  };
  
  // Calculate averages
  const averageScore = totalGamesPlayed > 0 ? (user.totalScore || 0) / totalGamesPlayed : 0;
  const averageSessionTime = sessionHistory.length > 0 ? 
    sessionHistory.reduce((sum, session) => sum + (session.duration || 0), 0) / sessionHistory.length : 0;
  
  // Playing patterns
  const peakHours = user.peakHours || [];
  const longestSession = user.longestSession || 0;
  
  // Recent activity (last 7 days)
  const recentActivity = [];
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    const dayStats = dailyStats[dateStr] || {
      gamesPlayed: 0,
      highScore: 0,
      playTime: 0
    };
    recentActivity.push({
      date: dateStr,
      ...dayStats
    });
  }
  
  // Score progression (last 30 days)
  const scoreProgression = [];
  for (let i = 29; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    const dayStats = dailyStats[dateStr];
    if (dayStats && dayStats.highScore > 0) {
      scoreProgression.push({
        date: dateStr,
        highScore: dayStats.highScore
      });
    }
  }
  
  return {
    // Basic statistics
    totalGamesPlayed,
    topScore,
    longestWord,
    highestLevel,
    totalWordsFound,
    averageScore: Math.round(averageScore),
    
    // Time tracking
    totalPlayTime,
    totalPlayTimeFormatted: formatTime(totalPlayTime),
    averageSessionTime: Math.round(averageSessionTime),
    averageSessionTimeFormatted: formatTime(averageSessionTime),
    longestSession,
    longestSessionFormatted: formatTime(longestSession),
    
    // Daily stats
    todayStats,
    
    // Weekly stats
    thisWeekStats,
    
    // Monthly stats
    thisMonthStats,
    
    // Playing patterns
    peakHours,
    recentActivity,
    scoreProgression,
    
    // Login streaks
    currentLoginStreak: user.currentLoginStreak || 0,
    longestLoginStreak: user.longestLoginStreak || 0,
    
    // Battle stats
    battleWins: user.battleWins || 0,
    battleLosses: user.battleLosses || 0,
    battleWinRate: user.battleWins + user.battleLosses > 0 ? 
      Math.round((user.battleWins / (user.battleWins + user.battleLosses)) * 100) : 0,
    
    // Leaderboard placements
    firstPlaceFinishes: user.firstPlaceFinishes || 0,
    secondPlaceFinishes: user.secondPlaceFinishes || 0,
    thirdPlaceFinishes: user.thirdPlaceFinishes || 0
  };
}

function formatTime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  if (hours > 0) {
    return `${hours}h ${minutes}m ${secs}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${secs}s`;
  } else {
    return `${secs}s`;
  }
}

exports.handler = async (event) => {
  const corsHeaders = getCorsHeaders(event);
  
  try {
    // Extract token from Authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Authorization header required' }),
      };
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Verify and decode the JWT token
    const jwt = require('jsonwebtoken');
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'Invalid token' }),
      };
    }

    const userId = decoded.id;
    if (!userId) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not authorized' }),
      };
    }

    // Get user data
    const { Item: user } = await docClient.send(new GetCommand({
      TableName: process.env.USERS_TABLE,
      Key: { id: userId }
    }));

    if (!user) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    // Calculate comprehensive statistics
    const statistics = calculateStatistics(user);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        statistics
      }),
    };

  } catch (error) {
    console.error('Error getting user statistics:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ 
        message: 'Internal server error',
        error: error.message 
      }),
    };
  }
};
