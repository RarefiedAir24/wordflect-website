const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function restoreProfileBackgrounds() {
  try {
    console.log('Restoring profile backgrounds to production database...');
    
    const backgrounds = [
      {
        id: 'aurora',
        name: 'Aurora Gradient',
        type: 'gradient',
        colors: ['#0f2027', '#2c5364', '#00c9a7', '#8f94fb'],
        animation: 'pulse',
        price: 0,
        isDefault: true
      },
      {
        id: 'blue',
        name: 'Blue',
        type: 'color',
        color: '#1976d2',
        animation: 'none',
        price: 0,
        isDefault: true
      },
      {
        id: 'gold',
        name: 'Gold',
        type: 'color',
        color: '#FFD700',
        animation: 'none',
        price: 100
      },
      {
        id: 'sunset',
        name: 'Sunset',
        type: 'gradient',
        colors: ['#ff6b6b', '#feca57', '#ff9ff3', '#54a0ff'],
        animation: 'pulse',
        price: 200
      },
      {
        id: 'ocean',
        name: 'Ocean',
        type: 'gradient',
        colors: ['#667eea', '#764ba2', '#f093fb', '#f5576c'],
        animation: 'pulse',
        price: 250
      },
      {
        id: 'forest',
        name: 'Forest',
        type: 'gradient',
        colors: ['#134e5e', '#71b280', '#a8e6cf', '#dcedc1'],
        animation: 'pulse',
        price: 200
      },
      {
        id: 'purple',
        name: 'Purple',
        type: 'color',
        color: '#9c27b0',
        animation: 'none',
        price: 150
      },
      {
        id: 'emerald',
        name: 'Emerald',
        type: 'color',
        color: '#00b894',
        animation: 'none',
        price: 150
      },
      {
        id: 'coral',
        name: 'Coral',
        type: 'color',
        color: '#ff7675',
        animation: 'none',
        price: 150
      },
      {
        id: 'midnight',
        name: 'Midnight',
        type: 'gradient',
        colors: ['#2c3e50', '#34495e', '#8e44ad', '#9b59b6'],
        animation: 'glow',
        price: 300
      },
      {
        id: 'spring',
        name: 'Spring',
        type: 'gradient',
        colors: ['#a8edea', '#fed6e3', '#ffecd2', '#fcb69f'],
        animation: 'pulse',
        price: 250
      },
      {
        id: 'autumn',
        name: 'Autumn',
        type: 'gradient',
        colors: ['#ffecd2', '#fcb69f', '#ff9a9e', '#fecfef'],
        animation: 'pulse',
        price: 250
      },
      {
        id: 'silver',
        name: 'Silver',
        type: 'color',
        color: '#95a5a6',
        animation: 'none',
        price: 100
      },
      {
        id: 'rose',
        name: 'Rose',
        type: 'color',
        color: '#e91e63',
        animation: 'none',
        price: 150
      },
      {
        id: 'teal',
        name: 'Teal',
        type: 'color',
        color: '#009688',
        animation: 'none',
        price: 150
      },
      {
        id: 'indigo',
        name: 'Indigo',
        type: 'color',
        color: '#3f51b5',
        animation: 'none',
        price: 150
      },
      {
        id: 'orange',
        name: 'Orange',
        type: 'color',
        color: '#ff9800',
        animation: 'none',
        price: 150
      },
      {
        id: 'pink',
        name: 'Pink',
        type: 'color',
        color: '#e91e63',
        animation: 'none',
        price: 150
      },
      {
        id: 'lime',
        name: 'Lime',
        type: 'color',
        color: '#cddc39',
        animation: 'none',
        price: 150
      },
      {
        id: 'cosmic',
        name: 'Cosmic',
        type: 'gradient',
        colors: ['#667eea', '#764ba2', '#f093fb', '#f5576c'],
        animation: 'pulse',
        price: 300
      },
      {
        id: 'lavender',
        name: 'Lavender',
        type: 'gradient',
        colors: ['#e0c3fc', '#667eea', '#764ba2', '#f093fb'],
        animation: 'pulse',
        price: 250
      },
      {
        id: 'fire',
        name: 'Fire',
        type: 'gradient',
        colors: ['#ff6b6b', '#feca57', '#ff9ff3', '#54a0ff'],
        animation: 'pulse',
        price: 300
      },
      {
        id: 'neon',
        name: 'Neon',
        type: 'gradient',
        colors: ['#00d4ff', '#00ff88', '#ff00ff', '#ff8800'],
        animation: 'pulse',
        price: 350
      },
      {
        id: 'pastel',
        name: 'Pastel',
        type: 'gradient',
        colors: ['#ffb3ba', '#baffc9', '#bae1ff', '#ffffba'],
        animation: 'pulse',
        price: 200
      },
      {
        id: 'galaxy',
        name: 'Galaxy',
        type: 'gradient',
        colors: ['#0c0c0c', '#1a1a2e', '#16213e', '#0f3460'],
        animation: 'glow',
        price: 400
      }
    ];
    
    for (const background of backgrounds) {
      await dynamoDB.send(new PutCommand({
        TableName: 'wordflect-backend-backgrounds-prod',
        Item: background
      }));
      console.log(`✅ Restored background: ${background.name} (${background.type})`);
    }
    
    console.log('\n🎉 All profile backgrounds restored successfully!');
    console.log(`Total backgrounds restored: ${backgrounds.length}`);
    
  } catch (error) {
    console.error('Error restoring backgrounds:', error);
  }
}

restoreProfileBackgrounds();
