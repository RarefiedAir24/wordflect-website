#!/usr/bin/env node

// 🏗️ Immediate AWS Infrastructure Backup
// Run this script to backup all AWS infrastructure immediately

const { createInfrastructureBackup } = require('./backup-aws-infrastructure');

console.log('🚀 Starting immediate AWS infrastructure backup...\n');

createInfrastructureBackup()
  .then(() => {
    console.log('\n✅ Infrastructure backup completed successfully!');
    console.log('📁 Check the backups directory for the infrastructure backup file.');
  })
  .catch(error => {
    console.error('\n❌ Infrastructure backup failed:', error);
    process.exit(1);
  });
