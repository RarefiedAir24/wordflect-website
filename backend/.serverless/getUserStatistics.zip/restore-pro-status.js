const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function restoreProStatus() {
  try {
    console.log('Restoring Pro status and premium features...');
    
    // Update the user profile with Pro status
    const updateResult = await dynamoDB.send(new UpdateCommand({
      TableName: 'wordflect-backend-users-prod',
      Key: { id: 'd59de7c3-9c83-41c9-87bf-a73b87048ff3' },
      UpdateExpression: 'SET isPremium = :isPremium, premiumTier = :premiumTier, selectedBackground = :selectedBackground, usernameColor = :usernameColor',
      ExpressionAttributeValues: {
        ':isPremium': true,
        ':premiumTier': 'pro',
        ':selectedBackground': {
          id: 'aurora',
          name: 'Aurora Gradient',
          type: 'gradient',
          colors: ['#0f2027', '#2c5364', '#00c9a7', '#8f94fb'],
          animation: 'pulse'
        },
        ':usernameColor': '#ffffff'
      }
    }));
    
    console.log('✅ Pro status restored successfully!');
    console.log('Premium features unlocked:');
    console.log('- Profile backgrounds');
    console.log('- Custom username colors');
    console.log('- Premium frames');
    console.log('- All premium content');
    console.log('\nSelected background: Aurora Gradient');
    console.log('Username color: White');
    
  } catch (error) {
    console.error('Error restoring Pro status:', error);
  }
}

restoreProStatus();
