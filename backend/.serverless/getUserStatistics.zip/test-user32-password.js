const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function testUser32Password() {
  try {
    console.log('Testing testuser32 password...');
    
    // Get testuser32 from prod table
    const result = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-users-prod',
      FilterExpression: 'email = :email',
      ExpressionAttributeValues: {
        ':email': 'testuser32@gmail.com'
      }
    }));
    
    if (result.Items && result.Items.length > 0) {
      const user = result.Items[0];
      console.log('Full password hash:', user.password);
      
      // Test the password
      const testPassword = 'test';
      const isMatch = await bcrypt.compare(testPassword, user.password);
      console.log('Password verification test:', isMatch ? '✅ PASS' : '❌ FAIL');
      
      if (!isMatch) {
        console.log('Testing with different password variations...');
        const variations = ['Test', 'TEST', 'test123', 'password', 'Password'];
        for (const variation of variations) {
          const match = await bcrypt.compare(variation, user.password);
          console.log(`"${variation}": ${match ? '✅' : '❌'}`);
        }
      }
    } else {
      console.log('testuser32 not found in prod table');
    }
    
  } catch (error) {
    console.error('Error testing password:', error);
  }
}

testUser32Password(); 