const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const fs = require('fs');
const path = require('path');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

// Import infrastructure backup functions
const { createInfrastructureBackup } = require('./backup-aws-infrastructure');

// All critical production tables
const TABLES = {
  users: 'wordflect-backend-users-prod',
  missions: 'wordflect-backend-missions-prod',
  frames: 'wordflect-backend-frames-prod',
  backgrounds: 'wordflect-backend-backgrounds-prod',
  wordOfTheDay: 'wordflect-backend-word-of-the-day-prod',
  battles: 'wordflect-backend-battles-prod'
};

async function backupTable(tableName, fileName) {
  try {
    console.log(`📋 Backing up ${tableName}...`);
    const items = [];
    let lastEvaluatedKey = undefined;
    
    do {
      const params = {
        TableName: tableName,
        ...(lastEvaluatedKey && { ExclusiveStartKey: lastEvaluatedKey })
      };
      
      const result = await dynamoDB.send(new ScanCommand(params));
      items.push(...result.Items);
      lastEvaluatedKey = result.LastEvaluatedKey;
      
      console.log(`  - Retrieved ${result.Items.length} items (${items.length} total so far)`);
    } while (lastEvaluatedKey);
    
    const backupDir = path.join(__dirname, 'backups', new Date().toISOString().split('T')[0]);
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    
    const filePath = path.join(backupDir, fileName);
    fs.writeFileSync(filePath, JSON.stringify(items, null, 2));
    
    console.log(`✅ ${tableName} backed up: ${items.length} items saved to ${filePath}`);
    return { success: true, count: items.length, filePath };
  } catch (error) {
    console.log(`❌ Failed to backup ${tableName}: ${error.message}`);
    return { success: false, error: error.message };
  }
}

async function createAutomatedBackup() {
  const timestamp = new Date().toISOString();
  console.log(`🚀 Starting automated production data backup...`);
  console.log(`📅 Backup timestamp: ${timestamp}`);
  console.log('');
  
  const results = {};
  const summary = {
    timestamp,
    totalItems: 0,
    successfulTables: 0,
    failedTables: 0,
    results: {}
  };
  
  for (const [key, tableName] of Object.entries(TABLES)) {
    const fileName = `${key}.json`;
    const result = await backupTable(tableName, fileName);
    results[key] = result;
    
    if (result.success) {
      summary.totalItems += result.count;
      summary.successfulTables++;
    } else {
      summary.failedTables++;
    }
    
    summary.results[key] = result;
  }
  
  // Save backup summary
  const backupDir = path.join(__dirname, 'backups', new Date().toISOString().split('T')[0]);
  const summaryPath = path.join(backupDir, 'backup-summary.json');
  fs.writeFileSync(summaryPath, JSON.stringify(summary, null, 2));
  
  console.log('');
  console.log('📊 BACKUP SUMMARY:');
  console.log('==================');
  for (const [key, result] of Object.entries(results)) {
    if (result.success) {
      console.log(`✅ ${TABLES[key]}: ${result.count} items`);
    } else {
      console.log(`❌ ${TABLES[key]}: ERROR - ${result.error}`);
    }
  }
  
  console.log('');
  console.log(`📁 Total items backed up: ${summary.totalItems}`);
  console.log(`📄 Summary saved to: ${summaryPath}`);
  
  // Create a "latest" symlink for easy access
  const latestBackupPath = path.join(__dirname, 'backups', 'latest');
  if (fs.existsSync(latestBackupPath)) {
    fs.unlinkSync(latestBackupPath);
  }
  fs.symlinkSync(backupDir, latestBackupPath);
  
  console.log(`🔗 Latest backup linked to: ${latestBackupPath}`);
  
  return summary;
}

// Function to clean up old backups (keep last 7 days)
async function cleanupOldBackups() {
  const backupsDir = path.join(__dirname, 'backups');
  if (!fs.existsSync(backupsDir)) return;
  
  const today = new Date();
  const cutoffDate = new Date(today.getTime() - (7 * 24 * 60 * 60 * 1000)); // 7 days ago
  
  const entries = fs.readdirSync(backupsDir, { withFileTypes: true });
  let cleanedCount = 0;
  
  for (const entry of entries) {
    if (entry.isDirectory() && entry.name !== 'latest') {
      const backupDate = new Date(entry.name);
      if (backupDate < cutoffDate) {
        const backupPath = path.join(backupsDir, entry.name);
        fs.rmSync(backupPath, { recursive: true, force: true });
        console.log(`🗑️ Cleaned up old backup: ${entry.name}`);
        cleanedCount++;
      }
    }
  }
  
  if (cleanedCount > 0) {
    console.log(`🧹 Cleaned up ${cleanedCount} old backup(s)`);
  }
}

// Main execution
async function main() {
  try {
    console.log('🔄 Starting comprehensive backup process...\n');
    
    // Step 1: Backup DynamoDB data
    console.log('📊 STEP 1: Backing up DynamoDB data...');
    await createAutomatedBackup();
    
    // Step 2: Backup AWS infrastructure (weekly)
    const today = new Date();
    const dayOfWeek = today.getDay(); // 0 = Sunday, 6 = Saturday
    const isWeeklyBackup = dayOfWeek === 0; // Sunday = weekly infrastructure backup
    
    if (isWeeklyBackup) {
      console.log('\n🏗️ STEP 2: Backing up AWS infrastructure (weekly)...');
      await createInfrastructureBackup();
    } else {
      console.log('\n⏭️ STEP 2: Skipping infrastructure backup (runs weekly on Sundays)');
    }
    
    // Step 3: Cleanup old backups
    console.log('\n🧹 STEP 3: Cleaning up old backups...');
    await cleanupOldBackups();
    
    console.log('\n🎉 Comprehensive backup completed successfully!');
  } catch (error) {
    console.error('❌ Automated backup failed:', error);
    process.exit(1);
  }
}

// Export for use in other scripts
module.exports = {
  createAutomatedBackup,
  cleanupOldBackups,
  backupTable
};

// Run if called directly
if (require.main === module) {
  main();
}
