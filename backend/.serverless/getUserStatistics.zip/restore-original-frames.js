const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function restoreOriginalFrames() {
  try {
    console.log('Restoring original frames to production database...');
    
    const originalFrames = [
      // Default frames (free)
      { id: 'spiked-steel', name: 'Spiked Steel', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/spiked-steel.png', rarity: 'common', price: 0, isDefault: true },
      { id: 'ice-crystal', name: 'Ice Crystal', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-crystal.png', rarity: 'common', price: 0, isDefault: true },
      
      // Level-based frames
      { id: 'heart-gold', name: 'Heart Gold', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/heart-gold.png', rarity: 'rare', unlockedAt: 5, price: 150 },
      { id: 'skull-bone', name: 'Skull Bone', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/skull-bone.png', rarity: 'rare', unlockedAt: 5, price: 200 },
      { id: 'blue-spikes', name: 'Blue Spikes', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-spikes.png', rarity: 'rare', unlockedAt: 5, price: 250 },
      { id: 'wood-diamonds', name: 'Wood Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wood-diamonds.png', rarity: 'rare', unlockedAt: 8, price: 300 },
      { id: 'fire-frame', name: 'Fire Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/fire-frame.png', rarity: 'rare', unlockedAt: 5, price: 200 },
      { id: 'halo', name: 'Halo', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/halo.png', rarity: 'epic', unlockedAt: 10, price: 400 },
      { id: 'blue-diamonds', name: 'Blue Diamonds', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/blue-diamonds.png', rarity: 'epic', unlockedAt: 15, price: 500 },
      { id: 'dark-bling', name: 'Dark Bling', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dark-bling.png', rarity: 'epic', unlockedAt: 18, price: 600 },
      { id: 'galaxy-frame', name: 'Galaxy Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/galaxy-frame.png', rarity: 'epic', unlockedAt: 12, price: 500 },
      { id: 'vine-frame', name: 'Vine Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/vine-frame.png', rarity: 'epic', unlockedAt: 15, price: 600 },
      { id: 'cyber-frame', name: 'Cyber Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/cyber-frame.png', rarity: 'epic', unlockedAt: 18, price: 700 },
      { id: 'ice-shard', name: 'Ice Shard', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/ice-shard.png', rarity: 'legendary', unlockedAt: 20, price: 800 },
      { id: 'gradient-diamond', name: 'Gradient Diamond', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/gradient-diamond.png', rarity: 'legendary', unlockedAt: 20, price: 800 },
      { id: 'dragon-frame', name: 'Dragon Frame', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/dragon-frame.png', rarity: 'legendary', unlockedAt: 25, price: 1000 },
      
      // Battle-based frames
      { id: 'wings', name: 'Wings', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/wings.png', rarity: 'legendary', battleWinsRequired: 10, price: 1200 },
      { id: 'empress', name: 'Empress', imageUrl: 'https://wordflect-avatar-frames.s3.us-east-2.amazonaws.com/empress.png', rarity: 'legendary', battleWinsRequired: 25, price: 1000 }
    ];
    
    for (const frame of originalFrames) {
      await dynamoDB.send(new PutCommand({
        TableName: 'wordflect-backend-frames-prod',
        Item: frame
      }));
      console.log(`✅ Restored frame: ${frame.name} (${frame.rarity})`);
    }
    
    console.log('\n🎉 All original frames restored successfully!');
    console.log(`Total frames restored: ${originalFrames.length}`);
    
  } catch (error) {
    console.error('Error restoring frames:', error);
  }
}

restoreOriginalFrames();
