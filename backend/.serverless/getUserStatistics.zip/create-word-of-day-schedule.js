const { EventBridgeClient, PutRuleCommand, PutTargetsCommand } = require('@aws-sdk/client-eventbridge');
const { LambdaClient, AddPermissionCommand } = require('@aws-sdk/client-lambda');

const eventBridge = new EventBridgeClient({ region: 'us-east-2' });
const lambda = new LambdaClient({ region: 'us-east-2' });

async function createWordOfDaySchedule() {
  try {
    console.log('Creating CloudWatch Events rule for daily Word of the Day updates...');
    
    const ruleName = 'wordflect-daily-word-of-day';
    const functionName = 'wordflect-backend-prod-setWordOfTheDay';
    const scheduleExpression = 'cron(0 0 * * ? *)'; // Daily at midnight UTC
    
    // Create the rule
    const putRuleCommand = new PutRuleCommand({
      Name: ruleName,
      ScheduleExpression: scheduleExpression,
      Description: 'Triggers Word of the Day update daily at midnight UTC',
      State: 'ENABLED'
    });
    
    const ruleResult = await eventBridge.send(putRuleCommand);
    console.log('✅ CloudWatch Events rule created:', ruleResult.RuleArn);
    
    // Add target to the rule
    const putTargetsCommand = new PutTargetsCommand({
      Rule: ruleName,
      Targets: [
        {
          Id: 'WordOfDayTarget',
          Arn: `arn:aws:lambda:us-east-2:${process.env.AWS_ACCOUNT_ID || '123456789012'}:function:${functionName}`,
          Input: '{}'
        }
      ]
    });
    
    await eventBridge.send(putTargetsCommand);
    console.log('✅ Target added to rule');
    
    // Add permission for EventBridge to invoke the Lambda function
    const addPermissionCommand = new AddPermissionCommand({
      FunctionName: functionName,
      StatementId: 'EventBridgeInvoke',
      Action: 'lambda:InvokeFunction',
      Principal: 'events.amazonaws.com',
      SourceArn: ruleResult.RuleArn
    });
    
    await lambda.send(addPermissionCommand);
    console.log('✅ Lambda permission added for EventBridge');
    
    console.log('\n🎉 Daily Word of the Day schedule is now active!');
    console.log('The function will run automatically every day at midnight UTC.');
    console.log('Rule ARN:', ruleResult.RuleArn);
    
  } catch (error) {
    console.error('Error creating schedule:', error);
    
    if (error.name === 'ResourceAlreadyExistsException') {
      console.log('The rule already exists. Checking if it\'s properly configured...');
    }
  }
}

createWordOfDaySchedule();
