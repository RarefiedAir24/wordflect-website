const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand, PutCommand, DeleteCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

const USERS_TABLE = 'wordflect-backend-users-prod';
const MISSIONS_TABLE = 'wordflect-backend-missions-prod';

async function addThemeWordMissions() {
  console.log('Adding theme word completion missions...');

  try {
    // First, check if these missions already exist and delete them
    const existingMissions = await dynamoDB.send(new ScanCommand({
      TableName: MISSIONS_TABLE,
      FilterExpression: 'contains(title, :title)',
      ExpressionAttributeValues: {
        ':title': 'Find All Daily Theme Words'
      }
    }));

    if (existingMissions.Items && existingMissions.Items.length > 0) {
      console.log(`Found ${existingMissions.Items.length} existing theme word missions, deleting...`);
      for (const mission of existingMissions.Items) {
        await dynamoDB.send(new DeleteCommand({
          TableName: MISSIONS_TABLE,
          Key: { id: mission.id }
        }));
        console.log(`Deleted mission: ${mission.title}`);
      }
    }

    // Add Daily Mission: Find All Daily Theme Words
    const dailyMission = {
      id: 'find-all-daily-theme-words',
      title: 'Find All Daily Theme Words',
      description: 'Complete all 12 daily theme words in a single day',
      objective: 'Find all daily theme words',
      target: 1,
      period: 'daily',
      tier: 'Daily Special',
      flectcoins: 0,
      gems: 50,
      reward: {
        type: 'gems',
        amount: 50
      },
      category: 'theme',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await dynamoDB.send(new PutCommand({
      TableName: MISSIONS_TABLE,
      Item: dailyMission
    }));
    console.log('Added daily mission: Find All Daily Theme Words (50 gems)');

    // Add Weekly Mission: Find All Daily Theme Words
    const weeklyMission = {
      id: 'find-all-weekly-theme-words',
      title: 'Find All Daily Theme Words',
      description: 'Complete all daily theme words for 7 days',
      objective: 'Find all daily theme words',
      target: 7,
      period: 'weekly',
      tier: 'Weekly Special',
      flectcoins: 0,
      gems: 500,
      reward: {
        type: 'gems',
        amount: 500
      },
      category: 'theme',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await dynamoDB.send(new PutCommand({
      TableName: MISSIONS_TABLE,
      Item: weeklyMission
    }));
    console.log('Added weekly mission: Find All Daily Theme Words (500 gems)');

    console.log('✅ Theme word missions added successfully!');
    console.log('📋 Summary:');
    console.log('  - Daily: Find All Daily Theme Words (50 gems)');
    console.log('  - Weekly: Find All Daily Theme Words (500 gems)');

  } catch (error) {
    console.error('❌ Error adding theme word missions:', error);
    throw error;
  }
}

// Run the script
addThemeWordMissions()
  .then(() => {
    console.log('🎉 Script completed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 Script failed:', error);
    process.exit(1);
  });
