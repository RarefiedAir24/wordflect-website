const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function fixMissionRewardStructure() {
  console.log('🔧 Fixing mission reward structure...\n');
  
  try {
    // Get all missions
    const result = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-missions-prod'
    }));
    
    console.log(`📊 Found ${result.Items.length} missions to update\n`);
    
    let updatedCount = 0;
    
    for (const mission of result.Items) {
      const hasReward = mission.reward && typeof mission.reward === 'object';
      
      if (!hasReward) {
        // Create proper reward structure based on flectcoins and gems
        let rewardType = 'none';
        let rewardAmount = 0;
        
        if (mission.flectcoins && mission.flectcoins > 0) {
          rewardType = 'flectcoins';
          rewardAmount = mission.flectcoins;
        } else if (mission.gems && mission.gems > 0) {
          rewardType = 'gems';
          rewardAmount = mission.gems;
        }
        
        // Update mission with proper reward structure
        const updatedMission = {
          ...mission,
          reward: {
            type: rewardType,
            amount: rewardAmount
          }
        };
        
        await dynamoDB.send(new PutCommand({
          TableName: 'wordflect-backend-missions-prod',
          Item: updatedMission
        }));
        
        console.log(`✅ Updated: ${mission.title} - ${rewardType}: ${rewardAmount}`);
        updatedCount++;
      } else {
        console.log(`⏭️  Skipped: ${mission.title} - already has reward structure`);
      }
    }
    
    console.log(`\n🎉 Updated ${updatedCount} missions with proper reward structure!`);
    console.log('\n📋 REWARD STRUCTURE FIXED:');
    console.log('==========================');
    console.log('✅ All missions now have the reward field with type and amount');
    console.log('✅ Backend can now properly award flectcoins/gems on completion');
    console.log('✅ Duplicate rewards are prevented by the existing logic');
    
  } catch (error) {
    console.error('❌ Error fixing mission reward structure:', error);
  }
}

fixMissionRewardStructure();
