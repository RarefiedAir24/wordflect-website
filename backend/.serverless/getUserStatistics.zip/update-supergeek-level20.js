const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function updateSupergeekLevel20() {
  try {
    console.log('Updating supergeek@me.com user profile to level 20...');
    
    // Update the user profile with level 20 and realistic stats
    const updateResult = await dynamoDB.send(new UpdateCommand({
      TableName: 'wordflect-backend-users-prod',
      Key: { id: 'd59de7c3-9c83-41c9-87bf-a73b87048ff3' },
      UpdateExpression: 'SET username = :username, highestLevel = :highestLevel, gems = :gems, flectcoins = :flectcoins, profileImageUrl = :profileImageUrl',
      ExpressionAttributeValues: {
        ':username': 'RarefiedAir24',
        ':highestLevel': 20,  // Restored to your actual level
        ':gems': 5000,        // More realistic gems for level 20
        ':flectcoins': 3000,  // More realistic flectcoins for level 20
        ':profileImageUrl': 'https://wordflect-profile-images.s3.amazonaws.com/profile-images/RarefiedAir24.jpg' // Placeholder for profile image
      }
    }));
    
    console.log('✅ User profile updated to level 20!');
    console.log('Username: RarefiedAir24');
    console.log('Level: 20');
    console.log('Gems: 5000');
    console.log('Flectcoins: 3000');
    console.log('Profile Image: Restored placeholder');
    console.log('\nYou can now sign in with:');
    console.log('Email: supergeek@me.com');
    console.log('Password: test123');
    
  } catch (error) {
    console.error('Error updating user profile:', error);
  }
}

updateSupergeekLevel20();
