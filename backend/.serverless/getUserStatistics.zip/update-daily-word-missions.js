const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, DeleteCommand, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

function generateMissionId(type, title) {
  return `${type}-${title.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
}

async function updateDailyWordMissions() {
  try {
    console.log('Updating daily missions with correct word-finding missions...');
    
    // First, let's see what's currently in the database
    const scanResult = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-missions-prod',
      FilterExpression: '#type = :type',
      ExpressionAttributeNames: { '#type': 'type' },
      ExpressionAttributeValues: { ':type': 'daily' }
    }));
    
    console.log(`Found ${scanResult.Items.length} current daily missions`);
    
    // Delete existing daily missions
    for (const mission of scanResult.Items) {
      console.log(`Deleting mission: ${mission.title}`);
      await dynamoDB.send(new DeleteCommand({
        TableName: 'wordflect-backend-missions-prod',
        Key: { id: mission.id }
      }));
    }
    
    // Create new daily missions with word-finding missions from 10 to 200
    const dailyMissions = [
      // Basic gameplay missions
      { 
        id: generateMissionId('daily', 'Play 1 Game Today'), 
        type: 'daily', 
        title: 'Play 1 Game Today', 
        description: 'Play at least one game today', 
        target: 1, 
        objective: 'Play Games Today', 
        reward: { type: 'points', amount: 25 }, 
        tier: 'Daily Basics', 
        category: 'gameplay', 
        sortOrder: 1 
      },
      { 
        id: generateMissionId('daily', 'Score 100 Points'), 
        type: 'daily', 
        title: 'Score 100 Points', 
        description: 'Score 100 points today', 
        target: 100, 
        objective: 'Score Points Today', 
        reward: { type: 'points', amount: 40 }, 
        tier: 'Daily Basics', 
        category: 'scoring', 
        sortOrder: 2 
      },
      { 
        id: generateMissionId('daily', 'Complete Game Without Hints'), 
        type: 'daily', 
        title: 'Complete Game Without Hints', 
        description: 'Complete a game without using any hints', 
        target: 1, 
        objective: 'Complete Games No Hints Today', 
        reward: { type: 'points', amount: 100 }, 
        tier: 'Daily Challenges', 
        category: 'gameplay', 
        sortOrder: 3 
      },
      { 
        id: generateMissionId('daily', 'Find a Long Word'), 
        type: 'daily', 
        title: 'Find a Long Word', 
        description: 'Find a word with 8 or more letters', 
        target: 1, 
        objective: 'Find Long Words Today', 
        reward: { type: 'points', amount: 50 }, 
        tier: 'Daily Challenges', 
        category: 'word-finding', 
        sortOrder: 4 
      },
      { 
        id: generateMissionId('daily', 'Find 3 Long Words'), 
        type: 'daily', 
        title: 'Find 3 Long Words', 
        description: 'Find 3 words with 8 or more letters', 
        target: 3, 
        objective: 'Find Long Words Today', 
        reward: { type: 'points', amount: 75 }, 
        tier: 'Daily Challenges', 
        category: 'word-finding', 
        sortOrder: 5 
      },
      { 
        id: generateMissionId('daily', 'Play 3 Games'), 
        type: 'daily', 
        title: 'Play 3 Games', 
        description: 'Play 3 games today', 
        target: 3, 
        objective: 'Play Games Today', 
        reward: { type: 'points', amount: 60 }, 
        tier: 'Daily Challenges', 
        category: 'gameplay', 
        sortOrder: 6 
      },
      { 
        id: generateMissionId('daily', 'Score 200 Points'), 
        type: 'daily', 
        title: 'Score 200 Points', 
        description: 'Score 200 points today', 
        target: 200, 
        objective: 'Score Points Today', 
        reward: { type: 'points', amount: 80 }, 
        tier: 'Daily Challenges', 
        category: 'scoring', 
        sortOrder: 7 
      },
      { 
        id: generateMissionId('daily', 'Find the Word of the Day'), 
        type: 'daily', 
        title: 'Find the Word of the Day', 
        description: 'Find today\'s word of the day: {word}', 
        target: 1, 
        objective: 'Find Word of the Day Today', 
        reward: { type: 'gems', amount: 100 }, 
        tier: 'Daily Special', 
        category: 'special', 
        sortOrder: 8 
      }
    ];
    
    // Add word-finding missions from 10 to 200 words
    const wordCounts = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 120, 140, 160, 180, 200];
    let sortOrder = 9;
    
    for (const wordCount of wordCounts) {
      const reward = wordCount <= 50 ? 30 + (wordCount / 10) * 10 : 80 + (wordCount - 50) / 10 * 5;
      dailyMissions.push({
        id: generateMissionId('daily', `Find ${wordCount} Words`),
        type: 'daily',
        title: `Find ${wordCount} Words`,
        description: `Find ${wordCount} words today`,
        target: wordCount,
        objective: 'Find X Words Today',
        reward: { type: 'points', amount: Math.round(reward) },
        tier: wordCount <= 50 ? 'Daily Basics' : 'Daily Challenges',
        category: 'word-finding',
        sortOrder: sortOrder++
      });
    }
    
    // Add the missions to the database
    for (const mission of dailyMissions) {
      await dynamoDB.send(new PutCommand({
        TableName: 'wordflect-backend-missions-prod',
        Item: mission
      }));
      console.log(`✅ Added mission: ${mission.title} (${mission.type})`);
    }
    
    console.log(`\n🎉 Updated daily missions! Total: ${dailyMissions.length} missions`);
    console.log('📋 Word-finding missions: 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 120, 140, 160, 180, 200 words');
    
  } catch (error) {
    console.error('Error updating daily missions:', error);
  }
}

updateDailyWordMissions();
