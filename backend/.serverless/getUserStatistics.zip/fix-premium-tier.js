const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, UpdateCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function fixPremiumTier() {
  try {
    console.log('Fixing premium tier to match backend expectations...');
    
    // Update the user profile with the correct premium tier value
    const updateResult = await dynamoDB.send(new UpdateCommand({
      TableName: 'wordflect-backend-users-prod',
      Key: { id: 'd59de7c3-9c83-41c9-87bf-a73b87048ff3' },
      UpdateExpression: 'SET premiumTier = :premiumTier',
      ExpressionAttributeValues: {
        ':premiumTier': 'wordflect-pro' // Backend expects 'wordflect-pro' not just 'pro'
      }
    }));
    
    console.log('✅ Premium tier fixed!');
    console.log('Changed from: pro');
    console.log('Changed to: wordflect-pro');
    console.log('\nThis should now allow access to:');
    console.log('- Crystal Crown (Premium frame)');
    console.log('- Phoenix Reign (Pro frame)');
    
  } catch (error) {
    console.error('Error fixing premium tier:', error);
  }
}

fixPremiumTier();
