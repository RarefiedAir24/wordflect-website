const { 
  LambdaClient, 
  ListFunctionsCommand, 
  GetFunctionCommand,
  GetFunctionConfigurationCommand 
} = require('@aws-sdk/client-lambda');

const { 
  APIGatewayClient, 
  GetRestApisCommand,
  GetResourcesCommand,
  GetMethodsCommand 
} = require('@aws-sdk/client-api-gateway');

const { 
  CloudWatchLogsClient, 
  DescribeLogGroupsCommand 
} = require('@aws-sdk/client-cloudwatch-logs');

const { 
  S3Client, 
  ListBucketsCommand,
  ListObjectsV2Command 
} = require('@aws-sdk/client-s3');

const { 
  DynamoDBClient,
  ListTablesCommand 
} = require('@aws-sdk/client-dynamodb');

const { 
  DynamoDBDocumentClient
} = require('@aws-sdk/lib-dynamodb');

const fs = require('fs');
const path = require('path');

// Initialize AWS clients
const lambda = new LambdaClient({ region: 'us-east-2' });
const apiGateway = new APIGatewayClient({ region: 'us-east-2' });
const cloudWatch = new CloudWatchLogsClient({ region: 'us-east-2' });
const s3 = new S3Client({ region: 'us-east-2' });
const dynamoDBClient = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(dynamoDBClient);

async function backupLambdaFunctions() {
  console.log('📦 Backing up Lambda functions...');
  
  try {
    const functions = await lambda.send(new ListFunctionsCommand({}));
    const lambdaBackup = [];
    
    for (const func of functions.Functions) {
      if (func.FunctionName.includes('wordflect-backend-prod')) {
        console.log(`  - Backing up: ${func.FunctionName}`);
        
        // Get function details
        const functionDetails = await lambda.send(new GetFunctionCommand({
          FunctionName: func.FunctionName
        }));
        
        // Get function configuration
        const functionConfig = await lambda.send(new GetFunctionConfigurationCommand({
          FunctionName: func.FunctionName
        }));
        
        lambdaBackup.push({
          functionName: func.FunctionName,
          runtime: func.Runtime,
          handler: func.Handler,
          codeSize: func.CodeSize,
          description: func.Description,
          timeout: func.Timeout,
          memorySize: func.MemorySize,
          lastModified: func.LastModified,
          version: func.Version,
          environment: functionConfig.Environment,
          vpcConfig: functionConfig.VpcConfig,
          layers: functionConfig.Layers
        });
      }
    }
    
    return lambdaBackup;
  } catch (error) {
    console.error('❌ Error backing up Lambda functions:', error);
    return [];
  }
}

async function backupAPIGateway() {
  console.log('🌐 Backing up API Gateway...');
  
  try {
    const apis = await apiGateway.send(new GetRestApisCommand({}));
    const apiBackup = [];
    
    for (const api of apis.items) {
      if (api.name.includes('wordflect-backend-prod')) {
        console.log(`  - Backing up API: ${api.name}`);
        
        // Get API resources
        const resources = await apiGateway.send(new GetResourcesCommand({
          restApiId: api.id
        }));
        
        // Get methods for each resource
        const resourcesWithMethods = [];
        for (const resource of resources.items) {
          if (resource.resourceMethods) {
            const methods = [];
            for (const [method, methodDetails] of Object.entries(resource.resourceMethods)) {
              try {
                const methodInfo = await apiGateway.send(new GetMethodsCommand({
                  restApiId: api.id,
                  resourceId: resource.id,
                  httpMethod: method
                }));
                methods.push({
                  method,
                  authorizationType: methodInfo.authorizationType,
                  apiKeyRequired: methodInfo.apiKeyRequired
                });
              } catch (error) {
                methods.push({ method, error: error.message });
              }
            }
            resourcesWithMethods.push({
              id: resource.id,
              path: resource.path,
              methods
            });
          }
        }
        
        apiBackup.push({
          id: api.id,
          name: api.name,
          description: api.description,
          version: api.version,
          createdDate: api.createdDate,
          resources: resourcesWithMethods
        });
      }
    }
    
    return apiBackup;
  } catch (error) {
    console.error('❌ Error backing up API Gateway:', error);
    return [];
  }
}

async function backupCloudWatchLogs() {
  console.log('📊 Backing up CloudWatch Log Groups...');
  
  try {
    const logGroups = await cloudWatch.send(new DescribeLogGroupsCommand({}));
    const logsBackup = [];
    
    for (const logGroup of logGroups.logGroups) {
      if (logGroup.logGroupName.includes('wordflect-backend-prod')) {
        console.log(`  - Backing up Log Group: ${logGroup.logGroupName}`);
        logsBackup.push({
          logGroupName: logGroup.logGroupName,
          creationTime: logGroup.creationTime,
          retentionInDays: logGroup.retentionInDays,
          metricFilterCount: logGroup.metricFilterCount,
          storedBytes: logGroup.storedBytes
        });
      }
    }
    
    return logsBackup;
  } catch (error) {
    console.error('❌ Error backing up CloudWatch Logs:', error);
    return [];
  }
}

async function backupS3Buckets() {
  console.log('🪣 Backing up S3 Buckets...');
  
  try {
    const buckets = await s3.send(new ListBucketsCommand({}));
    const s3Backup = [];
    
    for (const bucket of buckets.Buckets) {
      if (bucket.Name.includes('wordflect') || bucket.Name.includes('wordflect-backend-prod')) {
        console.log(`  - Backing up Bucket: ${bucket.Name}`);
        
        try {
          const objects = await s3.send(new ListObjectsV2Command({
            Bucket: bucket.Name,
            MaxKeys: 1000 // Limit for demo
          }));
          
          s3Backup.push({
            name: bucket.Name,
            creationDate: bucket.CreationDate,
            objectCount: objects.KeyCount,
            totalSize: objects.Contents?.reduce((sum, obj) => sum + obj.Size, 0) || 0,
            sampleObjects: objects.Contents?.slice(0, 10).map(obj => ({
              key: obj.Key,
              size: obj.Size,
              lastModified: obj.LastModified
            })) || []
          });
        } catch (error) {
          s3Backup.push({
            name: bucket.Name,
            creationDate: bucket.CreationDate,
            error: error.message
          });
        }
      }
    }
    
    return s3Backup;
  } catch (error) {
    console.error('❌ Error backing up S3 Buckets:', error);
    return [];
  }
}

async function backupDynamoDBTables() {
  console.log('🗄️ Backing up DynamoDB Table Structure...');
  
  try {
    const tables = await dynamoDBClient.send(new ListTablesCommand({}));
    const dynamoBackup = [];
    
    for (const tableName of tables.TableNames) {
      if (tableName.includes('wordflect-backend-prod')) {
        console.log(`  - Backing up Table Structure: ${tableName}`);
        
        // Note: This only backs up table structure, not data
        // Data is backed up separately by automated-backup-system.js
        dynamoBackup.push({
          tableName,
          backupType: 'structure_only',
          note: 'Data backed up separately by automated-backup-system.js'
        });
      }
    }
    
    return dynamoBackup;
  } catch (error) {
    console.error('❌ Error backing up DynamoDB Tables:', error);
    return [];
  }
}

async function createInfrastructureBackup() {
  const timestamp = new Date().toISOString();
  console.log(`🚀 Starting AWS Infrastructure Backup...`);
  console.log(`📅 Backup timestamp: ${timestamp}`);
  console.log('');
  
  const infrastructureBackup = {
    timestamp,
    lambda: await backupLambdaFunctions(),
    apiGateway: await backupAPIGateway(),
    cloudWatchLogs: await backupCloudWatchLogs(),
    s3Buckets: await backupS3Buckets(),
    dynamoDBTables: await backupDynamoDBTables()
  };
  
  // Save infrastructure backup
  const backupDir = path.join(__dirname, 'backups', new Date().toISOString().split('T')[0]);
  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }
  
  const infrastructurePath = path.join(backupDir, 'aws-infrastructure.json');
  fs.writeFileSync(infrastructurePath, JSON.stringify(infrastructureBackup, null, 2));
  
  console.log('');
  console.log('📊 INFRASTRUCTURE BACKUP SUMMARY:');
  console.log('==================================');
  console.log(`✅ Lambda Functions: ${infrastructureBackup.lambda.length}`);
  console.log(`✅ API Gateway APIs: ${infrastructureBackup.apiGateway.length}`);
  console.log(`✅ CloudWatch Log Groups: ${infrastructureBackup.cloudWatchLogs.length}`);
  console.log(`✅ S3 Buckets: ${infrastructureBackup.s3Buckets.length}`);
  console.log(`✅ DynamoDB Tables: ${infrastructureBackup.dynamoDBTables.length}`);
  console.log('');
  console.log(`📄 Infrastructure backup saved to: ${infrastructurePath}`);
  
  return infrastructureBackup;
}

// Export for use in other scripts
module.exports = {
  createInfrastructureBackup,
  backupLambdaFunctions,
  backupAPIGateway,
  backupCloudWatchLogs,
  backupS3Buckets,
  backupDynamoDBTables
};

// Run if called directly
if (require.main === module) {
  createInfrastructureBackup()
    .then(() => console.log('\n🎉 AWS Infrastructure backup completed!'))
    .catch(error => {
      console.error('❌ Infrastructure backup failed:', error);
      process.exit(1);
    });
}
