const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');
const fs = require('fs');
const path = require('path');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

// Production table names
const TABLES = {
  users: 'wordflect-backend-users-prod',
  missions: 'wordflect-backend-missions-prod',
  frames: 'wordflect-backend-frames-prod',
  backgrounds: 'wordflect-backend-backgrounds-prod',
  wordOfTheDay: 'wordflect-backend-word-of-the-day-prod',
  battles: 'wordflect-backend-battles-prod'
};

async function backupTable(tableName, fileName) {
  try {
    console.log(`📋 Backing up ${tableName}...`);
    
    const items = [];
    let lastEvaluatedKey = undefined;
    
    do {
      const params = {
        TableName: tableName,
        ...(lastEvaluatedKey && { ExclusiveStartKey: lastEvaluatedKey })
      };
      
      const result = await dynamoDB.send(new ScanCommand(params));
      items.push(...(result.Items || []));
      lastEvaluatedKey = result.LastEvaluatedKey;
      
      console.log(`  - Retrieved ${result.Items?.length || 0} items (${items.length} total so far)`);
    } while (lastEvaluatedKey);
    
    // Create backup directory
    const backupDir = path.join(__dirname, 'backups', new Date().toISOString().split('T')[0]);
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    
    // Save backup
    const backupPath = path.join(backupDir, `${fileName}.json`);
    fs.writeFileSync(backupPath, JSON.stringify(items, null, 2));
    
    console.log(`✅ ${tableName} backed up: ${items.length} items saved to ${backupPath}`);
    return { tableName, itemCount: items.length, backupPath };
  } catch (error) {
    console.error(`❌ Failed to backup ${tableName}:`, error);
    return { tableName, error: error.message };
  }
}

async function backupAllProductionData() {
  console.log('🚀 Starting comprehensive production data backup...\n');
  
  const timestamp = new Date().toISOString();
  console.log(`📅 Backup timestamp: ${timestamp}\n`);
  
  const results = [];
  
  // Backup all tables
  for (const [key, tableName] of Object.entries(TABLES)) {
    const result = await backupTable(tableName, key);
    results.push(result);
    console.log('');
  }
  
  // Create backup summary
  const summary = {
    timestamp,
    tables: results,
    totalItems: results.reduce((sum, r) => sum + (r.itemCount || 0), 0)
  };
  
  const backupDir = path.join(__dirname, 'backups', new Date().toISOString().split('T')[0]);
  const summaryPath = path.join(backupDir, 'backup-summary.json');
  fs.writeFileSync(summaryPath, JSON.stringify(summary, null, 2));
  
  console.log('📊 BACKUP SUMMARY:');
  console.log('==================');
  results.forEach(result => {
    if (result.error) {
      console.log(`❌ ${result.tableName}: ERROR - ${result.error}`);
    } else {
      console.log(`✅ ${result.tableName}: ${result.itemCount} items`);
    }
  });
  console.log(`\n📁 Total items backed up: ${summary.totalItems}`);
  console.log(`📄 Summary saved to: ${summaryPath}`);
  
  return summary;
}

// Run backup
backupAllProductionData().catch(console.error);
