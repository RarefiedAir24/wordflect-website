const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, BatchWriteCommand } = require('@aws-sdk/lib-dynamodb');
const fs = require('fs');
const path = require('path');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

// Production table names
const TABLES = {
  users: 'wordflect-backend-users-prod',
  missions: 'wordflect-backend-missions-prod',
  frames: 'wordflect-backend-frames-prod',
  backgrounds: 'wordflect-backend-backgrounds-prod',
  wordOfTheDay: 'wordflect-backend-word-of-the-day-prod',
  battles: 'wordflect-backend-battles-prod'
};

async function restoreTable(tableName, backupPath) {
  try {
    console.log(`🔄 Restoring ${tableName} from ${backupPath}...`);
    
    if (!fs.existsSync(backupPath)) {
      console.log(`❌ Backup file not found: ${backupPath}`);
      return { tableName, error: 'Backup file not found' };
    }
    
    const items = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
    console.log(`  - Found ${items.length} items to restore`);
    
    if (items.length === 0) {
      console.log(`  - No items to restore for ${tableName}`);
      return { tableName, itemCount: 0 };
    }
    
    // Batch write items (DynamoDB allows max 25 items per batch)
    const batchSize = 25;
    let restoredCount = 0;
    
    for (let i = 0; i < items.length; i += batchSize) {
      const batch = items.slice(i, i + batchSize);
      const writeRequests = batch.map(item => ({
        PutRequest: { Item: item }
      }));
      
      try {
        await dynamoDB.send(new BatchWriteCommand({
          RequestItems: {
            [tableName]: writeRequests
          }
        }));
        restoredCount += batch.length;
        console.log(`  - Restored batch ${Math.floor(i/batchSize) + 1}: ${batch.length} items`);
      } catch (error) {
        console.error(`  - Error restoring batch ${Math.floor(i/batchSize) + 1}:`, error);
        // Continue with next batch
      }
    }
    
    console.log(`✅ ${tableName} restored: ${restoredCount}/${items.length} items`);
    return { tableName, itemCount: restoredCount, totalItems: items.length };
  } catch (error) {
    console.error(`❌ Failed to restore ${tableName}:`, error);
    return { tableName, error: error.message };
  }
}

async function restoreFromBackup(backupDate) {
  console.log('🚀 Starting data restoration from backup...\n');
  
  const backupDir = path.join(__dirname, 'backups', backupDate);
  if (!fs.existsSync(backupDir)) {
    console.error(`❌ Backup directory not found: ${backupDir}`);
    console.log('Available backup dates:');
    const backupsDir = path.join(__dirname, 'backups');
    if (fs.existsSync(backupsDir)) {
      const dates = fs.readdirSync(backupsDir).filter(f => fs.statSync(path.join(backupsDir, f)).isDirectory());
      dates.forEach(date => console.log(`  - ${date}`));
    }
    return;
  }
  
  // Check for backup summary
  const summaryPath = path.join(backupDir, 'backup-summary.json');
  if (fs.existsSync(summaryPath)) {
    const summary = JSON.parse(fs.readFileSync(summaryPath, 'utf8'));
    console.log(`📅 Restoring from backup created: ${summary.timestamp}`);
    console.log(`📊 Original backup contained: ${summary.totalItems} total items\n`);
  }
  
  const results = [];
  
  // Restore all tables
  for (const [key, tableName] of Object.entries(TABLES)) {
    const backupPath = path.join(backupDir, `${key}.json`);
    const result = await restoreTable(tableName, backupPath);
    results.push(result);
    console.log('');
  }
  
  console.log('📊 RESTORATION SUMMARY:');
  console.log('========================');
  results.forEach(result => {
    if (result.error) {
      console.log(`❌ ${result.tableName}: ERROR - ${result.error}`);
    } else {
      console.log(`✅ ${result.tableName}: ${result.itemCount} items restored`);
    }
  });
  
  const totalRestored = results.reduce((sum, r) => sum + (r.itemCount || 0), 0);
  console.log(`\n📁 Total items restored: ${totalRestored}`);
}

// Usage: node restore-from-backup.js YYYY-MM-DD
const backupDate = process.argv[2];
if (!backupDate) {
  console.error('❌ Please provide backup date (YYYY-MM-DD)');
  console.log('Usage: node restore-from-backup.js 2025-08-22');
  process.exit(1);
}

restoreFromBackup(backupDate).catch(console.error);
