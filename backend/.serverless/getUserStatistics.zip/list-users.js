const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, ScanCommand } = require('@aws-sdk/lib-dynamodb');

const client = new DynamoDBClient({ region: 'us-east-2' });
const dynamoDB = DynamoDBDocumentClient.from(client);

async function listUsers() {
  try {
    console.log('Listing all users in DEV table...');
    
    const scanResult = await dynamoDB.send(new ScanCommand({
      TableName: 'wordflect-backend-users-dev'
    }));
    
    if (scanResult.Items && scanResult.Items.length > 0) {
      console.log(`Found ${scanResult.Items.length} users:`);
      scanResult.Items.forEach((user, index) => {
        console.log(`\n${index + 1}. User:`);
        console.log(`   ID: ${user.id}`);
        console.log(`   Username: ${user.username}`);
        console.log(`   Email: ${user.email}`);
        console.log(`   Has password: ${!!user.password}`);
        console.log(`   Created: ${user.createdAt}`);
      });
    } else {
      console.log('No users found in DEV table');
    }
    
  } catch (error) {
    console.error('Error listing users:', error);
  }
}

listUsers();
